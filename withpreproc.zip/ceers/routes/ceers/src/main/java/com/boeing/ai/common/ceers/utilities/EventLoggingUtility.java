/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 04-13-2016
 * Authors      : Tim Schramer
 * File         : EventLoggingUtility.java - Create and process CEERS Events
 *                                           Converted from .NET API
 *-----------------------------------------------------------------------------
 * Revision History (Release 2.5.5)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *--------------|-------------------|------------------------------------------
 * 1.0.0/2.0.0  | Tim Schramer      | Added with version 2.0.0
 *              | 04-13-2016        |
 *--------------|-------------------|------------------------------------------
 * 2.0.0/2.5.0  | Tim Schramer      | Robust Unit tests. Added legacy .NET
 *              | Rohan Mars        | method calls. Additional functionality
 *              | 04-21-2016        | Restructured code.
 *--------------|-------------------|------------------------------------------
 * 2.5.0/2.5.5  | Tim Schramer      | Restructured to natively support Classes
 *              | 04-28-2016        | ported from .NET.
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.ceers.utilities;
import com.boeing.ai.common.ceers.messages.EventType;
import com.boeing.ai.common.ceers.utilities.CeersUtils;
import com.boeing.ai.common.ceers.utilities.EventLoggingDefaults;
import com.boeing.ai.common.utilities.ArgumentException;
import com.boeing.ai.common.utilities.IO.DirectorySupport;
import com.boeing.ai.common.utilities.StringSupport;
import com.boeing.ai.common.utilities.Web.HttpUtilSupport;

import com.boeing.web.xmlns.ai.ceers.v1.Attribute;
import com.boeing.web.xmlns.ai.ceers.v1.AttributeSet;
import com.boeing.web.xmlns.ai.ceers.v1.Event;
import com.boeing.web.xmlns.ai.ceers.v1.ObjectFactory;

import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.StringReader;

import java.net.InetAddress;

import java.nio.file.Path;
import java.nio.file.Paths;

import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathFactory;

import org.apache.camel.Exchange;
import org.apache.commons.lang3.exception.ExceptionUtils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.w3c.dom.Document;

import org.xml.sax.InputSource;
/*---------------------------------------------------------------------------*/
public class EventLoggingUtility {
    private final Logger LOG = LoggerFactory.getLogger(EventLoggingUtility.class);
    public boolean debug = false;
    private String eventLogDirectory = "";
    private String messageID;
    private boolean messageSent = false;
    private EventType eventType = EventType.AUDIT;

    private ObjectFactory objectFactory = new ObjectFactory();
    private Event eventMessage;

    public EventLoggingUtility(String eventLogDirectory) throws Exception {
        initMessage();
        this.eventLogDirectory = eventLogDirectory;
    }

    private void initMessage() throws Exception {
        this.messageID = "";
        this.eventMessage = this.objectFactory.createEvent();
        this.eventMessage.setEventId("");
        this.eventMessage.setEventGroup("");
        this.eventMessage.setApplicationName("");
        this.eventMessage.setMessageName("");
        this.eventMessage.setGlobalTxId("");
        this.eventMessage.setServerName(InetAddress.getLocalHost().getHostName());
        this.eventMessage.setEnvironmentName("");
        this.eventMessage.setComponentName("");
        this.eventMessage.setMetadata(null);
        this.eventMessage.setUserdata(null);
        this.eventMessage.setEventData(this.objectFactory.createEventData());
    }

    public void logErrorMessage(Exception ex) throws Exception {
        this.LOG.error(ex.getMessage() + ":\n" + ExceptionUtils.getStackTrace(ex));
    }

    public void writeEventMessage() throws Exception {
        if (!this.messageSent) {
            // TimeStamp and ServerName may not have been set from the Event fields. Make sure they have values.
            if (this.eventMessage.getEventTimestamp() == null || this.eventMessage.getEventTimestamp().toString().length() == 0) {
                GregorianCalendar cal = (GregorianCalendar)GregorianCalendar.getInstance();
                DatatypeFactory dtf = DatatypeFactory.newInstance();
                XMLGregorianCalendar xmlCal = dtf.newXMLGregorianCalendar(cal);

                this.eventMessage.setEventTimestamp(xmlCal);
            }
            if (StringSupport.isBlank(this.eventMessage.getServerName())) {
                this.eventMessage.setServerName(InetAddress.getLocalHost().getHostName());
            }
            if (!StringSupport.isBlank(this.eventLogDirectory)) {
                if (!DirectorySupport.verifyDirectory(this.eventLogDirectory)) {
                    throw new ArgumentException("Alternate Event Logging directory invalid or could not be created: " + this.eventLogDirectory);
                }
            }
            writeMessageOut();
            this.messageSent = true;
        }
    }

    private void writeMessageOut() throws Exception {
        String eventFileName = "";
        String eventType = "UNKNOWN";
        Path eventSpec;
        if (this.getEventType() == EventType.AUDIT) {
            eventType = "AUDIT";
        } else if (this.getEventType() == EventType.STATE) {
            eventType = "STATE";
        } else if (this.getEventType() == EventType.NOTIFICATION) {
            eventType = "NOTIF";
        } else if (this.getEventType() == EventType.PENDING) {
            eventType = "PENDING";
        }

        // Write Event to file - Platform independent.
        eventFileName = String.format("%s_%s.xml", eventType, this.eventMessage.getEventId());
        eventSpec = Paths.get( this.eventLogDirectory, eventFileName );
// LOG.info("WRITEMESSAGEOUT = " + eventSpec.toString());

        OutputStream outputStream = null;
        try {
            outputStream = new FileOutputStream(eventSpec.toString());
            String eventXml = CeersUtils.marshalCeersObject(eventMessage, outputStream);
        } finally {
            outputStream.flush();
            outputStream.close();
            outputStream = null;
            System.gc();
        }
    }

    private String trimStringToMaxLength(String value) throws Exception {
        if (value.length() > EventLoggingDefaults.MAX_VALUE_LENGTH)
            return value.substring(0, (0) + (EventLoggingDefaults.MAX_VALUE_LENGTH));
        else
            return value;
    }

    // Parse 'Field1'='Value1','Field2'='Value2' type string and load event attribute class array.
    public AttributeSet parseNameValueString(String pairString) throws Exception {
        AttributeSet nameValues = null;
        int numPairs = 0;
        if (pairString == null || !pairString.contains("="))
            return nameValues;

        pairString = StringSupport.Trim(pairString);
        if (StringSupport.isBlank(pairString))
            return nameValues;

        pairString = CeersUtils.cleanupOfficeCharacters(pairString);
        LOG.debug("ParseNameValueString: pairString 1 = " + pairString);

        try
        {
            // Cleanup delimiters
            pairString = pairString.replace("' =", "'=");
            pairString = pairString.replace("= '", "='");
            pairString = pairString.replace("' ,", "',");
            pairString = pairString.replace(", '", ",'");
            // Special case. Last value omitted.
            if (pairString.endsWith("'="))
                pairString = pairString + "'";

            numPairs = CeersUtils.countStringOccurrences(pairString,"'='");
            if (numPairs == 0)
                return nameValues;

            LOG.debug("ParseNameValueString: pairString / numPairs= " + pairString + "/" + String.valueOf(numPairs));

            nameValues = this.objectFactory.createAttributeSet();
            Attribute myAttPair;
            String[] pairs = new String[numPairs];
            String[] keyvalue = new String[2];
            // Replace delimiters for parsing
            pairString = pairString.replace("'='", "^");
            pairString = pairString.replace("','", "~");
            pairString = StringSupport.TrimStart(pairString, new char[] {'\''});
            pairString = StringSupport.TrimEnd(pairString, new char[] {'\''});
            pairs = StringSupport.Split(pairString, '~');
            LOG.debug("ParseNameValueString: Looping...");

            for (int loop = 0; loop < numPairs; loop++) {
                myAttPair = this.objectFactory.createAttribute();
                keyvalue[0] = "";
                keyvalue[1] = "";
                keyvalue = StringSupport.Split(pairs[loop], '^');
                LOG.debug("ParseNameValueString: loop/key/value = " + String.valueOf(loop) + "/" + keyvalue[0] + "/" + keyvalue[1]);

                myAttPair.setKey(keyvalue[0]);
                myAttPair.setValue(keyvalue[1]);
                nameValues.getAttribute().add(myAttPair);
            }
        } catch (Exception e) {
            LOG.error("ParseNameValueString: Name/Value string Parse Exception = " + pairString + "\n\n" + e.getMessage() + "\n\n" + e.getStackTrace().toString());
            ArgumentException argE = new ArgumentException("Error parsing Name/Value string, " + pairString + "\n\n" + e.getMessage(), e);
            throw argE;
        }

        //nameValues = this._objectFactory.createAttributeSet();
        //Attribute myAttPair = this._objectFactory.createAttribute();
        //myAttPair.setKey("(Error getting Key/Value pairs)");
        //myAttPair.setValue("");
        //nameValues.getAttribute().add(myAttPair);
        LOG.debug("ParseNameValueString: Num Atts = " + String.valueOf(nameValues.getAttribute().size()));

        return nameValues;
    }

    // Parse 'Field1'='Value1','Field2'='Value2' type string and load event attribute class array.
    public AttributeSet parseNameValueStringESC(String pairString) throws Exception {
        AttributeSet nameValues = null;
        int numPairs = 0;
        if (pairString == null || !pairString.contains("="))
            return nameValues;

        pairString = StringSupport.Trim(pairString);
        if (StringSupport.isBlank(pairString))
            return nameValues;

        pairString = CeersUtils.cleanupOfficeCharacters(pairString);
        LOG.debug("ParseNameValueStringESC: pairString 1 = " + pairString);

        try
        {
            // Cleanup delimiters
            pairString = pairString.replace("' =", "'=");
            pairString = pairString.replace("= '", "='");
            pairString = pairString.replace("' ,", "',");
            pairString = pairString.replace(", '", ",'");
            // Special case. Last value omitted.
            if (pairString.endsWith("'="))
                pairString = pairString + "'";

            numPairs = CeersUtils.countStringOccurrences(pairString,"'='");
            if (numPairs == 0)
                return nameValues;

            LOG.debug("ParseNameValueStringESC: pairString / numPairs= " + pairString + "/" + String.valueOf(numPairs));

            nameValues = this.objectFactory.createAttributeSet();
            Attribute myAttPair;
            String[] pairs = new String[numPairs];
            String[] keyvalue = new String[2];
            // Replace delimiters for parsing
            pairString = pairString.replace("'='", "^");
            pairString = pairString.replace("','", "~");
            pairString = StringSupport.TrimStart(pairString, new char[] {'\''});
            pairString = StringSupport.TrimEnd(pairString, new char[] {'\''});
            pairs = StringSupport.Split(pairString, '~');
            LOG.debug("ParseNameValueStringESC: Looping...");

            for (int loop = 0; loop < numPairs; loop++) {
                myAttPair = this.objectFactory.createAttribute();
                keyvalue[0] = "";
                keyvalue[1] = "";
                keyvalue = StringSupport.Split(pairs[loop], '^');
                LOG.debug("ParseNameValueStringESC: loop/key/value = " + String.valueOf(loop) + "/" + keyvalue[0] + "/" + keyvalue[1]);

                myAttPair.setKey(keyvalue[0]);
                myAttPair.setValue(HttpUtilSupport.HtmlDecode(keyvalue[1]));
                nameValues.getAttribute().add(myAttPair);
            }
        } catch (Exception e) {
            LOG.error("ParseNameValueStringESC: Name/Value string Parse Exception = " + pairString + "\n\n" + e.getMessage() + "\n\n" + e.getStackTrace().toString());
            ArgumentException argE = new ArgumentException("Error parsing Name/Value string, " + pairString + "\n\n" + e.getMessage(), e);
            throw argE;
        }

        //nameValues = this._objectFactory.createAttributeSet();
        //Attribute myAttPair = this._objectFactory.createAttribute();
        //myAttPair.setKey("(Error getting Key/Value pairs)");
        //myAttPair.setValue("");
        //nameValues.getAttribute().add(myAttPair);
        LOG.debug("ParseNameValueString: Num Atts = " + String.valueOf(nameValues.getAttribute().size()));

        return nameValues;
    }

    public AttributeSet getContextNameValuePairs(Exchange exchange) throws Exception {
        AttributeSet nameValues = this.objectFactory.createAttributeSet();
        if(exchange == null) return nameValues;

        Map<String, Object> exchangeMetadata = exchange.getProperties();
        Attribute myAttPair;

        for (Map.Entry<String, Object> entry : exchangeMetadata.entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();

            myAttPair = this.objectFactory.createAttribute();
            myAttPair.setKey(key);
            myAttPair.setValue(value.toString());
            nameValues.getAttribute().add(myAttPair);
        }

        return nameValues;
    }

    // Combine attributeset arrays.
    public AttributeSet combineAttributeSets(AttributeSet set1, AttributeSet set2) throws Exception {
        AttributeSet comboSet = null;
        int set1Size = 0;
        int set2Size = 0;

        if (set1 != null)
            set1Size = set1.getAttribute().size();
        if (set2 != null)
            set2Size = set2.getAttribute().size();
        if (set1Size + set2Size == 0)
            return comboSet;

        List<Attribute> list1 = set1.getAttribute();
        List<Attribute> list2 = set2.getAttribute();
        Attribute myAttPair;

        comboSet = this.objectFactory.createAttributeSet();
        if (list1 != null) {
            for (int loop = 0; loop < set1Size; loop++) {
                myAttPair = this.objectFactory.createAttribute();
                myAttPair.setKey(list1.get(loop).getKey());
                myAttPair.setValue(list1.get(loop).getValue());
                comboSet.getAttribute().add(myAttPair);
            }
        }

        if (list2 != null) {
            for (int loop = 0; loop < set2Size; loop++) {
                myAttPair = this.objectFactory.createAttribute();
                myAttPair.setKey(list2.get(loop).getKey());
                myAttPair.setValue(list2.get(loop).getValue());
                comboSet.getAttribute().add(myAttPair);
            }
        }

        return comboSet;
    }

    // Changeout XPATH and BYTERANGE values with the Payload value.
    public AttributeSet getPayloadValues(AttributeSet attSet, String payloadString) throws Exception {
        if (attSet == null || payloadString == null)
            return null;

        List<Attribute> alist = attSet.getAttribute();
        AttributeSet newSet = this.objectFactory.createAttributeSet();
        Attribute myAttPair;
        String newVal = "";
        for (int loop = 0; loop < attSet.getAttribute().size(); loop++) {
            myAttPair = this.objectFactory.createAttribute();
            myAttPair.setKey(alist.get(loop).getKey());
            newVal = alist.get(loop).getValue();

            if (newVal.toUpperCase().startsWith("XPATH(")) {
                try {
                    newVal = parseBufferXpath(newVal,payloadString);
                } catch (Exception pe) {
                    LOG.debug("GetPayloadValues(): " + pe.getMessage());
                }

            } else if (newVal.toUpperCase().startsWith("BYTERANGE(")) {
                try {
                    newVal = parseBufferByteRange(newVal,payloadString);
                } catch (Exception pe) {
                    LOG.debug("GetPayloadValues(): " + pe.getMessage());
                }

            }
            myAttPair.setValue(newVal);
            newSet.getAttribute().add(myAttPair);
        }
        return newSet;
    }

    // Return a string of the entire message body (obsolete, just return payload string)
    public String parseBufferAll(String payloadString) throws Exception {
        String bodyString = payloadString;

        if (bodyString.equals("")) bodyString = "";
        return bodyString;
    }

    // Return a string of the message body with XPATH applied.
    public String parseBufferXpath(String xpString, String payloadString) throws Exception {
        String pathString = "";
        String bodyString = "";

        pathString = xpString.substring(xpString.indexOf("(") + 1);
        pathString = pathString.substring(0,(0) + (pathString.length() - 1));
        pathString = StringSupport.Trim(pathString);
        if (StringSupport.isBlank(pathString))
            return "";

        LOG.debug("ParseBufferXpath(): pathString = " + pathString);

        InputSource inSource = new InputSource(new StringReader(payloadString));
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = dbFactory.newDocumentBuilder();
        Document document = docBuilder.parse(inSource);

        XPathFactory xpathFactory = XPathFactory.newInstance();
        XPath xpath = xpathFactory.newXPath();

        bodyString = xpath.evaluate(pathString, document);

        return bodyString;
    }

    // Return a string of the message body with BYTERANGE applied.
    public String parseBufferByteRange(String brString, String payloadString) throws Exception {
        String bodyString = "";
        String rangeString = "";
        int bIndex = 0;
        int bLength = 0;
        int msgSize = 0;

        // Get the range from the string
        rangeString = brString.replace(" ", "");
        rangeString = rangeString.substring(rangeString.indexOf("(") + 1);
        rangeString = StringSupport.TrimEnd(rangeString, new char[] {')'});
        LOG.debug("ParseBufferByteRange(): rangeString = " + rangeString);

        if (rangeString.contains(",")) {
            // Starting byte and length
            String[] range = new String[2];
            range = StringSupport.Split(rangeString, ',');
            bIndex = Integer.valueOf(range[0]);
            bLength = Integer.valueOf(range[1]);
        } else if (!StringSupport.isBlank(rangeString)) {
            // Starting byte only
            bIndex = Integer.valueOf(rangeString);
            bLength = -1;
        } else
        {
            // No range
            LOG.debug("ParseBufferByteRange(): Missing BYTERANGE() found");

            throw new ArgumentException("Missing range values in BYTERANGE() found", "");
        }
        if (bIndex < 0 || bLength < -1) {
            LOG.debug("ParseBufferByteRange(): Invalid BYTERANGE() values found");

            throw new ArgumentException("Invalid BYTERANGE() values found", "");
        }

        LOG.debug("ParseBufferByteRange(): Pipeline Stream found");

        msgSize = payloadString.length();

        // Check for meaningful byte range and reset to message length if needed.
        if (msgSize == 0 || bIndex > msgSize - 1)
            return "";

        if (bLength == -1)
            bLength = msgSize - bIndex;

        if (bIndex + bLength > msgSize)
            bLength = msgSize - bIndex;

        LOG.debug("ParseBufferByteRange(): bIndex = " + String.valueOf(bIndex));
        LOG.debug("ParseBufferByteRange(): bLength = " + String.valueOf(bLength));
        LOG.debug("ParseBufferByteRange(): msgSize = " + String.valueOf(msgSize));

        if (bIndex + bLength <= msgSize) {
            bodyString = payloadString.substring(bIndex, bIndex + bLength);
        }

        return bodyString;
    }

    public byte[] convertStringToBytes(String input) throws Exception {
        byte[] byteData = new byte[0];

        if(StringSupport.isBlank(input)) return byteData;
        byteData = input.getBytes();

        return byteData;
    }

    public String convertBytesToString(byte[] bytes) throws Exception {
        String output = "";

        if(bytes == null || bytes.length ==0) return output;
        output = new String(bytes, "UTF-8");

        return output;
    }

    public EventType getEventType() throws Exception {
        return this.eventType;
    }

    public void setEventType(EventType value) throws Exception {
        this.eventType = value;
    }

    public String getMessageID() throws Exception {
        return this.messageID;
    }

    public void setMessageID(String value) throws Exception {
        this.messageID = value;
    }

    public String getEventID() throws Exception {
        return this.eventMessage.getEventId();
    }

    public void setEventID(String value) throws Exception {
        this.eventMessage.setEventId(value);
    }

    public String getEventGroup() throws Exception {
        return this.eventMessage.getEventGroup();
    }

    public void setEventGroup(String value) throws Exception {
        this.eventMessage.setEventGroup(value);
    }

    public void setApplicationName(String value) throws Exception {
        this.eventMessage.setApplicationName(value);
    }

    public void setMessageName(String value) throws Exception {
        this.eventMessage.setMessageName(trimStringToMaxLength(value));
    }

    public void setEventTimestamp(String value) throws Exception {
        XMLGregorianCalendar xgc=DatatypeFactory.newInstance().newXMLGregorianCalendar(value);
        this.eventMessage.setEventTimestamp(xgc);
    }
    public void setEventTimestamp(GregorianCalendar value) throws Exception {
        DatatypeFactory dtf = DatatypeFactory.newInstance();
        XMLGregorianCalendar xmlCal = dtf.newXMLGregorianCalendar(value);
        this.eventMessage.setEventTimestamp(xmlCal);
    }
    public void setEventTimestamp(XMLGregorianCalendar value) throws Exception {
        this.eventMessage.setEventTimestamp(value);
    }

    public String getGlobalTransID() throws Exception {
        return this.eventMessage.getGlobalTxId();
    }

    public void setGlobalTransID(String value) throws Exception {
        this.eventMessage.setGlobalTxId(value);
    }

    public String getServerName() throws Exception {
        return this.eventMessage.getServerName();
    }

    public void setServerName(String value) throws Exception {
        this.eventMessage.setServerName(value);
    }

    public String getEnvironmentName() throws Exception {
        return this.eventMessage.getEnvironmentName();
    }

    public void setEnvironmentName(String value) throws Exception {
        this.eventMessage.setEnvironmentName(value);
    }

    public void setComponentName(String value) throws Exception {
        this.eventMessage.setComponentName(value);
    }

    public AttributeSet getUserData() throws Exception {
        return this.eventMessage.getUserdata();
    }

    public void setUserData(AttributeSet value) throws Exception {
        this.eventMessage.setUserdata(value);
    }

    public AttributeSet getMetaData() throws Exception {
        return this.eventMessage.getMetadata();
    }

    public void setMetaData(AttributeSet value) throws Exception {
        this.eventMessage.setMetadata(value);
    }

    public Event getEventMessage() throws Exception {
        return this.eventMessage;
    }

    public void setEventMessage(Event value) throws Exception {
        this.eventMessage = value;
    }

    public String getAlternateLogFilePath() throws Exception {
        return this.eventLogDirectory ;
    }
    public void setAlternateLogFilePath(String value) throws Exception {
        this.eventLogDirectory = value;
    }
}




