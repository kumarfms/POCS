/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 12-09-2016
 * Authors      : Alex Kretchetov, David Campbell, Rohan Mars, Tim Schramer
 * File         : CeersRouteTest.java - Unit Tests for CEERS Routes
 *-----------------------------------------------------------------------------
 * Revision History (Release 2.5.5)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *-----------------------------------------------------------------------------
 * -.-.-/1.0.0  | Alex Kretchetov   | Initial Create.
 *              | David Campbell    |
 *              | Rohan Mars        |
 *              | 12-09-2016        |
 *--------------|-------------------|------------------------------------------
 * 1.0.0/2.0.0  | Tim Schramer      | Major update and additions.
 *              | Rohan Mars        | Added missing CEERS API functionality
 *              | 04-13-2016        |
 *--------------|-------------------|------------------------------------------
 * 2.0.0/2.5.0  | Tim Schramer      | Robust Unit tests. Added legacy .NET
 *              | Rohan Mars        | method calls. Additional functionality
 *              | 04-13-2016        | Restructured code.
 *--------------|-------------------|------------------------------------------
 * 2.5.0/2.5.5  | Tim Schramer      | Updated tests to support AlternateLogging
 *              | 04-28-2016        | Event output option.
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common;
import com.boeing.ai.common.ceers.messages.CeersMessage;
/*---------------------------------------------------------------------------*/
import com.boeing.web.xmlns.ai.ceers.v1.Event;

import java.io.StringReader;

import java.util.Dictionary;
import java.util.Map;

import javax.transaction.TransactionManager;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.Exchange;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.test.blueprint.CamelBlueprintTestSupport;
import org.apache.camel.util.KeyValueHolder;
import org.apache.geronimo.transaction.manager.RecoverableTransactionManager;

import org.junit.Test;

import org.mockito.Mockito;

import static org.hamcrest.CoreMatchers.instanceOf;
import static org.hamcrest.Matchers.isEmptyOrNullString;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.nullValue;
/*---------------------------------------------------------------------------*/
public class CeersRouteTest extends CamelBlueprintTestSupport {
    public final String MOCK_LOCAL_ALTERNATE_QUEUE = "mock:localAlternateQueue";
    public final String MOCK_LOCAL_AUDIT_QUEUE = "mock:localAuditQueue";
    public final String MOCK_REMOTE_AUDIT_QUEUE = "mock:remoteAuditQueue";
    public final String MOCK_LOCAL_NOTIFICATION_QUEUE = "mock:localNotificationQueue";
    public final String MOCK_REMOTE_NOTIFICATION_QUEUE = "mock:remoteNotificationQueue";
    public final String MOCK_LOCAL_STATE_QUEUE = "mock:localStateQueue";
    public final String MOCK_REMOTE_STATE_QUEUE = "mock:remoteStateQueue";

    @Produce(uri="direct-vm:ceers")
    protected ProducerTemplate ceersProducer;

    @Produce(uri="direct:localAlternateQueue")
    protected ProducerTemplate alternateProducer;

    @Produce(uri="direct:localAuditQueue")
    protected ProducerTemplate auditProducer;

    @Produce(uri="direct:localNotificationQueue")
    protected ProducerTemplate notificationProducer;

    @Produce(uri="direct:localStateQueue")
    protected ProducerTemplate stateProducer;

    @Override
    protected String getBlueprintDescriptor() {
        return "/OSGI-INF/blueprint/blueprint.xml";
    }

    @SuppressWarnings("rawtypes")
    @Override
    protected void addServicesOnStartup(Map<String, KeyValueHolder<Object,Dictionary>> services) {
        TransactionManager transactionManager = Mockito.mock(TransactionManager.class);
        services.put(TransactionManager.class.getCanonicalName(), asService(transactionManager, null));

        RecoverableTransactionManager recoverableTransactionManager = Mockito.mock(RecoverableTransactionManager.class);
        services.put(RecoverableTransactionManager.class.getCanonicalName(), asService(recoverableTransactionManager, null));
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Override
    protected String useOverridePropertiesWithConfigAdmin(Dictionary props) {
        props.put("ceers.amq.brokerUrl", "vm://localhost?broker.persistent=false");
        props.put("ceers.alternate.local.endpoint", MOCK_LOCAL_ALTERNATE_QUEUE);
        props.put("ceers.alternate.local.xa.endpoint","direct:localAlternateQueue");
        props.put("ceers.audit.local.endpoint", MOCK_LOCAL_AUDIT_QUEUE);
        props.put("ceers.audit.local.xa.endpoint","direct:localAuditQueue");
        props.put("ceers.audit.remote.xa.endpoint", MOCK_REMOTE_AUDIT_QUEUE);
        props.put("ceers.notification.local.endpoint", MOCK_LOCAL_NOTIFICATION_QUEUE);
        props.put("ceers.notification.local.xa.endpoint","direct:localNotificationQueue");
        props.put("ceers.notification.remote.xa.endpoint","mock:remoteNotificationQueue");
        props.put("ceers.state.local.endpoint", MOCK_LOCAL_STATE_QUEUE);
        props.put("ceers.state.local.xa.endpoint","direct:localStateQueue");
        props.put("ceers.state.remote.xa.endpoint","mock:remoteStateQueue");
        return "ceers.properties";
    }

  /*  @Test
    public void alternateMessageRouter() throws Exception {
        String message = "<ceersEventManagerImpl><_eventType>STATE</_eventType><_stateEvent><alternateLogFilePath>target\\CeersEvents</alternateLogFilePath></_stateEvent><eventType>STATE</eventType><stateEvent></stateEvent></ceersEventManagerImpl>";
        MockEndpoint alternateEndpoint = getMockEndpoint(MOCK_LOCAL_ALTERNATE_QUEUE);
        alternateEndpoint.expectedMessageCount(1);
        alternateEndpoint.expectedBodiesReceived(message);
        MockEndpoint auditEndpoint = getMockEndpoint(MOCK_LOCAL_AUDIT_QUEUE);
        auditEndpoint.expectedMessageCount(0);
        MockEndpoint notificationEndpoint = getMockEndpoint(MOCK_LOCAL_NOTIFICATION_QUEUE);
        notificationEndpoint.expectedMessageCount(0);
        MockEndpoint stateEndpoint = getMockEndpoint(MOCK_LOCAL_STATE_QUEUE);
        stateEndpoint.expectedMessageCount(0);
        ceersProducer.sendBody(message);
        assertMockEndpointsSatisfied();
    }*/

    @Test
    public void auditMessageRouter() throws Exception {
        String message = "<ceersEventManagerImpl><auditEvent></auditEvent><eventType>AUDIT</eventType></ceersEventManagerImpl>";
        MockEndpoint alternateEndpoint = getMockEndpoint(MOCK_LOCAL_ALTERNATE_QUEUE);
        alternateEndpoint.expectedMessageCount(0);
        MockEndpoint auditEndpoint = getMockEndpoint(MOCK_LOCAL_AUDIT_QUEUE);
        auditEndpoint.expectedMessageCount(1);
        auditEndpoint.expectedBodiesReceived(message);
        MockEndpoint notificationEndpoint = getMockEndpoint(MOCK_LOCAL_NOTIFICATION_QUEUE);
        notificationEndpoint.expectedMessageCount(0);
        MockEndpoint stateEndpoint = getMockEndpoint(MOCK_LOCAL_STATE_QUEUE);
        stateEndpoint.expectedMessageCount(0);
        ceersProducer.sendBody(message);
        assertMockEndpointsSatisfied();
    }

    @Test
    public void notifactionMessageRouter() throws Exception {
        String message = "<ceersEventManagerImpl><_eventType>NOTIFICATION</_eventType><_notificationEvent></_notificationEvent><eventType>NOTIFICATION</eventType><notificationEvent></notificationEvent></ceersEventManagerImpl>";
        MockEndpoint alternateEndpoint = getMockEndpoint(MOCK_LOCAL_ALTERNATE_QUEUE);
        alternateEndpoint.expectedMessageCount(0);
        MockEndpoint auditEndpoint = getMockEndpoint(MOCK_LOCAL_AUDIT_QUEUE);
        auditEndpoint.expectedMessageCount(0);
        MockEndpoint notificationEndpoint = getMockEndpoint(MOCK_LOCAL_NOTIFICATION_QUEUE);
        notificationEndpoint.expectedMessageCount(1);
        notificationEndpoint.expectedBodiesReceived(message);
        MockEndpoint stateEndpoint = getMockEndpoint(MOCK_LOCAL_STATE_QUEUE);
        stateEndpoint.expectedMessageCount(0);
        ceersProducer.sendBody(message);
        assertMockEndpointsSatisfied();
    }

    @Test
    public void stateMessageRouter() throws Exception {
        String message = "<ceersEventManagerImpl><_eventType>STATE</_eventType><_stateEvent></_stateEvent><eventType>STATE</eventType><stateEvent></stateEvent></ceersEventManagerImpl>";
        MockEndpoint alternateEndpoint = getMockEndpoint(MOCK_LOCAL_ALTERNATE_QUEUE);
        alternateEndpoint.expectedMessageCount(0);
        MockEndpoint auditEndpoint = getMockEndpoint(MOCK_LOCAL_AUDIT_QUEUE);
        auditEndpoint.expectedMessageCount(0);
        MockEndpoint notificationEndpoint = getMockEndpoint(MOCK_LOCAL_NOTIFICATION_QUEUE);
        notificationEndpoint.expectedMessageCount(0);
        MockEndpoint stateEndpoint = getMockEndpoint(MOCK_LOCAL_STATE_QUEUE);
        stateEndpoint.expectedMessageCount(1);
        stateEndpoint.expectedBodiesReceived(message);
        ceersProducer.sendBody(message);
        assertMockEndpointsSatisfied();
    }

    @Test
    public void auditBridgeRoute() throws Exception {
        String message = "<ceersMessage>" 
        + "<eventType>AUDIT</eventType>"
        + "<auditEvent>"
        + "<applicationName>PHL_BLIS</applicationName>"
        + "<componentName>UnitTest.auditBridgeRoute</componentName>"
        + "<dataSensitivity>RESTRICT</dataSensitivity>"
        + "<globalTransactionID>4cb0797e-d12a-4adf-9365-027ac2d1f956</globalTransactionID>"
        + "<ignoreEventErrors>false</ignoreEventErrors>"
        + "<messageName>ULLSA_INVENTORY</messageName>"
        + "<timeStamp>2016-04-16T23:51:53.752-07:00</timeStamp>"
        + "<userData>'FirstName'='Tim','LastName'='Schramer'</userData>"
        + "<payloadMsgBuffer xsi:type=\"xs:string\" xmlns:xs=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">Test</payloadMsgBuffer>"
        + "<payloadMsgType>MessageExchange</payloadMsgType>"
        + "<transferType>Rcv</transferType>"
        + "</auditEvent>"
        + "</ceersMessage>";

        MockEndpoint auditEndpoint = getMockEndpoint(MOCK_REMOTE_AUDIT_QUEUE);
        auditEndpoint.expectedMessageCount(1);
        auditProducer.sendBody(message);
        assertMockEndpointsSatisfied();

        /*Exchange exchange = auditEndpoint.getExchanges().get(0);
        assertThat("String class expected",exchange.getIn().getBody(), instanceOf(CeersMessage.class));
        CeersMessage ceersMessage = (CeersMessage)exchange.getIn().getBody();
        System.out.println("%%%Payload%%%   "+ceersMessage.toString());*/
        
        Exchange exchange = auditEndpoint.getExchanges().get(0);
        assertThat("String class expected",exchange.getIn().getBody(), instanceOf(String.class));
        String payload = (String)exchange.getIn().getBody();
        Event event = unmashall(payload);

        assertThat("EventId",event.getEventId(),not(isEmptyOrNullString()));
        assertThat("EventGroup",event.getEventGroup(),not(isEmptyOrNullString()));
        assertThat("DataSensitivity",event.getDataSensitivity(),not(isEmptyOrNullString()));
        assertThat("EventTimestsamp",event.getEventTimestamp(),not(nullValue()));
        assertThat("GlobalTxId",event.getGlobalTxId(),not(isEmptyOrNullString()));
        assertThat("ServerName",event.getServerName(),not(isEmptyOrNullString()));
        assertThat("EnvironmentName",event.getEnvironmentName(),not(isEmptyOrNullString()));
        assertThat("ComponentName",event.getComponentName(),not(isEmptyOrNullString()));

        assertEquals("Application Name","PHL_BLIS",event.getApplicationName());
        assertEquals("Message Name","ULLSA_INVENTORY",event.getMessageName());
        assertEquals("Transfer Type","RCV",event.getEventData().getAudit().getTransferType());

        assertEquals("Payload","Test",event.getEventData().getAudit().getPayload().getContent().getMessageBody().getTextContent());
///        assertEquals("Payload","<![CDATA[Test]]>",event.getEventData().getAudit().getPayload().getContent().getMessageBody().getTextContent());
    }

    /*@Test
    public void stateBridgeRoute() throws Exception {
        String message = "<ceersEventManagerImpl>"
        + "<_eventType>STATE</_eventType>"
        + "<_stateEvent>"
        + "<applicationName>PHL_BLIS</applicationName>"
        + "<componentName>UnitTest.stateBridgeRoute</componentName>"
        + "<dataSensitivity>RESTRICT</dataSensitivity>"
        + "<disableLogging>false</disableLogging>"
        + "<environmentName>UNKNOWN DEV</environmentName>"
        + "<eventGroupName>NotSpecified</eventGroupName>"
        + "<globalTransactionID>4cb0797e-d12a-4adf-9365-027ac2d1f956</globalTransactionID>"
        + "<messageName>ULLSA_INVENTORY</messageName>"
        + "<ignoreEventErrors>false</ignoreEventErrors>"
        + "<metaData>'CamelToEndpoint'='ceers://?applicationName=PHL_BLIS&amp;eventType=state','breadcrumbId'='ID-A5273963-61191-1461632532575-1-1'</metaData>"
        + "<timeStamp>2016-04-25T18:02:13.792-07:00</timeStamp>"
        + "<transactionState>Started</transactionState>"
        + "</_stateEvent>"
        + "<eventType>STATE</eventType>"
        + "<stateEvent>"
        + "<applicationName>PHL_BLIS</applicationName>"
        + "<componentName>UnitTest.stateBridgeRoute</componentName>"
        + "<dataSensitivity>RESTRICT</dataSensitivity>"
        + "<disableLogging>false</disableLogging>"
        + "<environmentName>UNKNOWN DEV</environmentName>"
        + "<eventGroupName>NotSpecified</eventGroupName>"
        + "<globalTransactionID>4cb0797e-d12a-4adf-9365-027ac2d1f956</globalTransactionID>"
        + "<messageName>ULLSA_INVENTORY</messageName>"
        + "<ignoreEventErrors>false</ignoreEventErrors>"
        + "<metaData>'CamelToEndpoint'='ceers://?applicationName=PHL_BLIS&amp;eventType=state','breadcrumbId'='ID-A5273963-61191-1461632532575-1-1'</metaData>"
        + "<timeStamp>2016-04-25T18:02:13.792-07:00</timeStamp>"
        + "<transactionState>Started</transactionState>"
        + "</stateEvent>"
        + "</ceersEventManagerImpl>";

        MockEndpoint stateEndpoint = getMockEndpoint(MOCK_REMOTE_STATE_QUEUE);
        stateEndpoint.expectedMessageCount(1);
        stateProducer.sendBody(message);
        assertMockEndpointsSatisfied();

        Exchange exchange = stateEndpoint.getExchanges().get(0);
        assertThat("String class expected",exchange.getIn().getBody(), instanceOf(String.class));
        String payload = (String)exchange.getIn().getBody();
        Event event = unmashall(payload);

        assertThat("EventId",event.getEventId(),not(isEmptyOrNullString()));
        assertThat("EventGroup",event.getEventGroup(),not(isEmptyOrNullString()));
        assertThat("DataSensitivity",event.getDataSensitivity(),not(isEmptyOrNullString()));
        assertThat("EventTimestsamp",event.getEventTimestamp(),not(nullValue()));
        assertThat("GlobalTxId",event.getGlobalTxId(),not(isEmptyOrNullString()));
        assertThat("ServerName",event.getServerName(),not(isEmptyOrNullString()));
        assertThat("EnvironmentName",event.getEnvironmentName(),not(isEmptyOrNullString()));
        assertThat("ComponentName",event.getComponentName(),not(isEmptyOrNullString()));

        assertEquals("Application Name","PHL_BLIS",event.getApplicationName());
        assertEquals("Message Name","ULLSA_INVENTORY",event.getMessageName());
        assertEquals("Transaction State","STARTED",event.getEventData().getState().getTransactionState());
    }

    @Test
    public void notificationBridgeRoute() throws Exception {
        String message = "<ceersEventManagerImpl>"
        + "<_eventType>NOTIFICATION</_eventType>"
        + "<_notificationEvent>"
        + "<applicationName>PHL_BLIS</applicationName>"
        + "<componentName>UnitTest.notificationBridgeRoute</componentName>"
        + "<dataSensitivity>RESTRICT</dataSensitivity>"
        + "<globalTransactionID>4cb0797e-d12a-4adf-9365-027ac2d1f956</globalTransactionID>"
        + "<ignoreEventErrors>false</ignoreEventErrors>"
        + "<messageName>ULLSA_INVENTORY</messageName>"
        + "<timeStamp>2016-04-16T23:51:53.752-07:00</timeStamp>"
        + "<userData>'FirstName'='Tim','LastName'='Schramer'</userData>"
        + "<payloadMsgBuffer xsi:type=\"xs:string\" xmlns:xs=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">Test</payloadMsgBuffer>"
        + "<payloadMsgType>MessageExchange</payloadMsgType>"
        + "</_notificationEvent>"
        + "<eventType>NOTIFICATION</eventType>"
        + "<notificationEvent>"
        + "<applicationName>PHL_BLIS</applicationName>"
        + "<componentName>UnitTest.notificationBridgeRoute</componentName>"
        + "<dataSensitivity>RESTRICT</dataSensitivity>"
        + "<globalTransactionID>4cb0797e-d12a-4adf-9365-027ac2d1f956</globalTransactionID>"
        + "<ignoreEventErrors>false</ignoreEventErrors>"
        + "<messageName>ULLSA_INVENTORY</messageName>"
        + "<timeStamp>2016-04-16T23:51:53.752-07:00</timeStamp>"
        + "<userData>'FirstName'='Tim','LastName'='Schramer'</userData>"
        + "<payloadMsgBuffer xsi:type=\"xs:string\" xmlns:xs=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">Test</payloadMsgBuffer>"
        + "<payloadMsgType>MessageExchange</payloadMsgType>"
        + "</notificationEvent>"
        + "</ceersEventManagerImpl>";

        MockEndpoint notificationEndpoint = getMockEndpoint(MOCK_REMOTE_NOTIFICATION_QUEUE);
        notificationEndpoint.expectedMessageCount(1);
        notificationProducer.sendBody(message);
        assertMockEndpointsSatisfied();

        Exchange exchange = notificationEndpoint.getExchanges().get(0);
        assertThat("String class expected",exchange.getIn().getBody(), instanceOf(String.class));
        String payload = (String)exchange.getIn().getBody();
        Event event = unmashall(payload);

        assertThat("EventId",event.getEventId(),not(isEmptyOrNullString()));
        assertThat("EventGroup",event.getEventGroup(),not(isEmptyOrNullString()));
        assertThat("DataSensitivity",event.getDataSensitivity(),not(isEmptyOrNullString()));
        assertThat("EventTimestsamp",event.getEventTimestamp(),not(nullValue()));
        assertThat("GlobalTxId",event.getGlobalTxId(),not(isEmptyOrNullString()));
        assertThat("ServerName",event.getServerName(),not(isEmptyOrNullString()));
        assertThat("EnvironmentName",event.getEnvironmentName(),not(isEmptyOrNullString()));
        assertThat("ComponentName",event.getComponentName(),not(isEmptyOrNullString()));
        assertThat("Userdata",event.getUserdata(),not(nullValue()));

        assertEquals("Application Name","PHL_BLIS",event.getApplicationName());
        assertEquals("Message Name","ULLSA_INVENTORY",event.getMessageName());
        assertEquals("Payload","Test",event.getEventData().getNotification().getPayload().getContent().getMessageBody().getTextContent());
//        assertEquals("Payload","<![CDATA[Test]]>",event.getEventData().getNotification().getPayload().getContent().getMessageBody().getTextContent());
    }*/

    private Event unmashall(String payload) throws JAXBException {
        JAXBContext jaxbContext = JAXBContext.newInstance(Event.class);
        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
        StringReader reader = new StringReader(payload);
        return (Event)unmarshaller.unmarshal(reader);
    }
}


