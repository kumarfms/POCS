package xsql.jdbc;

import java.util.Iterator;
import java.util.List;

import xsql.expr.RecordValue;
import xsql.impl.Parameter;

public class StoredProcResult extends RecordValue
{
   private static String returnValueFieldName = "returnValue";
   private String recordSetName;
   private RecordSet recordSet = null;
   private RecordValue args = new RecordValue ();

   public StoredProcResult (List parameters)
   {
      for (Iterator i = parameters.iterator (); i.hasNext (); )
      {
         Parameter p = (Parameter) i.next (); 
         if (p.name == null)
         {
            setFieldValue (returnValueFieldName, null);
         }
         else
         {
            setFieldValue (p.name, null);
         }
      } 
   }

   public void setReturnValue (String name, Object value)
   {
      if (name == null)
         setFieldValue (returnValueFieldName, value);
      else
         setFieldValue (name, value);
   }
   
   public void setUpdateCount (String name, Object value)
   {
      if (name == null)
         setFieldValue ("updateCount", value);
      else
         setFieldValue (name, value);
   }


   public void setRecordSet (RecordSet recordSet)
   {
      this.recordSet = recordSet;
      setFieldValue (recordSet.getName (), recordSet);
   }


   public RecordSet getRecordSet ()
   {
      return recordSet;
   }
   
   public static String getReturnValueFieldName ()
   {
       return returnValueFieldName;
   }
}
