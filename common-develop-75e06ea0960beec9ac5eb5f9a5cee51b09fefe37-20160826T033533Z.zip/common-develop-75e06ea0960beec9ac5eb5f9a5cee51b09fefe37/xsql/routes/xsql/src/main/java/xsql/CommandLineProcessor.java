package xsql;

import org.w3c.dom.*;
import org.xml.sax.*;
import javax.xml.parsers.*;

import java.util.*;
import java.io.*;
import java.sql.Connection;
import java.sql.SQLException;
import xsql.util.*;
import xsql.jdbc.*;

/**
 * This class provides a command line interface to the XSQL Processor.
 */
public class CommandLineProcessor
{
   private static boolean valid = true;
   private static String inputFileName = null;
   private static String outputFileName = null;

   private static String dbtype = null;
   private static String dburl = null;
   private static String dbhost = null;
   private static String dbport = null;
   private static String dbsid = null;
   private static String dbuser = null;
   private static String dbpwd = null;
   private static String dbserviceName = null;

   private static String logLevel = null;
   private static Connection conn = null;
   private static LinkedList variableList = new LinkedList();
   private static XSQLDataSource xds = null;
   private static boolean generateProcDefs = false;
   private static boolean includeSchemaInDefName = false;
   private static String procSchemaPattern = null;
   private static String procNamePattern = null;
   private static String procDictPath = null;


   public static void main (String args[])
   throws Exception
   {     
      valid = processOptions (args);

      if (!valid) return;
 
      printDependencyReport ();
      
      XSQLProcessor processor = new XSQLProcessor ();

      try
      {
         if (variableList.size() > 0)
         {
            for (Iterator i = variableList.iterator (); i.hasNext();)
            {
               String [] variable = (String []) i.next();
               processor.setVariable (variable[0], variable[1]);
            }
         }

         if (logLevel != null)
         {
            int level = Integer.parseInt (logLevel);
            processor.setLogLevel (level);
         }

         if (xds != null)
         {
            conn = xds.getConnection ();
            conn.setAutoCommit (false);
            processor.setDefaultConnection (xds.getName (), conn);
            info ("Database connection established.");
         }

         if (procDictPath != null)
         {
            processor.setProcDictPath (procDictPath);
         }


         if (generateProcDefs)
         {
            processor.generateProcDefs (procNamePattern, procSchemaPattern, includeSchemaInDefName);
         }
         else
         {
            processor.execute (getInputStream ());            
            if (processor.containsDocument ())
            {
               processor.printDocument ();

               if (outputFileName != null)
               {
                  OutputStream output =
                     new FileOutputStream (outputFileName);
                  processor.writeDocument (output);
                  output.close ();
               }
            }

            if (conn != null)
            {
               conn.commit ();
            }

            info ("Input file successfully executed.");
         }
      }
      catch (XSQLCompileTimeException e)
      {
         System.err.println (e.getMessage ());
         List errors = e.getErrors ();
         for (Iterator i = errors.iterator (); i.hasNext ();)
         {
            String message = (String) i.next ();
            System.err.println (message);
         }
         printOutRootCause (e);
         DBUtil.rollback (conn);
      }
      catch (XSQLRuntimeException e)
      {
         String errorMessage =
           "Error executing line " + e.getLine () + ": " + e.getMessage ();
         System.err.println (errorMessage);
         printOutRootCause (e);
         DBUtil.rollback (conn);
      }
      catch (SQLException e)
      {
         System.err.println ("Database error: " + e.getMessage ());
         printOutRootCause (e);
         DBUtil.rollback (conn);
      }
      catch (Exception e)
      {
         e.printStackTrace (System.err);
         DBUtil.rollback (conn);
      } 
      finally
      {
         DBUtil.closeConnection (conn);
      }
   }

   private static void printOutRootCause (Throwable ex)
   {
      Throwable cause = ex.getCause ();
      if (cause != null)
      {
         System.err.println("Cause:\n");
         cause.printStackTrace (System.err);
      }
   }
   
   
   private static XSQLDataSource getDataSource ()
   {
      if (dbtype == null) return null;
      
      if ("db2".equalsIgnoreCase (dbtype))
         xds = new XSQLDB2DataSource ();   
      else if ("oracle".equalsIgnoreCase (dbtype))
      {
         xds = new XSQLOracleDataSource ();
         if (dbserviceName != null)
         {
            XSQLOracleDataSource ods = (XSQLOracleDataSource) xds;
            ods.setServiceName (dbserviceName);
         }
      }
      else if ("SQLServer".equalsIgnoreCase (dbtype))
         xds = new XSQLSqlServerDataSource ();
      else if ("Teradata".equalsIgnoreCase (dbtype))
         xds = new XSQLTeraDataSource (); 
      
      xds.setUser (dbuser);
      xds.setPwd (dbpwd);
      xds.setSid (dbsid);
      xds.setPort (dbport);
      xds.setHost (dbhost);
      xds.setJDBCUrl (dburl);
      
      return xds;
   }


   private static InputStream getInputStream ()
   throws Exception
   {
      InputStream input = System.in;
      if (inputFileName != null)
      {
         input = new FileInputStream (inputFileName);
      }
      return input;
   }


   private static boolean processOptions (String args [])
   throws Exception
   {
      XSQLDataSource xds = null;
      boolean valid = true;

      int i = 0;
      while (valid && i < args.length)
      {
         if (args [i].equals ("-spec"))
         {
            i += 1;
            if (i < args.length)
               inputFileName = args [i];
            else
               valid = false;
         }
         else if (args [i].equals ("-dbtype"))
         {
            i += 1;
            if (i < args.length)
               dbtype = args [i];
            else
               valid = false;
         }
         else if (args [i].equals ("-dburl"))
         {
            i += 1;
            if (i < args.length)
               dburl = args [i];
            else
               valid = false;
         }
         else if (args [i].equals ("-dbhost"))
         {
            i += 1;
            if (i < args.length)
               dbhost = args [i];
            else
               valid = false;
         }
         else if (args [i].equals ("-dbport"))
         {
            i += 1;
            if (i < args.length)
               dbport = args [i];
            else
               valid = false;
         }
         else if (args [i].equals ("-dbsid"))
         {
            i += 1;
            if (i < args.length)
               dbsid = args [i];
            else
               valid = false;
         }
         else if (args [i].equals ("-dbuser"))
         {
            i += 1;
            if (i < args.length)
               dbuser = args [i];
            else
               valid = false;
         }
         else if (args [i].equals ("-dbpwd"))
         {
            i += 1;
            if (i < args.length)
               dbpwd = args [i];
            else
               valid = false;
         }
         else if (args [i].equals ("-dbserviceName"))
         {
            i += 1;
            if (i < args.length)
               dbserviceName = args [i];
            else
               valid = false;
         }
         else if (args [i].equals ("-output"))
         {
            i += 1;
            if (i < args.length)
               outputFileName = args [i];
            else
               valid = false;
         }
         else if (args [i].equals ("-logLevel"))
         {
            i += 1;
            if (i < args.length)
               logLevel = args [i];
            else
               valid = false;
         }
         else if (args [i].equals ("-variableName"))
         {
            i += 1;
            if (i < args.length)
            {
               String [] variable = new String[2];
               variable[0] = args [i];
               variableList.add(variable);
            }
            else
               valid = false;
         }
         else if (args [i].equals ("-variableValue"))
         {
            i += 1;
            if (i < args.length)
            {
               try
               {
                  String [] variable = (String []) variableList.getLast ();
                  variable[1] = args [i];
               }
               catch (NoSuchElementException e)
               {
                  valid = false;
               }
            }
            else
               valid = false;
         }
         else if (args[i].equals ("-generateProcDefs"))
         {
            generateProcDefs = true;               
         }
         else if (args[i].equals ("-includeSchemaInDefName"))
         {
            includeSchemaInDefName = true;               
         }
         else if (args [i].equals ("-procDictPath"))
         {
            i += 1;
            if (i < args.length)
               procDictPath = args [i];
            else
               valid = false;
         }
         else if (args[i].equals ("-procSchemaPattern"))
         {
            i += 1;
            if (generateProcDefs)
            {
               if (i < args.length)
               {
                  procSchemaPattern = args [i];
               }
            }
            else
               valid = false; 
         }
         else if (args[i].equals ("-procNamePattern"))
         {
            i += 1;
            if (generateProcDefs)
            {
               if (i < args.length)
               {
                  procNamePattern = args [i];
               }
            }
            else
            {
               valid = false;
            }
            
         }
         else if (args [i].equals ("-usage"))
         {
            i += 1;
            valid = false;
         }
         else if (!args[i].startsWith ("-"))
         {
            inputFileName = args [i];
         }
         else
         {
            System.err.println ("Invalid option: " + args [i]);
            valid = false;
         }
         i += 1;
      }
      
      if (!valid)
         usageError ();
      
      if (valid)
         valid = validateLogLevel();
      
      if (valid && dbtype != null)
      {
         valid = validateDatabaseParameters ();
      }
      
      return valid;
   }
   
   
   public static void usageError ()
   {
      String usage = 
        "Usage: xsql [-dbtype database type: db2, oracle, sqlserver, and teradata]\n" + 
        "            [-dburl database url: if used only: dbtype, dbuser and dbpwd are required]\n" +          
        "            [-dbhost database host]\n" + 
        "            [-dbport database port]\n" + 
        "            [-dbsid  database id]\n" +
        "            [-dbserviceName database service name - Oracle only]\n" + 
        "            [-dbuser database user]\n" + 
        "            [-dbpwd  database pwd]\n" + 
        "            [-logLevel  0=debug,1=info,2=warn,3=error]\n" + 
        "            [-variableName]\n" + 
        "            [-variableValue]\n" + 
        "            [-output output file name]\n" + 
        "            [-generateProcDefs]\n" + 
        "            [-procNamePattern database procedure name]\n" +
        "            [-procSchemaPattern database schema name]\n" +
        "            [-includeSchemaInDefName include schema name in generated procedure definition]\n" +
        "            [-procDictPath location of procedure definition dictionary]\n" +
        "            input file";
      info (usage);
   }


   public static void info (String message)
   {
      try
      {
         System.out.println(message);
      } 
      catch (Exception e) {}
   }

   private static boolean validateLogLevel ()
   {
      if (logLevel == null) return true;
      
      String msg = "Errors found validating logging level:\n";
      
      try
      {
         int level = Integer.parseInt(logLevel);
         
         if ((level < 0) || (level > 3))
            throw new IllegalArgumentException ();
         
         return true;
      }
      catch (Exception e)
      {
         msg += "-logLevel must be an integer between 0 and 3";
         info (msg);
         return false;
      }
      
   }
   
   private static boolean validateDatabaseParameters ()
   {
      String msg = "Errors found validating database parameters:\n";

      boolean valid = (      "db2".equalsIgnoreCase(dbtype) ||
                          "Oracle".equalsIgnoreCase(dbtype) ||
                       "SQLServer".equalsIgnoreCase(dbtype) || 
                        "Teradata".equalsIgnoreCase(dbtype));
      
      if (!valid)
      {
         msg += "-dbtype must be one of the following: DB2, Oracle, SqlServer, and " +
                "Teradata.";
         info (msg);
         return valid;
      }
      
      if (dburl != null)
      {
         xds = getDataSource ();
         return valid;
      }
      
      valid = dbhost != null;
      
      if (!valid)
      {
         msg += "-dbhost cannot be null.";
         info (msg);
         return valid;
      }
      
      valid = dbport != null;
      
      if (!valid)
      {
         msg += "-dbport cannot be null.";
         info (msg);
         return valid;
      }
      
      try
      {
         int port = Integer.parseInt (dbport);
      }
      catch (Exception e)
      {
         valid = false;
         msg += "-dbport must be an integer.";
         info (msg);
         return valid;
      }
      
      if (dbserviceName == null)
      {
         valid = dbsid != null;

         if (!valid)
         {
            msg += "-dbsid cannot be null.";
            info (msg);
            return valid;
         }
      }
      
      if (dbsid == null)
      {
         valid = dbserviceName != null;

         if (!valid)
         {
            msg += "-dbserviceName cannot be null.";
            info (msg);
            return valid;
         }
      }      
      
      valid = dbuser != null;
      
      if (!valid)
      {
         msg += "-dbuser cannot be null.";
         info (msg);
         return valid;
      }
      
      valid = dbpwd != null;
      
      if (!valid)
      {
         msg += "-dbpwd cannot be null.";
         info (msg);
         return valid;
      }
      
      if (valid)
         xds = getDataSource ();
      
      return valid;
   }
   
   private static void printDependencyReport ()
   { 
      info ("Running XSQL with the following dependent versions:");
      info (org.apache.xerces.impl.Version.getVersion ());
   }
}
