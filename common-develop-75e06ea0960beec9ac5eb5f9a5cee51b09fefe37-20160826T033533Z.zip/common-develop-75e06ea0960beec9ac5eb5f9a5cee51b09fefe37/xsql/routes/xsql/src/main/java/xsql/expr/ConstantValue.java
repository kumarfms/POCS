package xsql.expr;

public class ConstantValue extends Node
{
   Object value;

   public ConstantValue (ExpressionContext context, Object value)
   throws Exception
   {
      super (context);
      this.value = value;
   }

   public Object eval ()
   throws Exception
   {
      return value;
   }
}
