package xsql.ast;

import java.util.*;
import java.io.*;


/**
A <i>call nwp-api statement</i> invokes the execution of a NWP API. The call
specifies the association of arguments with the formal parameters
of the API.
*/
abstract public class NWPCall extends XSQLStatement
implements Serializable
{
   /**
   * The name of NWP call statement. If this attribute is specified,
   * a variable with the same name will be set to result of the
   * call. This variable can then be used to access the return value
   * and the out parameters.
   */
   public String  name;
   /**
   * The name of the package that contains the NWP API.
   */
   public String  packageName;
   /**
   * The name of the NWP-API Oracle procedure to call.
   */
   public String  procedureName;
   /**
   * The arguments to call the API with.
   */
   public List  args = new LinkedList ();


}
