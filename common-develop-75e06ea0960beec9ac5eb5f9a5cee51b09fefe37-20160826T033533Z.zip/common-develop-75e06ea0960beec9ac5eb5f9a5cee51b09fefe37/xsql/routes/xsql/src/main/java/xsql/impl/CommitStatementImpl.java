package xsql.impl;

import xsql.*;
import xsql.ast.*;
import xsql.util.*;
import xsql.expr.*;
  
import java.sql.*;

public class CommitStatementImpl extends CommitStatement
{ 
   public void execute (StatementContext context)
   throws Exception
   {
      Connection dbConn = context.getDefaultConnection ();
      if (dbConn == null) return;
      dbConn.commit ();
   }
}
