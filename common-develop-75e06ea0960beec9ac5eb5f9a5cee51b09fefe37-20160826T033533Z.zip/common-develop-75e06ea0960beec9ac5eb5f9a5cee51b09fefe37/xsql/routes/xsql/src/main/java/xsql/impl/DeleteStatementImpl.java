package xsql.impl;
 
public class DeleteStatementImpl extends NonSelectStatementImpl
{ 
}