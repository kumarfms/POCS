package xsql.ast;

import java.util.*;
import java.io.*;


/**
A <i>set statement</i> assigns a variable the value of an expression.
<p>
The value of the variable may be given as either
an <code>expr</code> attribute,
a <code>value</code> attribute,
an <code>&lt;expr&gt;</code> element,
or a <code>&lt;value&gt;</code> element.
Only one of the four forms of a value can be specified.
If none of the above forms are specified, then the variable is
assigned the value <code>null</code>.
*/
abstract public class SetStatement extends XSQLStatement
implements Serializable
{
   /**
    * The name of the variable.
    */
   public String  name;
   /**
    * An attribute containing an XSQL expression. In this form the expression
    * is evaluated and the value is assigned to the variable.
    */
   public String  expr;
   /**
    * An attribute that contains a string value.
    * In this form, 
    * the value assigned is the string value of the attribute.
    * If the string value contains embedded expressions,
    * they are evaluated and substituted into the final string value.
    */
   public String  value;
   /**
    * An element containing an XSQL expression. 
    * In this form the expression
    * is evaluated and the value is assigned to the variable.
    */
   public String  longExpr;
   /**
    * An element that contains a string value.
    * In this form, 
    * the value assigned is a string containing the characters
    * between the &lt;value&gt; start and the &lt;/value&gt; end tag.
    * If the string contains embedded expressions,
    * they are evaluated and substituted into the final string value.
    */
   public String  longValue;


}
