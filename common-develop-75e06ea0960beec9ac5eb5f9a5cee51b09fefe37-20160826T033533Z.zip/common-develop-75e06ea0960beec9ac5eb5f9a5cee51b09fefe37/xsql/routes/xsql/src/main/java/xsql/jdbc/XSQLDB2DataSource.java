package xsql.jdbc;

import com.ibm.db2.jcc.DB2Driver;

import java.io.*;
import java.sql.*;
import java.util.logging.Logger;

import com.ibm.db2.jcc.DB2DataSource;

/** 
 *  Encapsulates the specific data and behavior for connecting to an IBM DB2
 *  database via JDBC.
 */
public class XSQLDB2DataSource extends XSQLDataSource
implements Serializable
{
   private DB2DataSource ds = null;
   
   public XSQLDB2DataSource () 
   {
   }
   
   public XSQLDB2DataSource (String name, Connection conn)
   {
      super(name, conn);
   }
   
   public boolean equals (Object obj)
   {
      if (!super.equals (obj))
      {
         return false;
      }
      if (obj == null) return false;
      if (!(obj instanceof XSQLDB2DataSource)) return false;

      XSQLDB2DataSource obj1 = (XSQLDB2DataSource) obj;
      return true;
   }


   public String getJDBCUrl ()
   throws SQLException
   {
      if (url == null)
      {
         url = "jdbc:db2://" + getHost() + ":"
                             + getPort() + "/"
                             + getSid();
      }
      return url;
   }

   /**
    * Returns the port to the jdbc datasource
    */
   public int getPort ()
   throws SQLException
   {
      try
      {
         if (port == null)
            return 49186;
         else
            return Integer.parseInt (port);
      }
      catch (Exception e)
      {
         String errMsg = "Unable to get port number.";
         throw new SQLException(errMsg);
      }
   } 

   
   public Connection getConnection()
   throws SQLException
   {
      if (conn != null)
         return conn;
      
      if (url == null)
         return getConnectionFromDataSource ();
      else
         return getConnectionFromDriver ();
   }
   
   protected Connection getConnectionFromDataSource ()
   throws SQLException
   {
      if (ds == null)
         ds = new DB2DataSource ();
      
      ds.setDriverType (4);
      ds.setDatabaseName (getSid ());
      ds.setLoginTimeout (getLoginTimeout ());
      ds.setServerName (getHost ());
      ds.setPortNumber (getPort ());
      ds.setUser (getUser ());
      ds.setPassword (getPwd ());
      
      return ds.getConnection ();      
   }
   
   protected Connection getConnectionFromDriver ()
   throws SQLException
   {
      DB2Driver d = new DB2Driver ();
      return d.connect (getJDBCUrl (), null);
   }

}
