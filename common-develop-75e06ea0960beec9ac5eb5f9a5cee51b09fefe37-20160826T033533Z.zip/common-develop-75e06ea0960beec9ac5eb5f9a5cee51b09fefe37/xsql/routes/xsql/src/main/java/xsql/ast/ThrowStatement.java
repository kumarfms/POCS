package xsql.ast;

import java.util.*;
import java.io.*;


/**
A <i>throw statement</i> enables the user to throw exceptions of type
XSQLUserException to the process calling the XSQLProcessor.  This is useful
for instances where stored procedures pass return codes on anomalistic behavior
versus throwing an exception up through the JDBC layer and the user needs to
abort processing.
*/
abstract public class ThrowStatement extends XSQLStatement
implements Serializable
{
   /**
    * An optional reason for the exception as an XML attribute.
    */
   public String  attrReason;
   /**
    * An optional reason for the exception as an XML element.
    */
   public String  elementReason;


}
