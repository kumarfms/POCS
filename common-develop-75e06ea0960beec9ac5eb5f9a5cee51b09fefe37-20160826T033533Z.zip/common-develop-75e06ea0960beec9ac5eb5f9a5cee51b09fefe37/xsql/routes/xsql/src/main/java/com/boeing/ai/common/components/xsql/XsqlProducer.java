package com.boeing.ai.common.components.xsql;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javax.sql.DataSource;

import org.apache.camel.Exchange;
import org.apache.camel.impl.DefaultProducer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import xsql.*;


/**
 * The Xsql producer.
 */

public class XsqlProducer extends DefaultProducer {
    private static final transient Logger LOG = LoggerFactory.getLogger(XsqlProducer.class);
    private XsqlEndpoint endpoint;
    private DataSource dataSource;
    //private XSQLProcessor xsqlProcessor;
    
    @Override
    public XsqlEndpoint getEndpoint() {
        return (XsqlEndpoint) super.getEndpoint();
    }

    public XsqlProducer(XsqlEndpoint endpoint, DataSource dataSource) {
        super(endpoint);
        this.endpoint = endpoint;
        this.dataSource = dataSource;
      //  xsqlProcessor = new XSQLProcessor();
    }

    public void process(Exchange exchange) throws Exception {
        LOG.debug(exchange.getIn().getBody().toString());
        Connection connection = null;
        XSQLProcessor xsqlProcessor = new XSQLProcessor();
		
        try {
            LOG.debug("start XsqlProducer..." + exchange.toString());
            LOG.info("start XsqlProducer..." + exchange.getIn().getMessageId());
            
            connection = dataSource.getConnection();
            xsqlProcessor.setDefaultConnection(connection);

            InputStream inputStream = exchange.getIn().getBody(InputStream.class);

            LOG.debug("before xsqlProcessor.execute...");
            xsqlProcessor.execute(inputStream);

            LOG.debug("after xsqlProcessor.execute...");

            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            xsqlProcessor.writeDocument(outputStream);
            outputStream.flush();

            LOG.debug("output from xsqlProcessor " + outputStream.toString(StandardCharsets.UTF_8.toString()));

            exchange.getIn().setBody(outputStream);
            LOG.debug("finish XsqlProducer..." + exchange.toString());
            LOG.info("finish XsqlProducer..." + exchange.getIn().getMessageId());
			xsqlProcessor = null;
        }
        catch (Exception e) {
            LOG.error(" Error in XSQL Producer" +e.getStackTrace());
            throw e;
        }
		/*finally {
            //close the connection
        	closeQuietly(connection);
        }
		*/

        LOG.debug(exchange.getIn().getBody().toString());
    }

    private void closeQuietly(Connection con) {
        if (con != null) {
            try {
                con.close();
            } catch (SQLException sqle) {
                LOG.warn("Error by closing connection: " + sqle, sqle);
            }
        }
    }


}
