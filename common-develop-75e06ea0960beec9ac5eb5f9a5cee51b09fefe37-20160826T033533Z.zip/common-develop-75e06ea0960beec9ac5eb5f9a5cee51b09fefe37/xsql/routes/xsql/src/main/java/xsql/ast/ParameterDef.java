package xsql.ast;

import java.util.*;
import java.io.*;

import org.xml.sax.Locator;

/**
A <i>parameter definition</i>defines the parameters used for calling a stored
procedure and associates a name with the definition.
*/
public class ParameterDef
implements Serializable
{
   /**
    * The location of source XML element for this object.
    */
   public transient Locator locator;
   /**
    * The position of the parameter.
    */
   public Integer  pos;
   /**
    * The name of the parameter.
    */
   public String  name;
   /**
    * The mode of the parameter.
    */
   public String  mode;
   /**
    * The JDBC type of the parameter.
    */
   public String  jdbcType;
   /**
    * The length of the parameter.
    */
   public Integer  length;
   /**
    * The scale attribute associated with the parameter.
    */
   public Integer  scale;
   /**
   *  The Java simple date format (see java.text.SimpleDateFormat) expression 
   *  that describes the input format used for specifying dates and times, and 
   *  also, the format which will be used for displaying them within the 
   *  generated XML document.
   */
   public String  simpleDateFormat;


}
