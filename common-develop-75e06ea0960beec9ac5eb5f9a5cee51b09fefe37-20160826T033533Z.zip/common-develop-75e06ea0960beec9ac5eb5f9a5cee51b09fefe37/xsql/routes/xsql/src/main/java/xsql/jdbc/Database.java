package xsql.jdbc;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.io.File;

import xsql.XSQLCompileTimeException;
import xsql.StatementContext;
import xsql.expr.RecordValue;
import xsql.impl.Argument;
import xsql.impl.CallProc;
import xsql.impl.Parameter;
import xsql.impl.StoredProcDefImpl;
import xsql.util.DBUtil;
import xsql.util.Logger;
import xsql.ast.StoredProcDefParser;
import xsql.util.ReflectionUtil;

abstract public class Database
{
   protected String name = null;
   protected Connection conn = null;
   protected ParameterManager pm = null;
   protected static Hashtable procedureCache = new Hashtable (57);
   protected StatementContext context = null;
   protected Logger logger = null;
   protected DatabaseMetaData metaData = null;

   
   public Database (StatementContext context)
   {
      this.context = context;
      name = context.getDefaultConnectionName ();
      conn = context.getDefaultConnection ();
      logger = context.getLogger ();
   }
   
   
   public void initialize ()
   throws Exception
   {
      if (pm == null)
      {
          pm = new ParameterManager (context);
      }
   }
   
   
   public ParameterManager getParameterManager ()
   {
      return pm;
   }
   
   
   public StoredProcDefImpl getStoredProcDef (String schemaName,
                                              String packageName,
                                              String procedureName,
                                              String recordSetTag,
                                              String recordTag)
   throws Exception
   {      
      String cacheKey = 
         getCacheKey (name, schemaName, packageName, procedureName);
      
      StoredProcDefImpl def = (StoredProcDefImpl) procedureCache.get (cacheKey);
            
      if (def == null)
      {
         def = getProcDefFromDict (schemaName,
                                   packageName,
                                   procedureName);
      }
      
      if (def == null)
      {
         def = getProcDefFromDatabase (schemaName, 
                                       packageName, 
                                       procedureName, 
                                       recordSetTag,
                                       recordTag);

         procedureCache.put (cacheKey, def);
         
         if (def != null)
         {
            logger.info (this,"Obtained stored proc definition from database.");
         }
         else
         {
            logger.info (this,"Could not obtain stored proc definition from database.");
         }

         if (logger.getLevel () == logger.DEBUG)
         {
            if (def != null)
            {
               byte [] defAsByteArray = def.toXML ().getBytes ();
               logger.debug (new String (defAsByteArray, "UTF-8"));
            }
         }
      }
      return def;
   }
   
   
   private String getCacheKey (String name,
                               String schemaName,
                               String packageName,
                               String procedureName)
   {
      StringBuffer cache = new StringBuffer ();
      cache.append (name);
      cache.append (":");
      cache.append (schemaName);
      cache.append (":");
      cache.append (packageName);
      cache.append (":");
      cache.append (procedureName);
      return cache.toString ();
   }


   protected StoredProcDefImpl getProcDefFromDict (String schemaName,
                                                   String packageName,
                                                   String procedureName)
   throws Exception
   {
      List<String> procDictPath = context.getProcDictPath ();

      for (String dir: procDictPath)
      {
         StoredProcDefImpl def = null;

         String procDefFileName = getProcDictFileName (schemaName,
           packageName, procedureName, dir);
      
         File procDefFile = new File (procDefFileName);
         if (procDefFile.exists () && procDefFile.isFile ())
         {
            logger.info ("Obtained stored proc definition from file " + procDefFileName);
            def = parseStoredProcDef (procDefFileName);
            def.check (context);
            if (schemaName != null)
            {
               def.schemaName = schemaName;
            }
            return def;
         }
      }
      return null;
   }


   protected StoredProcDefImpl parseStoredProcDef (String fileName)
   throws Exception
   {
      StoredProcDefParser parser = new StoredProcDefParser ();
      try
      {
         parser.parse (fileName, false);
      }
      catch (Exception e)
      {
      }
      int numErrors = parser.getNumErrors ();
      if (numErrors != 0)
      {
         String problem =
           "Error(s) found parsing stored procedure definition in file " +
           fileName + ".";
         List errors = parser.getErrors ();
         throw new XSQLCompileTimeException (problem, errors);
      }
      Object doc = parser.getDocument ();
      if (doc == null)
      {
         String problem =
           "The stored procedure definition in file " +
           fileName + " is invalid.";
         throw new XSQLCompileTimeException (problem);
      }
      if (!(doc instanceof StoredProcDefImpl))
      {
         String problem =
           "The stored procedure definition in file " +
           fileName + " has an invalid root tag.";
         throw new XSQLCompileTimeException (problem);
      }
      return (StoredProcDefImpl) doc;
   }

   

   protected String getProcDictFileName (String schemaName,
                                         String packageName,
                                         String procedureName,
                                         String procDictPath)
   throws Exception
   {
      
      String procDefFileName = "", candidateFileName = "";
         
      if (schemaName != null)
         candidateFileName += (schemaName + "."); 
      if (packageName != null)
         candidateFileName += (packageName + ".");
      if (procedureName != null)
         candidateFileName += procedureName;
      
      procDefFileName = procDictPath + "/" + candidateFileName;
      
      return procDefFileName;

 }
   
   abstract protected StoredProcDefImpl getProcDefFromDatabase (String schemaName,
                                                                String packageName,
                                                                String procedureName,
                                                                String recordSetTag,
                                                                String recordTag)
   throws Exception;
   
   
   abstract public void generateProcDefs (String procNamePattern,
                                          String procSchemaPattern,
                                          boolean includeSchemaInDefName)
   throws Exception;
   
   private String toNullOrUpperCase (String s)
   {
      if (s == null)
         return null;
      else
         return s.toUpperCase ();
   }
   
   public RecordSet executeQuery (String sql,
                                  String recordSetName,
                                  String recordName,
                                  List args)
   throws Exception
   {
      PreparedStatement ps = null;
      ResultSet rs = null;
      try
      {
         logger.info (this,"SQL = " + sql);
         ps = conn.prepareStatement(sql);
         pm.setPreparedStatement (ps);
         setArguments (ps, args);
         rs = ps.executeQuery ();
         pm.setResultSet (rs);
         return createRecordSet (recordSetName, recordName, rs);
      }
      finally
      {
         DBUtil.closeResultSet (rs);
         DBUtil.closePreparedStatement (ps);
         pm.clear ();
      }
   }
   
   public Integer executeUpdate (String sql, List args)
   throws Exception
   {
      Integer rowsAffected = null;
      PreparedStatement ps = null;
      
      try
      {
         logger.info (this,"SQL = " + sql);
         ps = conn.prepareStatement (sql);
         pm.setPreparedStatement (ps);
         setArguments (ps, args);
         int numRows = ps.executeUpdate ();
         return new Integer (numRows);
      }
      finally
      {
         DBUtil.closePreparedStatement (ps);
         pm.clear ();
      }
   }
   
      
   protected RecordSet createRecordSet (String recordSetName,
                                        String recordTag,
                                        ResultSet rs)
   throws Exception
   {
      try
      {
         RecordSet recordSet = new RecordSet (recordSetName, recordTag);

         if (rs == null) return recordSet;

         ResultSetMetaData rsmd = rs.getMetaData ();
         RecordSetMetaData meta = getUniqueMetaData (rsmd);
         int uniqueColumnCount = meta.getColumnCount ();

         while (rs.next())
         {
            RecordValue record = new RecordValue ();

            for (int i = 0; i < uniqueColumnCount; i++) 
            {
               Parameter p = 
                  (Parameter) meta.parameters.get (i);

               Object value = pm.getParameter (p);  

               record.setFieldValue (p.name, value);
            }
            recordSet.records.add(record);
         }

         return recordSet;
      }
      finally
      {
         DBUtil.closeResultSet (rs);
      }
   }
   
   protected RecordSetMetaData getUniqueMetaData(ResultSetMetaData rsmd)
   throws Exception
   {
      String logMsg = null;
      
      HashMap uniqueColumnMap = new HashMap();

      int candidateColumnCount = rsmd.getColumnCount();
      
      RecordSetMetaData meta = new RecordSetMetaData();
      
      for (int i = 1; i <= candidateColumnCount; i++)
      {    
         String candidateColumnLabel = rsmd.getColumnLabel(i);

         if (uniqueColumnMap.containsKey(candidateColumnLabel)) continue;

         Parameter p = new Parameter ();
         p.name = candidateColumnLabel;
         p.dbTypeName = rsmd.getColumnTypeName(i);
         p.pos = new Integer (i);
         p.sqlType = rsmd.getColumnType (i);
         p.jdbcType = pm.getJDBCTypeFromSqlType (p.sqlType);
         p.definedFromDatabase = true;
         p.isOutParameter = true;
         logger.debug (this, ReflectionUtil.toString (p));
         meta.parameters.add (p);
         uniqueColumnMap.put(candidateColumnLabel, null);
      }
      
      return meta;
   }
   
   public StoredProcResult makeCall (CallProc cp)
   throws Exception
   {
      StoredProcResult result = null;
      String logMsg = null;
      ResultSet rs = null;
      CallableStatement cs = null;
      RecordSet recordSet = null;
      
      try
      {
         result = new StoredProcResult (cp.getParameterList ());
         
         String sql = cp.getSQL ();  

         logMsg = "SQL = " + sql;

         logger.info (this, logMsg);

         cs = conn.prepareCall (sql);

         setParameters (cp, cs, result);
         
         invoke (cp, cs, result);
         
         setOutParametersInResult (cp, cs, result);
         
         return result;
      }
      finally
      {
         DBUtil.closeResultSet(rs);
         DBUtil.closeCallableStatement(cs);
         pm.clear ();
      }
   }
   
   protected void setParameters(CallProc cp,
                                CallableStatement cs,
                                StoredProcResult result)
   throws Exception
   {
      pm.setCallableStatement (cs);
      
      Parameter returnParameter = cp.getReturnParameter ();
      
      if (returnParameter != null)
         pm.setOutParameter (returnParameter);

      List parameterList = cp.getParameterList ();

      StringBuffer parameterInfo = new StringBuffer ();
      
      boolean first = true;
      
      for (int i = 0; i < parameterList.size(); i++)
      {
         Parameter p = (Parameter) parameterList.get(i);

         if (p.isInParameter)
         {
           if (first)
              parameterInfo.append ("\n   ");
           else
              parameterInfo.append (",\n   ");
           
           Argument arg = cp.getArgument (p.name);
           
           Object value = null;
           if (arg != null)
              value = context.resolveExpressions (arg.getValue ()); 
           
           pm.setInParameter (p, arg, value);
           
           if (value != null)
           {
              parameterInfo.append (p.name + "=> " + value);
           }
           else
              parameterInfo.append (p.name + "=> null");

           if (arg != null && arg.dateType != null)
           {
              parameterInfo.append (" (date-type attribute deprecated - use jdbc-type) ");
           }
           
           first = false;
         }

         if (p.isOutParameter)
            pm.setOutParameter (p);
      }

      logger.info (this,
         "The input parameters are \n(" + parameterInfo.toString () + "\n)");

   }
   
   
   protected void invoke (CallProc cp, 
                          CallableStatement cs,
                          StoredProcResult result)
   throws Exception
   {
      String recordSetTag = cp.getRecordSetTag ();
      String recordTag = cp.getRecordTag ();
      ResultSet rs = null;
      RecordSet recordSet = null;
      boolean containsResultSet = false;
      int updateCount = 0;
         
      try
      {
      containsResultSet = cs.execute ();

      if (containsResultSet)
      {
         rs = cs.getResultSet ();
         pm.setResultSet (rs);
      }
      else
      {
         updateCount = cs.getUpdateCount ();
         result.setUpdateCount (null, new Integer (updateCount));
      }
      /* This is placed here as subsequent statements may wish to 
       * test the length of the record set obtain from executing the
       * stored proc.
       */
      recordSet = createRecordSet (recordSetTag, recordTag, rs);
      result.setRecordSet (recordSet);
   }
      finally
      {
         DBUtil.closeResultSet (rs);
      }
   }
                            
   
   protected void setOutParametersInResult (CallProc cp,
                                            CallableStatement cs,
                                            StoredProcResult  result)
   throws Exception
   {
      Object value = null;
      Parameter returnParameter = cp.getReturnParameter ();
      
      pm.setCallableStatement (cs);
      
      if (returnParameter != null)
      {
         Argument arg = cp.getArgument (returnParameter.name);
         value = pm.getParameter (returnParameter, arg);
         result.setReturnValue (returnParameter.name, value);
      }
      
      List parameterList = cp.getParameterList ();
      for (Iterator i = parameterList.iterator (); i.hasNext ();)
      {
         Parameter p = (Parameter) i.next ();
         Argument arg = cp.getArgument(p.name);
         value = pm.getParameter (p, arg);
         result.setFieldValue (p.name, value);
      }
   }

   public void setArguments (PreparedStatement ps, List args)
   throws Exception
   {
      if (args.size () == 0) return;
      
      StringBuffer parameterInfo = new StringBuffer ();
      boolean first = true;
      for (int i = 0; i < args.size (); i++)
      {
         Argument arg = (Argument) args.get (i);

         Object value = null;

         if (arg != null)
            value = context.resolveExpressions (arg.getValue ());

         Parameter p = new Parameter ();
         p.jdbcType = arg.getJDBCType ();
         p.sqlType = pm.getSQLTypeFromJDBCType (p.jdbcType);
         p.name = arg.getName ();
         p.dbTypeName = null;
         p.pos = arg.pos;
         p.definedFromDatabase = false;
         p.isInParameter = true;
         p.isOutParameter = false;
         p.simpleDateFormat = arg.getSimpleDateFormat ();

         if (first)
            parameterInfo.append ("\n   ");
         else
            parameterInfo.append (",\n   ");

         pm.setInParameter (p, arg, value);

         if (value != null)
         {
            parameterInfo.append (p.name + "=> " + value);
         }
         else
            parameterInfo.append (p.name + "=> null");

         if (arg != null && arg.dateType != null)
         {
            parameterInfo.append (" (date-type attribute deprecated - use jdbc-type) ");
         }
      }

      logger.info (this,
         "The input parameters are \n(" + parameterInfo.toString () + "\n)");
   }
}
