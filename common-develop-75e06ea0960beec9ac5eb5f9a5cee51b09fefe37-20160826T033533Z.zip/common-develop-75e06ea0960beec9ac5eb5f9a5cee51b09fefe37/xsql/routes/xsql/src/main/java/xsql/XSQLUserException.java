package xsql;

import java.util.*;
import java.io.*;
import xsql.ast.*;
import xsql.expr.*;


public class XSQLUserException extends XSQLRuntimeException
{

   public XSQLUserException (Throwable cause)
   {
      super (cause.getMessage (), cause);
   }


   public XSQLUserException (String message)
   {
      super (message);
   }


   public XSQLUserException (String message, Throwable cause)
   {
      super (message, cause);
   }
}
