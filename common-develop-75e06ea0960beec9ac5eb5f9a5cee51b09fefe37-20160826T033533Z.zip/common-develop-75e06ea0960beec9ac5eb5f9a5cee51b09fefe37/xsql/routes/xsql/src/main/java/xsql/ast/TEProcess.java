package xsql.ast;

import java.util.*;
import java.io.*;


/**
A TE process is used to represent the beginning and end of a
sequence of TE calls.
The TE process maintains the status of the TE calls inside the
TE process by checking return codes.
The TE process also handles the decision of whether or not
to commit or rollback all TEs called inside the TE process.
For example, while executing a statement list,
if one or more te calls are made and complete without error the
TE process will issue a syncCommit call.
However, if one or more TE calls are made and an error occurs,
the TE process will issue a syncRollback.
<p>
The only required attribute on the TE process is
<i>name</i>, which is currently unused,
but is to be incorporated into a future version of XSQL
*/
abstract public class TEProcess extends XSQLStatement
implements Serializable
{
   /**
    * Defines the name of the TE process.
    */
   public String  name;
   /**
    * Defines the schema the TE process runs in. If the schema is not
    * specified, the TE process will run in the schema whose name
    * is established by the XSQL runtime environment.
    */
   public String  schema;
   /**
    * Defines a list of XSQL statements to be executed as part
    * of a TE process.
    */
   public List  statementList = new LinkedList ();


}
