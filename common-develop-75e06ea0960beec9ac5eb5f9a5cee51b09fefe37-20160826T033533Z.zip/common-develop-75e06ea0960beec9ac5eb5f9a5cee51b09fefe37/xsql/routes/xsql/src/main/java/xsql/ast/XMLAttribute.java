package xsql.ast;

import java.util.*;
import java.io.*;

import org.xml.sax.Locator;

/**
An <i>XML attribute statement</i> adds an attribute to an XML element.
See XMLElementStatement (xml).
*/
public class XMLAttribute
implements Serializable
{
   /**
    * The location of source XML element for this object.
    */
   public transient Locator locator;
   /**
    * The tag for the attribute to be added.
    */
   public String  name;
   /**
    * The text contents of the attribute.
    */
   public String  value;


}
