package xsql.expr;

import java.util.*;

public class SymbolTable
{
   private List tables;
   private HashMap globals;


   public SymbolTable ()
   {
      tables = new LinkedList ();
      globals = new HashMap ();
      tables.add (0, globals);
   }


   public void beginScope ()
   {
      HashMap table = new HashMap ();
      tables.add (0, table);
   }


   public void endScope ()
   {
      tables.remove (0);
   }


   public void addGlobal (String name, Object value)
   {
      globals.put (name, value);
   }


   public Object lookupGlobal (String name)
   {
      return globals.get (name);
   }


   public void add (String name, Object value)
   {
      HashMap table = (HashMap) tables.get (0);
      table.put (name, value);
   }


   public boolean set (String name, Object value)
   {
      for (Iterator i = tables.iterator (); i.hasNext (); )
      {
         HashMap table = (HashMap) i.next ();
         if (table.containsKey (name))
         {
            table.put (name, value);
            return true;
         }
      }
      return false;
   }


   public boolean symbolExistsInCurrentScope (String name)
   {
      HashMap table = (HashMap) tables.get (0);
      return table.containsKey (name);
   }


   public boolean symbolExists (String name)
   {
      for (Iterator i = tables.iterator (); i.hasNext (); )
      {
         HashMap table = (HashMap) i.next ();
         if (table.containsKey (name)) return true;
      }
      return false;
   }


   public Object lookup (String name)
   {
      for (Iterator i = tables.iterator (); i.hasNext (); )
      {
         HashMap table = (HashMap) i.next ();
         if (table.containsKey (name))
         {
            return table.get (name);
         }
      }
      return null;
   }
}
