package xsql.expr;

import java.io.*;
import java.util.*;


public abstract class LexAnalyzer
{

   static final int eof_sym = 0;
   static final int invalid_sym = 1;
   static final int identifier_sym = 2;
   static final int number_sym = 3;
   static final int string_sym = 4;
   static final int text_block_sym = 5;
   static final int comment_sym = 6;

   abstract String[] getSpecialSyms (); // The token value of a special symbol
                                        // is its index in array + 1000.
   abstract String[] getKeywords ();    // The token value of a keyword
                                        // symbol is its index in array + 2000.

   public int sym;
   public String symText;
   public StringBuffer stringValue;
   public boolean symIsRealNumber;
   public boolean unterminatedString;
   public boolean multiLineString;
   public int line;
   public int column;
   public boolean returnComments = false;

   private StringBuffer text;
   private int ch;
   private int ch_class;
   private int look_ahead;
   private int la_class;
   private int currentLine;
   private int currentColumn;
   private Reader input;
   private Hashtable keywordTable;


   public LexAnalyzer ()
   {
      text = new StringBuffer ();
      stringValue = new StringBuffer ();
      ch = ' ';
      ch_class = ' ';
      look_ahead = ' ';
      la_class = ' ';
      currentLine = 1;
      currentColumn = -1;
      initDFA ();
      initKeywordTable ();
   }


   public void setInput (Reader input)
   {
      this.input = input;
   }


   public void setInput (String input)
   {
      this.input = new StringReader (input);
   }


   // Define the character classes
   //   char classes 0 - 127 stand for the unicode chars with that value.
   //   the char class 128 stands for end of file
   //   the char class 129 stands for all characters above 127.

   private static final int cl_eof     = 128;
   private static final int cl_invalid = 129;
   private static final int NUM_CHAR_CLASSES = 130;

 
   private class State
   {
      int tokenValue;
      int adjust_cc;

      State (int tokenValue, int adjust_cc)
      {
         this.tokenValue = tokenValue; this.adjust_cc = adjust_cc;
      }
   }

   private State stateTable[][];


   private void initDFA ()
   {
      String [] specialSyms = getSpecialSyms ();
      State s;

      stateTable = new State [NUM_CHAR_CLASSES][NUM_CHAR_CLASSES];

      s = new State (invalid_sym, 1);
      for (int r = 0; r < NUM_CHAR_CLASSES; r++)
         for (int c = 0; c < NUM_CHAR_CLASSES; c++)
            stateTable[r][c] = s;

      setRow (cl_eof, new State (eof_sym, 0));

      s = new State (identifier_sym, 0);
      for (int r = 'A'; r <= 'Z'; r++)
         setRow (r, s);
      for (int r = 'a'; r <= 'z'; r++)
         setRow (r, s);
      setRow ('_', s);

      s = new State (number_sym, 0);
      for (int r = '0'; r <= '9'; r++)
         setRow (r, s);

      setRow ('"', new State (string_sym, 0));
      setRow ('\'', new State (string_sym, 0));

      setRow ('%', new State (text_block_sym, 0));

      setEntry ('/', '/', new State (comment_sym, 0));
      setEntry ('/', '*', new State (comment_sym, 0));

      for (int i = 0; i < specialSyms.length; i++)
      {
         String sym = specialSyms [i];

         if (sym.length () == 1)
            setRow (sym.charAt (0), new State (1000 + i, 1) );
         else
            setEntry (sym.charAt (0), sym.charAt (1), new State (1000+i, 2) );
      }
   }

   private void setRow (int r, State s)
   {
      for (int c = 0; c < NUM_CHAR_CLASSES; c++)
         if (stateTable[r][c].tokenValue == invalid_sym)
            stateTable[r][c] = s;
   }


   private void setEntry (int r, int c, State s)
   {
      stateTable[r][c] = s;
   }


   private void initKeywordTable ()
   {
      String [] keywords = getKeywords ();

      keywordTable = new Hashtable ();
      for (int i = 0; i < keywords.length; i++)
         keywordTable.put (keywords [i], new Integer (2000 + i));
   }


   private void getCh () throws IOException
   {
      ch = look_ahead;
      ch_class = la_class;

      if (input == null)
         input = new BufferedReader (new InputStreamReader (System.in));

      look_ahead = input.read ();
      if (look_ahead == -1)
      {
         la_class = cl_eof;
         look_ahead = 0;
      }
      else if (look_ahead > 127)
         la_class = cl_invalid;
      else
         la_class = look_ahead;

      if (ch == '\n')
      {
         currentLine += 1;
         currentColumn = 0;
      }
      else
         currentColumn += 1;
   }


   public void getsym () throws IOException
   {
      boolean done = false;

      while (!done)
      {
         State s;

         done = true;
         text.setLength (0);
         stringValue.setLength (0);
         while (Character.isWhitespace ((char)ch))
            getCh ();
         line = currentLine;
         column = currentColumn;

         s = stateTable [ch_class][la_class];
         sym = s.tokenValue;
         if (s.adjust_cc > 0)
         {
            text.append ((char)ch);
            getCh ();
            if (s.adjust_cc > 1)
            {
               text.append ((char)ch);
               getCh ();
            }
            symText = text.toString (); 
         }
         else if (sym == identifier_sym)
         {
            identifier ();
         }
         else if (sym == number_sym)
         {
            number ();
         }
         else if (sym == string_sym)
         {
            string ();
         }
         else if (sym == text_block_sym)
         {
            text_block ();
         }
         else if (sym == comment_sym)
         {
            comment ();
            if (!returnComments)
               done = false;
         }
         else if (sym == eof_sym)
         {
            symText = "";
         }
      }
   }

   private void identifier () throws IOException
   {
      Integer value;

      while (Character.isUnicodeIdentifierPart ((char)ch) && ch != 0)
      {
         text.append ((char)ch);
         getCh ();
      }
      symText = text.toString (); 

      value = (Integer)keywordTable.get (symText);
      if (value != null)
         sym = value.intValue ();
   }


   private void string () throws IOException
   {
      int delimiter = ch;

      unterminatedString = false;
      multiLineString = false;
      text.append ((char)ch);
      getCh ();

      while (true)
      {
         if (ch == delimiter)
         {
            text.append ((char)ch);
            getCh ();
            break;
         }
         if (ch == '\\')
         {
            text.append ((char)ch);
            getCh ();
         }
         if (ch == 0)
         {
            unterminatedString = true;
            break;
         }
         if (ch == '\n')
            multiLineString = true;

         text.append ((char)ch);
         stringValue.append ((char)ch);
         getCh ();
      }
      symText = text.toString (); 
   }


   private void text_block () throws IOException
   {
      int delimiter = ch;

      unterminatedString = false;
      multiLineString = false;
      text.append ((char)ch);
      getCh ();

      while (true)
      {
         if (ch == delimiter)
         {
            text.append ((char)ch);
            getCh ();
            break;
         }
         if (ch == '\\')
         {
            text.append ((char)ch);
            getCh ();
         }
         if (ch == 0)
         {
            unterminatedString = true;
            break;
         }
         if (ch == '\n')
            multiLineString = true;

         text.append ((char)ch);
         getCh ();
      }
      symText = text.toString (); 
   }


   private void comment () throws IOException
   {
      if (ch == '/' && look_ahead == '/')
         singleLineCStyleComment ();
      else if (ch == '/' && look_ahead == '*')
         multiLineCStyleComment ();
   }


   private void singleLineCStyleComment () throws IOException
   {
      while (ch != '\n' && ch != 0)
      {
         text.append ((char)ch);
         getCh ();
      }
      getCh ();
      symText = text.toString (); 
   }


   private void multiLineCStyleComment () throws IOException
   {
      text.append ((char)ch);
      getCh ();
      text.append ((char)ch);
      getCh ();
      while (!(ch == '*' && look_ahead == '/') && ch != 0)
      {
         text.append ((char)ch);
         getCh ();
      }
      if (ch != 0)
      {
         text.append ((char)ch);
         getCh ();
         text.append ((char)ch);
         getCh ();
      }
      symText = text.toString (); 
   }


   private void getDigits () throws IOException
   {
      while (ch >= '0' && ch <= '9')
      {
         text.append ((char)ch);
         getCh ();
      }
   }

   private void number () throws IOException
   {
      symIsRealNumber = false;
      getDigits ();
      if (ch == '.' && (look_ahead >= '0' && look_ahead <= '9'))
      {
         text.append ((char)ch);
         getCh ();
         getDigits (); 
         symIsRealNumber = true;
      }
      symText = text.toString (); 
   }


   
   public void test_getsym () throws Exception
   {
      getsym ();
      while (sym != eof_sym)
      {
         System.out.println (symText + ": " + sym);
         System.out.flush ();
         getsym ();
      }
   }


/*
   public static void main (String args[]) throws Exception
   {
      class Lex extends LexAnalyzer
      {
         public String[] getSpecialSyms ()
         {
            return new String[] {"(", ")", ","};
         }
      
         public String[] getKeywords ()
         {
            return new String[]
                   {"if", "while", "public", "final", "int", "return", "new" };
         }
      }
      String in = "if (9 - 'abc') , final new ( ( 'a' \"abcde ssss\"10 he";
      in = "header.abc==2";
      Lex l = new Lex ();
      l.setInput (in);

      l.returnComments = true;
      l.test_getsym ();
   }
*/
}

