package xsql.expr;

public class InvalidTypeException extends ExpressionException
{
   public InvalidTypeException (Object value, String expectedType)
   {
      super (buildMessage (value, expectedType));
   }


   private static String buildMessage (Object value, String expectedType)
   {
      String v = value.toString ();

      if (value instanceof String)
         v = "\"" + value + "\"";

      String message = 
        "A value (" + v + ") with an incompatible type for its context "
        + "was encountered during expression evaluation. "
        + "The expected type was " + expectedType + ".";

      return message;
   }
}
