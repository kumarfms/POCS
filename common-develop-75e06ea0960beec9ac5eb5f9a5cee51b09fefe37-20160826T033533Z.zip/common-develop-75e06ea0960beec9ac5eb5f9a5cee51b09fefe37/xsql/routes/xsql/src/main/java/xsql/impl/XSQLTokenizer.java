package xsql.impl;

public class XSQLTokenizer
{
   public final static int EOS = 0;
   public final static int TEXT = 1;
   public final static int EXPR = 2;

   public int          tokenType = 0;
   public StringBuffer text = new StringBuffer ();

   private String s;
   private int    pos = 0;
   private int    ch = 0;
   private int    lookAhead = 0;

   public XSQLTokenizer (String s)
   {
      if (s == null)
         this.s = "";
      else
         this.s = s;
      getCh ();
      getCh ();
      getToken ();
   }


   private void getCh ()
   {
      ch = lookAhead;
      if (pos < s.length ())
         lookAhead = s.charAt (pos++);
      else
         lookAhead = -1;
   }


   public void getToken ()
   {
      text.setLength (0);
      
      if (ch == -1)
      {
         tokenType = EOS;
      }
      else if (ch == '{' && lookAhead == '%')
      {
         text.append ((char) ch);
         getCh ();
         text.append ((char) ch);
         getCh ();
         while (ch != -1)
         {
            if (ch == '%' && lookAhead == '}') break;
            text.append ((char) ch);
            getCh ();
         }
         if (ch != -1)
         {
            text.append ((char) ch);
            getCh ();
            text.append ((char) ch);
            getCh ();
            tokenType = EXPR;
         }
         else
            tokenType = TEXT;
      }
      else
      {
         tokenType = TEXT;
         while (ch != -1)
         {
            if (ch == '{' && lookAhead == '%') break;
            text.append ((char) ch);
            getCh ();
         }
      }
   }

   public String getText ()
   {
      return text.toString ();
   }


   public String getExpr ()
   {
      String token = text.toString ();
      return token.substring (2, token.length () - 2);
   }
}
