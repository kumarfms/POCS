package xsql.expr;

public class NameExpr extends Node
{
   public String identifier;

   public NameExpr (ExpressionContext context, String identifier)
   throws Exception
   {
      super (context);
      this.identifier = identifier;
   }


   public boolean isPackageTypeOrMethodName ()
   {
      return context.getSymbolTable ().lookup (identifier) == null;
   }


   public String getName ()
   {
      return identifier;
   }


   public Object eval ()
   throws Exception
   {
      SymbolTable symbolTable = context.getSymbolTable ();
      Object value = symbolTable.lookup (identifier);
      if (value == null)
      {
         if (symbolTable.symbolExists (identifier))
            return null;
         else if (identifier.equals ("false"))
            return new Boolean (false);
         else if (identifier.equals ("true"))
            return new Boolean (true);
         else if (identifier.equals ("null"))
            return null;
         else
            throw new UndefinedSymbolException (identifier);
      }
      return value;
   }
}
