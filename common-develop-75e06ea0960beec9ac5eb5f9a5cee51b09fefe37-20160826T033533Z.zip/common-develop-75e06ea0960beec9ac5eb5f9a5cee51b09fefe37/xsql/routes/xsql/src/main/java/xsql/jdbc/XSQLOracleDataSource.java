package xsql.jdbc;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.util.Properties;
import java.util.logging.Logger;

import oracle.jdbc.OracleDriver;

/**
 * An OracleDataSource is used to establish connections to physical data sources
 * it represents (e.g. Oracle RDBMS, SQL RDBMS, etc.)
 */
public class XSQLOracleDataSource extends XSQLDataSource 
implements Serializable 
{
   /**
    * The service name of the database.  Note that the use of sid for Oracle
    * was deprecated started with Oracle 10g.
    */
   protected String serviceName; 
   
   public XSQLOracleDataSource ()
   {
      
   }
   
   public XSQLOracleDataSource (String name, Connection conn)
   {
      super(name, conn);
   }

   /**
    * Type of driver that should be used for establishing a database connection
    * (i.e. OCI or thin the default).
    */
   public String  driverType;
   /**
   * The specific properties that may be specified during connection creation 
   * to require Oracle's thin driver to use a secure connection with the
   * database server.  This feature requires the database server to be 
   * configured to support Oracle's Advanced Security environment.
   */
   public SecureThinOracleConnectionProperties  secureProperties;


   public boolean equals (Object obj)
   {
      if (!super.equals (obj))
      {
         return false;
      }
      if (obj == null) return false;
      if (!(obj instanceof XSQLOracleDataSource)) return false;

      XSQLOracleDataSource obj1 = (XSQLOracleDataSource) obj;
      if (!fieldsMatch (driverType, obj1.driverType))
         return false;
      if (!fieldsMatch (secureProperties, obj1.secureProperties))
         return false;
      return true;
   }

   /**
   * Returns the type of JDBC driver which should be used to connect to Oracle's
   * Advanced Queueing environment.
   */
   public String getDriverType()
   {
     String driverType = null;

     if (this.driverType == null)
        driverType = "thin";
     else if ("thin".equalsIgnoreCase(this.driverType))
        driverType = "thin";
     else if ("oci".equalsIgnoreCase(this.driverType))
        driverType = "oci";         

     return driverType;
   }


   public String getJDBCUrl () throws SQLException
   {
      if (url != null) return url;
      
      if (this.serviceName != null)
      {
         url = "jdbc:oracle:" + getDriverType() + ":@//" +
                    this.host + ":" +
                    getPort() + "/" + 
                    this.serviceName;
      }
      else
      {
         url = "jdbc:oracle:" + getDriverType() + ":@" +
                    this.host + ":" +
                    getPort() + ":" + 
                    this.sid;
      }
      return url;
   }


   /**
   * Returns the port to the jdbc datasource
   */ 
   public int getPort ()  
   throws SQLException
   { 
     try
     {
        if (port == null)  
           return 1521;
        else
           return Integer.parseInt (port);
     }
     catch (Exception e)
     {
        String errMsg = "Unable to get port number.";
        throw new SQLException(errMsg);
     }
   } 

   /**
   * Gets the connection properties
   */
   public Properties getConnectionProperties()
   {
     Properties connectionProperties = new Properties();
     connectionProperties.put("user", this.getUser());
     connectionProperties.put("password", this.getPwd());

     if (this.secureProperties != null)
     {
        if ("thin".equalsIgnoreCase(getDriverType()))
           this.secureProperties.addProperties(connectionProperties);
     }

     return connectionProperties;
   }

   /**
   * Returns the connection to the database
   */
   public Connection getConnection()
   throws SQLException
   {
      if (conn != null)
         return conn;

      return getConnectionFromDriver ();

   }
   
   protected Connection getConnectionFromDriver ()
   throws SQLException
   {
      OracleDriver driver = new OracleDriver ();
      Properties props = getConnectionProperties();
      return driver.connect (getJDBCUrl(), props);       
   }
   
   public void setServiceName (String serviceName)
   {
      this.serviceName = serviceName;
   }
   
   public String getServiceName ()
   {
      return serviceName;
   }

}
