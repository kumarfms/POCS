package xsql.impl;

import xsql.*;
import xsql.ast.*;
import xsql.util.*;
import xsql.expr.*;
  
public class ImportClassImpl extends ImportClass
{ 
   public void execute (StatementContext context)
   throws Exception
   {
      Class c = null;
      try
      {
         c = Class.forName (javaName);
      }
      catch (Exception e)
      {
         String reason = "No such class :: " + javaName;
         throw new XSQLRuntimeException (reason);
      }
      context.getSymbolTable ().add (name, c);
   }
}
