package xsql.jdbc;

import java.sql.PreparedStatement;
import xsql.StatementContext;
import xsql.impl.StoredProcDefImpl;

public class DB2Database extends Database
{

   public DB2Database (StatementContext context)
   {
      super (context);
   }
   

   protected StoredProcDefImpl getProcDefFromDatabase (String schemaName,
                                                       String packageName,
                                                       String procedureName,
                                                       String recordSetTag,
                                                       String recordTag)
   throws Exception
   {
      throw new UnsupportedOperationException ();
   }
      
   public void generateProcDefs (String procNamePattern,
                                 String procSchemaPattern,
                                 boolean includeSchemaInDefName)
   throws Exception
   {
      throw new UnsupportedOperationException ();
   }

   protected boolean handleBLOB(PreparedStatement ps, String value) throws Exception
   {
      return false;
   }

   protected boolean handleCLOB(PreparedStatement ps, String value) throws Exception
   {
      return false;
   }
}
