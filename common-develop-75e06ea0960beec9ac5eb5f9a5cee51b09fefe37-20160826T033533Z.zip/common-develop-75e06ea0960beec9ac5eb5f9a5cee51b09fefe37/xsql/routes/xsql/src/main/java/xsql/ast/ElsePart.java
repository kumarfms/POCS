package xsql.ast;

import java.util.*;
import java.io.*;

import org.xml.sax.Locator;

/**
 * This class provides a Java representation of
 * the XML element <code>else</code>.
 */
public class ElsePart
implements Serializable
{
   /**
    * The location of source XML element for this object.
    */
   public transient Locator locator;
   /**
    * Defines a list of XSQL statements to be executed.
    */
   public List  statementList = new LinkedList ();


}
