package xsql.ast;

import java.util.*;
import java.io.*;


/**
 * This class provides a Java representation of
 * the XML element <code>call-proc</code>.
 */
abstract public class CallProcDef extends XSQLStatement
implements Serializable
{
   /**
    * The logical name of the statement.
    */
   public String  name;
   /**
    * The name of the define-proc statement that defines the database procedure
    * to be called.  If not supplied, the logical name of the statement
    * will be used.
    */
   public String  defineProcName;
   /**
    * The name of the database schema that contains the stored procedure.
    */
   public String  schemaName;
   /**
    * The name of the package that contains the stored procedure.
    */
   public String  packageName;
   /**
    * The name of the stored procedure as given in the data base.
    */
   public String  procedureName;
   /**
    * The value to be used for the surrounding XML document tag for each
    * record returned from the record set (if applicable).
    */
   public String  recordTag;
   /**
    * The tag to be used to wrap the returned record set (if applicable).
    */
   public String  recordSetTag;
   /**
    * The arguments to call the stored procedure with.
    */
   public List  args = new LinkedList ();
   /**
    * Defines a list of XSQL statements to be executed.
    * These statements will for each row returned by the stored procedure
    * call.
    */
   public List  statementList = new LinkedList ();


}
