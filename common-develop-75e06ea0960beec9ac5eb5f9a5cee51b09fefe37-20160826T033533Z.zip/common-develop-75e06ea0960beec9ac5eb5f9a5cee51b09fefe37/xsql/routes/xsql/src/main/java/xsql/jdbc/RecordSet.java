package xsql.jdbc;

import java.util.*;
import java.sql.*;

import xsql.*;
import xsql.ast.*;
import xsql.expr.*;

public class RecordSet implements ArrayInterface
{
   public String   recordSetTag;
   public String   recordTag;
   public List     records = new Vector ();
 
   
   public RecordSet (String recordSetTag,
                     String recordTag)
   throws Exception
   {
      this.recordSetTag = recordSetTag;
      this.recordTag = recordTag;
   }
   
   
   public String getName ()
   {
      return recordSetTag;
   }


   public String getComponentName ()
   {
      return recordTag;
   }
 

   public int length ()
   {
      return records.size ();
   }


   public Object getValue (int index)
   {
      return records.get (index);
   }
   
   public void addRecord (RecordValue record)
   throws Exception
   {
      this.records.add (record);
   }
}
