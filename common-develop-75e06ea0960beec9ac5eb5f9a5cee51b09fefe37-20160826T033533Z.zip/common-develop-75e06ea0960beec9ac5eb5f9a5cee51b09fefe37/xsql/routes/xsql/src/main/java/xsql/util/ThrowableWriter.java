package xsql.util;

import java.sql.SQLException;
import org.xml.sax.SAXException;

import xsql.*;

public class ThrowableWriter
{
   private String msg = new String ();
   private Throwable t = null;
   
   public ThrowableWriter()
   {
   }
   
   public String write (Throwable t)
    {
        try
        {
            ThrowableInformation throwableInfo = new ThrowableInformation(t);
            msg += throwableInfo.toString ();

            if (t instanceof SQLException)
            {
                SQLException sqle = (SQLException) t;
                SQLException nextSQLException = sqle.getNextException();
                if (nextSQLException != null)
                {
                   msg += "    ----Next Exception----\n" + 
                          write(nextSQLException);
                }
            }
            else if (t instanceof SAXException)
            {
                SAXException sxe = (SAXException) t;
                Throwable cause = sxe.getException();
                if (cause != null)
                {
                   msg += "    ----Cause----\n" + 
                          write (cause);
                }
            }
            else if (t instanceof XSQLException)
            {
                XSQLException xsqle = (XSQLException) t;
                Throwable cause = xsqle.getCause ();
                if (cause != null)
                {
                   msg += "    ----Cause----\n" + 
                          write (cause);
                }
            }

        }
        catch (Throwable bad) {}
        
        return msg;
    }
}
