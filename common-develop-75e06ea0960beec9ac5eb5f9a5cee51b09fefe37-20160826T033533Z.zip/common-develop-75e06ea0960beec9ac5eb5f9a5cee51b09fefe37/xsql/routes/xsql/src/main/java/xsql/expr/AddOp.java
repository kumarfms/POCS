package xsql.expr;

public class AddOp extends BinaryOp
{
   public AddOp (ExpressionContext context,
                 String opSymbol,
                 Node left,
                 Node right)
   {
      super (context, opSymbol, left, right);
   }


   public Object eval ()
   throws Exception
   {
      evalOperands ();
      prepareValuesForAddOp ();
      if (leftValue instanceof String)
      {
         return leftValue.toString () + rightValue;
      }
      else
      {
         Number l = (Number) leftValue;
         Number r = (Number) rightValue;

         if (leftValue instanceof Double)
         {
            return new Double (l.doubleValue () + r.doubleValue ());
         }
         else if (leftValue instanceof Long)
         {
            return new Long (l.longValue () + r.longValue ());
         }
         else
         {
            return new Integer (l.intValue () + r.intValue ());
         }
      }
   }
}
