package xsql.expr;


import java.util.*;

public class Parser
{
   public Node compiledExpression;
   public ExpressionContext context;


   public void setContext (ExpressionContext context)
   {
      this.context = context;
   }

   /**
    * Number of syntax errors found during the parse.
    */
   public  int     num_syntax_errors = 0;
   /**
    * List of the syntax errors found during the parse.
    */
   public  java.util.List  errors = new LinkedList ();

   private boolean valid = true;
   private Lex     lex = null;

   public void setLex (Lex lex)
   {
      this.lex = lex;
   }


   /**
    * Adds the specified message to the error list.
    */
   protected void error (String msg)
   {
      String errorMessage;

      num_syntax_errors += 1;
      valid = false;
      errorMessage = "Error on line " + lex.line + "(" +
                          lex.column + "): " + msg;
      errors.add (errorMessage);
   }

   public void printErrors ()
   {
      for (Iterator i = errors.iterator (); i.hasNext (); )
      {
         String errorMessage = (String) i.next ();
         System.out.println (errorMessage);
      }
   }


   /**
    * This method parses the production: <code>expr</code>.
    * <pre>
    *    expr ::= relation ({<b>&&</b> relation} | {<b>||</b> relation})
    * </pre>
    */
   public Node parse_expr () throws Exception
   {
      Node result = null;
      Node relation = null;

      relation = parse_relation ();
      if (valid)
      {
         result = relation;
      }
      if (valid)
      {
         switch (lex.sym)
         {
            case Lex.ampersand_ampersand:
                  while (valid && (lex.sym == lex.ampersand_ampersand))
                  {
                     lex.getsym ();
                     if (valid)
                     {
                        relation = parse_relation ();
                        if (valid)
                        {
                           result = new LogicalOp (context, "&&", result, relation);
                        }
                     }
                  }
                  break;
            case Lex.bar_bar:
                  while (valid && (lex.sym == lex.bar_bar))
                  {
                     lex.getsym ();
                     if (valid)
                     {
                        relation = parse_relation ();
                        if (valid)
                        {
                           result = new LogicalOp (context, "||", result, relation);
                        }
                     }
                  }
                  break;
         }
      }
      if (valid)
      {
         compiledExpression = result;

      }
      return result;
   }


   /**
    * This method parses the production: <code>relation</code>.
    * <pre>
    *    relation ::= simple_expr [relop simple_expr]
    * </pre>
    */
   public Node parse_relation () throws Exception
   {
      Node result = null;
      Node simple_expr = null;
      String relop = null;

      simple_expr = parse_simple_expr ();
      if (valid)
      {
         result = simple_expr;
      }
      if (valid)
      {
         if (lex.sym == lex.less_than_equal
             || lex.sym == lex.greater_than
             || lex.sym == lex.exclamation_equal
             || lex.sym == lex.equal_equal
             || lex.sym == lex.less_than
             || lex.sym == lex.greater_than_equal)
         {
            relop = parse_relop ();
            if (valid)
            {
               simple_expr = parse_simple_expr ();
               if (valid)
               {
                  result = new RelationalOp (context, relop, result, simple_expr);
               }
            }
         }
      }
      return result;
   }


   /**
    * This method parses the production: <code>relop</code>.
    * <pre>
    *    relop ::= <b><</b> | <b><=</b> | <b>></b> | <b>>=</b> | <b>!=</b> | <b>==</b>
    * </pre>
    */
   public String parse_relop () throws Exception
   {
      String result = null;

      switch (lex.sym)
      {
         case Lex.less_than:
               result = lex.symText;
               lex.getsym ();
               break;
         case Lex.less_than_equal:
               result = lex.symText;
               lex.getsym ();
               break;
         case Lex.greater_than:
               result = lex.symText;
               lex.getsym ();
               break;
         case Lex.greater_than_equal:
               result = lex.symText;
               lex.getsym ();
               break;
         case Lex.exclamation_equal:
               result = lex.symText;
               lex.getsym ();
               break;
         case Lex.equal_equal:
               result = lex.symText;
               lex.getsym ();
               break;
         default:
               error (" Expected one of the following: " +
                  "{<=, >, !=, ==, <, >=}" );
               break;
      }
      return result;
   }


   /**
    * This method parses the production: <code>simple_expr</code>.
    * <pre>
    *    simple_expr ::= [addop] term {addop term}
    * </pre>
    */
   public Node parse_simple_expr () throws Exception
   {
      Node result = null;
      String addop = null;
      Node term = null;

      if (lex.sym == lex.plus
          || lex.sym == lex.minus)
      {
         addop = parse_addop ();
      }
      if (valid)
      {
         term = parse_term ();
         if (valid)
         {
            result = term;
            if (addop != null)
            {
               result = new UnaryArithmeticOp (context, addop, result);
            }
         }
      }
      while (valid && (lex.sym == lex.plus
                       || lex.sym == lex.minus))
      {
         addop = parse_addop ();
         if (valid)
         {
            term = parse_term ();
            if (valid)
            {
               if (addop.equals ("+"))
                  result = new AddOp (context, addop, result, term);
               else
                  result = new ArithmeticOp (context, addop, result, term);
            }
         }
      }
      return result;
   }


   /**
    * This method parses the production: <code>addop</code>.
    * <pre>
    *    addop ::= <b>+</b> | <b>-</b>
    * </pre>
    */
   public String parse_addop () throws Exception
   {
      String result = null;

      switch (lex.sym)
      {
         case Lex.plus:
               result = lex.symText;
               lex.getsym ();
               break;
         case Lex.minus:
               result = lex.symText;
               lex.getsym ();
               break;
         default:
               error (" Expected one of the following: " +
                  "{+, -}" );
               break;
      }
      return result;
   }


   /**
    * This method parses the production: <code>term</code>.
    * <pre>
    *    term ::= factor {mulop factor}
    * </pre>
    */
   public Node parse_term () throws Exception
   {
      Node result = null;
      Node factor = null;
      String mulop = null;

      factor = parse_factor ();
      if (valid)
      {
         result = factor;
      }
      while (valid && (lex.sym == lex.star
                       || lex.sym == lex.percent
                       || lex.sym == lex.slash))
      {
         mulop = parse_mulop ();
         if (valid)
         {
            factor = parse_factor ();
            if (valid)
            {
               result = new ArithmeticOp (context, mulop, result, factor);
            }
         }
      }
      return result;
   }


   /**
    * This method parses the production: <code>mulop</code>.
    * <pre>
    *    mulop ::= <b>*</b> | <b>/</b> | <b>%</b>
    * </pre>
    */
   public String parse_mulop () throws Exception
   {
      String result = null;

      switch (lex.sym)
      {
         case Lex.star:
               result = lex.symText;
               lex.getsym ();
               break;
         case Lex.slash:
               result = lex.symText;
               lex.getsym ();
               break;
         case Lex.percent:
               result = lex.symText;
               lex.getsym ();
               break;
         default:
               error (" Expected one of the following: " +
                  "{*, %, /}" );
               break;
      }
      return result;
   }


   /**
    * This method parses the production: <code>factor</code>.
    * <pre>
    *    factor ::= primary | <b>!</b> primary
    * </pre>
    */
   public Node parse_factor () throws Exception
   {
      Node result = null;
      Node primary = null;

      switch (lex.sym)
      {
         case Lex.string_sym:
         case Lex.lparen:
         case Lex.number_sym:
         case Lex.identifier_sym:
               primary = parse_primary ();
               if (valid)
               {
                  result = primary;
               }
               break;
         case Lex.exclamation:
               lex.getsym ();
               if (valid)
               {
                  primary = parse_primary ();
                  if (valid)
                  {
                     result = new UnaryLogicalOp (context, "!", primary);
                  }
               }
               break;
         default:
               error (" Expected one of the following: " +
                  "{string_sym, (, number_sym, identifier_sym, !}" );
               break;
      }
      return result;
   }


   /**
    * This method parses the production: <code>primary</code>.
    * <pre>
    *    primary ::= identifier {index} | number {index} | string {index} | <b>(</b> expr <b>)</b> {index}
    * </pre>
    */
   public Node parse_primary () throws Exception
   {
      Node result = null;
      String identifier = null;
      IndexOp index = null;
      Node number = null;
      Node string = null;
      Node expr = null;

      switch (lex.sym)
      {
         case Lex.identifier_sym:
               identifier = parse_identifier ();
               if (valid)
               {
                  result = new NameExpr (context, identifier);
               }
               while (valid && (lex.sym == lex.lparen
                                || lex.sym == lex.lbracket
                                || lex.sym == lex.dot))
               {
                  index = parse_index ();
                  if (valid)
                  {
                     index.setLeft (result);
                     result = index;
                  }
               }
               break;
         case Lex.number_sym:
               number = parse_number ();
               if (valid)
               {
                  result = number;
               }
               while (valid && (lex.sym == lex.lparen
                                || lex.sym == lex.lbracket
                                || lex.sym == lex.dot))
               {
                  index = parse_index ();
                  if (valid)
                  {
                     index.setLeft (result);
                     result = index;
                  }
               }
               break;
         case Lex.string_sym:
               string = parse_string ();
               if (valid)
               {
                  result = string;
               }
               while (valid && (lex.sym == lex.lparen
                                || lex.sym == lex.lbracket
                                || lex.sym == lex.dot))
               {
                  index = parse_index ();
                  if (valid)
                  {
                     index.setLeft (result);
                     result = index;
                  }
               }
               break;
         case Lex.lparen:
               lex.getsym ();
               if (valid)
               {
                  expr = parse_expr ();
                  if (valid)
                  {
                     result = expr;
                  }
               }
               if (valid)
               {
                  if (lex.sym == lex.rparen)
                     lex.getsym ();
                  else
                     error ("')' expected");
               }
               while (valid && (lex.sym == lex.lparen
                                || lex.sym == lex.lbracket
                                || lex.sym == lex.dot))
               {
                  index = parse_index ();
                  if (valid)
                  {
                     index.setLeft (result);
                     result = index;
                  }
               }
               break;
         default:
               error (" Expected one of the following: " +
                  "{string_sym, (, number_sym, identifier_sym}" );
               break;
      }
      return result;
   }


   /**
    * This method parses the production: <code>index</code>.
    * <pre>
    *    index ::= <b>.</b> identifier | <b>(</b> [expr {<b>,</b> expr}] <b>)</b> | <b>[</b> expr <b>]</b>
    * </pre>
    */
   public IndexOp parse_index () throws Exception
   {
      IndexOp result = null;
      String identifier = null;
      Node expr = null;

      switch (lex.sym)
      {
         case Lex.dot:
               lex.getsym ();
               if (valid)
               {
                  identifier = parse_identifier ();
                  if (valid)
                  {
                     result = new SelectionOp (context, identifier);
                  }
               }
               break;
         case Lex.lparen:
               result = new ApplyOp (context);
               lex.getsym ();
               if (valid)
               {
                  if (lex.sym == lex.plus
                      || lex.sym == lex.string_sym
                      || lex.sym == lex.lparen
                      || lex.sym == lex.number_sym
                      || lex.sym == lex.minus
                      || lex.sym == lex.identifier_sym
                      || lex.sym == lex.exclamation)
                  {
                     expr = parse_expr ();
                     if (valid)
                     {
                        ((ApplyOp) result).addArg (expr);
                     }
                     while (valid && (lex.sym == lex.comma))
                     {
                        lex.getsym ();
                        if (valid)
                        {
                           expr = parse_expr ();
                           if (valid)
                           {
                              ((ApplyOp) result).addArg (expr);
                           }
                        }
                     }
                  }
               }
               if (valid)
               {
                  if (lex.sym == lex.rparen)
                     lex.getsym ();
                  else
                     error ("')' expected");
               }
               break;
         case Lex.lbracket:
               lex.getsym ();
               if (valid)
               {
                  expr = parse_expr ();
                  if (valid)
                  {
                     result = new SubscriptOp (context, expr);
                  }
               }
               if (valid)
               {
                  if (lex.sym == lex.rbracket)
                     lex.getsym ();
                  else
                     error ("']' expected");
               }
               break;
         default:
               error (" Expected one of the following: " +
                  "{(, [, .}" );
               break;
      }
      return result;
   }


   /**
    * This method parses the production: <code>identifier</code>.
    * <pre>
    *    identifier ::= <b>identifier_sym</b>
    * </pre>
    */
   public String parse_identifier () throws Exception
   {
      String result = null;

      if (lex.sym == lex.identifier_sym)
      {
         result = lex.symText;
         lex.getsym ();
      }
      else
         error ("'identifier_sym' expected");
      return result;
   }


   /**
    * This method parses the production: <code>number</code>.
    * <pre>
    *    number ::= <b>number_sym</b>
    * </pre>
    */
   public Node parse_number () throws Exception
   {
      Node result = null;

      if (lex.sym == lex.number_sym)
      {
         if (lex.symIsRealNumber)
            result = new ConstantValue (context, new Double (lex.symText));
         else
            result = new ConstantValue (context, new Integer (lex.symText));
         lex.getsym ();
      }
      else
         error ("'number_sym' expected");
      return result;
   }


   /**
    * This method parses the production: <code>string</code>.
    * <pre>
    *    string ::= <b>string_sym</b>
    * </pre>
    */
   public Node parse_string () throws Exception
   {
      Node result = null;

      if (lex.sym == lex.string_sym)
      {
         result = new ConstantValue (context,
           lex.symText.substring (1, lex.symText.length () - 1));

      /* Note. The above line of code should read:
       *
       * result = new ConstantValue (context,
       *   lex.stringValue.toString ());
       *
       * in order to produce string constants with valid escaping of the
       * backslash character. However, this change was not implemented
       * because it may break legacy XSQL programs that took adavantage
       * of the improperly handled backslash character.
       */
     
         lex.getsym ();
      }
      else
         error ("'string_sym' expected");
      return result;
   }


   /**
    * This method parses the production: <code>start</code>.
    * <pre>
    *    start ::= expr
    * </pre>
    */
   public void parse_start () throws Exception
   {
      Node expr = null;

      expr = parse_expr ();
   }


   public int parse (Lex lex) throws Exception
   {
      this.lex = lex;
      valid = true;
      num_syntax_errors = 0;
      lex.getsym();
      parse_start ();

      if (valid && (lex.sym != lex.eof_sym) )
         error ("\"end of file\" expected");

      return num_syntax_errors;
   }


/*
   public static void main (String args[]) throws Exception
   {
      Parser p = new Parser ();
      Lex lex = new Lex ();

      p.parse (lex);
   }
*/
}
