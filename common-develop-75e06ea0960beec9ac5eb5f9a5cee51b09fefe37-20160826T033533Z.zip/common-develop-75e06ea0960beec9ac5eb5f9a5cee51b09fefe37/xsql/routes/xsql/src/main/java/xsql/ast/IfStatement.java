package xsql.ast;

import java.util.*;
import java.io.*;


/**
An <i>if statement</i> selects one of it's enclosed statement lists for
execution.
*/
abstract public class IfStatement extends XSQLStatement
implements Serializable
{
   /**
    * A boolean valued XSQL expression.
    */
   public String  condition;
   /**
   * The value of the element <code>then</code>.
   */
   public ThenPart  thenPart;
   /**
   * The value of the element <code>else</code>.
   */
   public ElsePart  elsePart;


}
