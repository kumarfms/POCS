package xsql.expr;

public class UnaryLogicalOp extends UnaryOp
{
   public UnaryLogicalOp (ExpressionContext context,
                          String opSymbol,
                          Node left)
   {
      super (context, opSymbol, left);
   }


   public Object eval ()
   throws Exception
   {
      evalOperand ();
      prepareValueForLogicalOp ();
      Boolean l = (Boolean) leftValue;
      if (opSymbol.equals ("!"))
         return new Boolean (!l.booleanValue ());
      else
         throw new UndefinedOperatorException (opSymbol);
   }
}
