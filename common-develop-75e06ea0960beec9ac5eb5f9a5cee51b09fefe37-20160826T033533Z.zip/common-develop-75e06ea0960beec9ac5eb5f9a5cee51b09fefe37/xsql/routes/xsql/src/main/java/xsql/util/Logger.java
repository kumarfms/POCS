package xsql.util;

public class Logger
{
   public static int DEBUG = 0;
   public static int INFO = 1;
   public static int WARNING = 2;
   public static int ERROR = 3;

   private int logThresholdLevel = INFO;
   private int numWarnings = 0;
   private int numErrors = 0;

   private String [] levelLabels =
      {"Debug", "Info", "Warning", "Error"};

   private LogWriter logWriter = null;


   public void setLogWriter (LogWriter logWriter)
   {
      this.logWriter = logWriter;
   }


   public void setLevel (int level)
   {
      logThresholdLevel = level;
   }


   public int getLevel ()
   {
      return logThresholdLevel;
   }


   public int getNumWarnings ()
   {
      return numWarnings;
   }


   public int getNumErrors ()
   {
      return numErrors;
   }


   private void addLogEntry (Object caller,
                             String methodName,
                             int level,
                             String message,
                             Throwable throwable)
   {
      if (level == WARNING)
         numWarnings += 1;
      else if (level == ERROR)
         numErrors += 1;

      if (level >= logThresholdLevel)
      {
         ISO8601DateFormat dateFormat = new ISO8601DateFormat();
      
         String fullMessage = dateFormat.getCurrentDateTime() + ": ";
 
         fullMessage += levelLabels [level];
         fullMessage += ": ";
         
         if (caller != null)
         {
            fullMessage += caller.getClass ().getName ();
            
            if (methodName != null)
            {
               fullMessage += "." + methodName + "()";
            }
            
            fullMessage += ": ";
         }
         fullMessage += message;

         if (throwable != null)
         {
            ThrowableWriter writer = new ThrowableWriter ();
            fullMessage += writer.write(throwable);
         }

         if (logWriter == null)
         {
            //System.out.println (fullMessage);
         }
         else
            logWriter.writeMessage (fullMessage);
      }
   }


   public void debug (String message)
   {
      addLogEntry (null, null, DEBUG, message, null);
   }


   public void debug (Object caller, String message)
   {
      addLogEntry (caller, null, DEBUG, message, null);
   }
   

   public void debug (Object caller, String message, Throwable t)
   {
      addLogEntry (caller, null, DEBUG, message, t);
   }   
   

   public void debug (Object caller, String methodName, String message)
   {
      addLogEntry (caller, methodName, DEBUG, message, null);
   }


   public void debug (Object caller, String methodName, String message, Throwable t)
   {
      addLogEntry (caller, methodName, DEBUG, message, t);
   }


   // =============


   public void info (String message)
   {
      addLogEntry (null, null, INFO, message, null);
   }


   public void info (Object caller, String message)
   {
      addLogEntry (caller, null, INFO, message, null);
   }
   

   public void info (Object caller, String message, Throwable t)
   {
      addLogEntry (caller, null, INFO, message, t);
   }   
   

   public void info (Object caller, String methodName, String message)
   {
      addLogEntry (caller, methodName, INFO, message, null);
   }


   public void info (Object caller, String methodName, String message, Throwable t)
   {
      addLogEntry (caller, methodName, INFO, message, t);
   }

   // =============


   public void warning (String message)
   {
      addLogEntry (null, null, WARNING, message, null);
   }


   public void warning (Object caller, String message)
   {
      addLogEntry (caller, null, WARNING, message, null);
   }
   

   public void warning (Object caller, String message, Throwable t)
   {
      addLogEntry (caller, null, WARNING, message, t);
   }   
   

   public void warning (Object caller, String methodName, String message)
   {
      addLogEntry (caller, methodName, WARNING, message, null);
   }


   public void warning (Object caller, String methodName, String message, Throwable t)
   {
      addLogEntry (caller, methodName, WARNING, message, t);
   }


   // =============


   public void error (String message)
   {
      addLogEntry (null, null, ERROR, message, null);
   }


   public void error (Object caller, String message)
   {
      addLogEntry (caller, null, ERROR, message, null);
   }
   

   public void error (Object caller, String message, Throwable t)
   {
      addLogEntry (caller, null, ERROR, message, t);
   }   
   

   public void error (Object caller, String methodName, String message)
   {
      addLogEntry (caller, methodName, ERROR, message, null);
   }


   public void error (Object caller, String methodName, String message, Throwable t)
   {
      addLogEntry (caller, methodName, ERROR, message, t);
   }
   // =============
}
