package xsql.ast;

import java.util.*;
import java.io.*;


/**
A <i>call TE statement</i> invokes the execution of a TE. The call
specifies the association of arguments with the formal parameters
of the TE.
*/
abstract public class TECall extends XSQLStatement
implements Serializable
{
   /**
   * The name of TE call statement. If this attribute is specified,
   * a variable with the same name will be set to result of the TE
   * call. This variable can then be used to access the return value
   * and the out parameters.
   */
   public String  name;
   /**
    * The name of a define-proc statement that defines the TE procedure
    * to be called.  If not supplied, the schema, package, and procedure
    * name must be supplied.
    */
   public String  defineProcName;
   /**
   * The name of the database schema that contains the TE.
   */
   public String  schemaName;
   /**
   * The name of the package that contains the TE's.
   */
   public String  packageName;
   /**
   * The name of the TE procedure to call.
   */
   public String  procedureName;
   /**
   * The arguments to call the TE with.
   */
   public List  args = new LinkedList ();


}
