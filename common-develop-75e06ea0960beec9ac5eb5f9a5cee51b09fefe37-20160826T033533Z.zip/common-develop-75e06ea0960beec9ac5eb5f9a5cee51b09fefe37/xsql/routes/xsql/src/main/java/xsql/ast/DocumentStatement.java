package xsql.ast;

import java.util.*;
import java.io.*;


/**
A <i>document statement</i> provides control over the document to the user.
*/
abstract public class DocumentStatement extends XSQLStatement
implements Serializable
{
   /**
    * The action to apply to the document.
    */
   public String  action;


}
