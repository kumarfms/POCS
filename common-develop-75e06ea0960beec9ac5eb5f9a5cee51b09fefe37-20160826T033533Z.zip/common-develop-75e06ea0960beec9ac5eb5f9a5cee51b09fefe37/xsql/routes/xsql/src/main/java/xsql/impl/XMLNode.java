package xsql.impl;

import java.util.*;
import java.io.*;

import org.xml.sax.Locator;

abstract public class XMLNode
implements Serializable
{
   public transient Locator locator;


   public void write (int indent, OutputStream os, String encoding)
   throws Exception
   {
      Writer writer = getWriter (os, encoding);
      write (indent, writer);
      writer.flush ();
   }


   protected static Writer getWriter (OutputStream os, String encoding)
   throws Exception
   {
      Writer writer = null;

      if (encoding == null)
      {
         writer = new OutputStreamWriter (os, "UTF-8");
         writer = new BufferedWriter (writer);
         writer.write ("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
      }
      else
      {
         writer = new OutputStreamWriter (os, encoding);
         writer = new BufferedWriter (writer);
         writer.write ("<?xml version=\"1.0\" encoding=\"" +
           encoding + "\"?>\n");
      }
      return writer;
   }


   protected void write (int index, Writer writer)
   throws Exception
   {
   }
}
