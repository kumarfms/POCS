package xsql.expr;

import java.lang.reflect.*;

public class SelectionOp extends IndexOp
{
   public String memberName;

   public SelectionOp (ExpressionContext context, String memberName)
   {
      super (context);
      this.memberName = memberName;
   }


   public boolean isPackageTypeOrMethodName ()
   {
      return left.isPackageTypeOrMethodName ();
   }


   public String getName ()
   {
      return left.getName () + "." + memberName;
   }


   public Object eval () throws Exception
   {
      Object value = left.eval ();

      if (parent instanceof ApplyOp)
      {
         ApplyOp parentApplyOp = (ApplyOp) parent;
         if (parentApplyOp.left == this)
            return new Function (value, memberName);
      }
      if (value instanceof ArrayInterface)
      {
         ArrayInterface a = (ArrayInterface) value;
         if (memberName.equals ("length"))
         {
            return new Integer (a.length ());
         }
         if (a.length () > 0)
         {
            Object componentValue = a.getValue (0);
            if (componentValue instanceof RecordInterface)
               value = componentValue;
         }
      }
      return getRecordFieldValue (value, memberName);
   }


   private Object getRecordFieldValue (Object value, String fieldName)
   throws Exception
   {
      if (value instanceof RecordInterface)
      {
         RecordInterface record = (RecordInterface) value;

         if (record.fieldExists (fieldName))
         {
            return record.getFieldValue (fieldName);
         }
         else
         {
            throw new UndefinedSymbolException ("record field " + memberName);
         }
      }
      else
      {
         Class c = null;
         if (value instanceof Class)
            c = (Class) value;
         else
            c = value.getClass ();

         java.lang.reflect.Field field = null;
         try
         {
            field = c.getDeclaredField (fieldName);
         }
         catch (NoSuchFieldException e)
         {
            String reason = "undefined field :: " + fieldName;
            throw new ExpressionException (reason);
         }
         return field.get (value);
      }
   }
}
