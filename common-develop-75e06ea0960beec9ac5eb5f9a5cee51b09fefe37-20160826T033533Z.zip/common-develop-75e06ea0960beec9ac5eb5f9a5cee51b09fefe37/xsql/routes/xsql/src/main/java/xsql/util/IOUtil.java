package xsql.util;

import java.io.*;

public class IOUtil 
{

   private IOUtil() { }
   
   public static void closeReader (Reader reader)
   {
      try
      {
         reader.close ();
      }
      catch (Exception e) {}
   }
   
   public static void closeWriter (Writer writer)
   {
      try
      {
         writer.close ();
      }
      catch (Exception e) {}
   }

   public static String inputStreamToString(InputStream is, String enc, int bufferSize)
   throws Exception
   {
      StringBuffer result = new StringBuffer (bufferSize);
      InputStreamReader reader = null;

      if (enc == null)
      {
         reader = new InputStreamReader(is);
      }
      else
      {
         reader = new InputStreamReader(is, enc);
      }

      int ch = reader.read();
      while (ch != -1)
      {
         result.append((char) ch);
         ch = reader.read();
      }
      is.close();
      return result.toString();
   }

    public static void writeInputStreamToOutputStream (InputStream in,
                                                       OutputStream out,
                                                       int bufferSize)
    throws Exception
    {
       byte [] buffer = new byte[bufferSize];
       while (true)
       {
          int bytesRead = in.read(buffer);
          if (bytesRead == -1) break;
          out.write(buffer, 0, bytesRead);
       }
    }

    public static void closeInputStream(InputStream in)
    {
        try
        {
            in.close();
        }
        catch (Exception e) {}
    }

    public static void closeOutputStream(OutputStream out)
    {
        try
        {
            out.close();
        }
        catch (Exception e) {}
    }
}
