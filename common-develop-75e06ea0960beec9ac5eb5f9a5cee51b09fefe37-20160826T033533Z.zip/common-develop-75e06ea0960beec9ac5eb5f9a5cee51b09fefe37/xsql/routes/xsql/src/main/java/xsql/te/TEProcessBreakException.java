package xsql.te;

import xsql.*;

public class TEProcessBreakException extends XSQLRuntimeException
{
   public TEProcessBreakException ()
   {
      super ("TEProcessBreakException");
   }
}
