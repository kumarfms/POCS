package xsql.expr;

public class UnaryArithmeticOp extends UnaryOp
{
   public UnaryArithmeticOp (ExpressionContext context,
                             String opSymbol,
                             Node left )
   {
      super (context, opSymbol, left);
   }


   public Object eval ()
   throws Exception
   {
      evalOperand ();
      prepareValueForArithmeticOp ();
      Number l = (Number) leftValue;
      if (leftValue instanceof Double)
      {
         if (opSymbol.equals ("+"))
            return l;
         else if (opSymbol.equals ("-"))
            return new Double (0.0 - l.doubleValue ());
         else
            throw new UndefinedOperatorException (opSymbol);
      }
      else if (leftValue instanceof Long)
      {
         if (opSymbol.equals ("+"))
            return l;
         else if (opSymbol.equals ("-"))
            return new Long (0 - l.longValue ());
         else
            throw new UndefinedOperatorException (opSymbol);
      }
      else
      {
         if (opSymbol.equals ("+"))
            return l;
         else if (opSymbol.equals ("-"))
            return new Integer (0 - l.intValue ());
         else
            throw new UndefinedOperatorException (opSymbol);
      }
   }
}
