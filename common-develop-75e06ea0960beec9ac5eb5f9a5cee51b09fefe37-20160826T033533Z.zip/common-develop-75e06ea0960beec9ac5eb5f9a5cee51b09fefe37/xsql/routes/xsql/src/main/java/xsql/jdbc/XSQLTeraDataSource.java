package xsql.jdbc;

import java.util.*;
import java.util.logging.Logger;
import java.io.*;
import java.sql.*;

import javax.sql.*;

import com.ncr.teradata.TeraDataSource;
import com.ncr.teradata.TeraDriver;


/**
 *  Encapsulates the specific data and behavior for connecting to an NCR
 *  Teradata database via JDBC.
 */
public class XSQLTeraDataSource extends XSQLDataSource
implements Serializable
{
   
   private TeraDataSource ds = null;
   
   public XSQLTeraDataSource ()
   {
   }

   public boolean equals (Object obj)
   {
      if (!super.equals (obj))
      {
         return false;
      }
      if (obj == null) return false;
      if (!(obj instanceof XSQLTeraDataSource)) return false;

      XSQLTeraDataSource obj1 = (XSQLTeraDataSource) obj;
      return true;
   }


   public String getJDBCUrl () throws SQLException
   {
      if (url == null)
      {
         url = "jdbc:teradata://" + getHost()     + "/" +
                      "ENCRYPTDATA=ON"            + "," +
                      "CHARSET=UTF8"              + "," +                 
                      "Database=" + getSid()      + "," +
                      "DBS_PORT=" + getPort();
      }

      return url;
   }

   /**
    * Returns the port to the jdbc datasource
    */
   public int getPort ()
   throws SQLException
   {
      try
      {
         if (port == null)
            return 1025;
         else
            return Integer.parseInt (port);
      }
      catch (Exception e)
      {
         String errMsg = "Unable to get port number.";
         throw new SQLException(errMsg);
      }
   } 


   public java.sql.Connection getConnection ()
   throws SQLException
   {
      if (conn != null)
         return conn;
      
      if (url == null)
         return getConnectionFromDataSource ();
      else
         return getConnectionFromDriver ();
   }
   
   protected Connection getConnectionFromDataSource ()
   throws SQLException
   {
      if (ds == null)
         ds = new TeraDataSource ();
      
      //required parameters
      ds.setDSName(getHost ());
      ds.setDBS_PORT(getPort() + ""); //port number on gateway server
      ds.setDSName(getHost ()); //dataBase server name
      ds.setuser(getUser ()); 
      ds.setpassword(getPwd ()); 
      ds.setDATABASE(getSid()); //default database name
      ds.setENCRYPTDATA("ON"); 
      ds.setCHARSET("UTF8");
      
      return ds.getConnection ();    
   }
   
   protected Connection getConnectionFromDriver ()
   throws SQLException
   {
      TeraDriver d = new TeraDriver ();
      return d.connect (getJDBCUrl (), getConnectionProperties ());
   }
   
   /**
   * Gets the connection properties
   */
   public Properties getConnectionProperties()
   {
     Properties connectionProperties = new Properties();
     connectionProperties.put("user", this.getUser());
     connectionProperties.put("password", this.getPwd());

     return connectionProperties;
   }


}
