package xsql.ast;

import java.util.*;
import java.io.*;


/**
A <i>tag statement</i> creates a variable in the current scope
and assigns it the value of an expression or a string literal.
<p>
The value of the variable may be given as either
an <code>expr</code> attribute,
a <code>value</code> attribute,
an <code>&lt;expr&gt;</code> element,
or a <code>&lt;value&gt;</code> element.
Only one of the four forms of a value can be specified.
If none of the above forms are specified, then the variable is
assigned the value <code>null</code>.
<p>
The scope of a variable is portion of an XSQL program where the variable
is potentially accessible by it's name.
The scope a variable begins at the
text of the first var statement mentioning its name to the end of the
statement list this var statement occurs in. 
The tag can be referred to by its name in this scope, unless it is
hidden by another tag statement that declares a variable by the same name,
in a nested statement list. In this case, the name shall refer to variable
in the inner scope.
<p>
In a given scope, excluding all nested scopes, only one variable with a
given name can exist.
*/
abstract public class TagStatement extends XSQLStatement
implements Serializable
{
   /**
    * The name of the tag. This name must be a legal XSQL identifier.
    */
   public String  name;
   /**
    * An attribute containing an XSQL expression. In this form the expression
    * is evaluated and the value is assigned to the tag.
    */
   public String  expr;
   /**
    * An attribute that contains a string value.
    * In this form, 
    * the value assigned is the string value of the attribute.
    * If the string value contains embedded expressions,
    * they are evaluated and substituted into the final string value.
    */
   public String  value;


}
