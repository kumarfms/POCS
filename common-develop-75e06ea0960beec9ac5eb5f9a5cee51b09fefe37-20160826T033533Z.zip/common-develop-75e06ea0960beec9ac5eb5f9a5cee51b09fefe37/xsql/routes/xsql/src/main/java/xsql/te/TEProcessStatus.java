package xsql.te;

import xsql.*;
import xsql.ast.*;

import java.util.*;

public class TEProcessStatus
{
   public boolean teCallFailed = false;
   public TECallImpl failedCall = null;
   public int numTECallsMade = 0;
   public CCAPIServices ccapiServices;
   public List teMessages = new LinkedList ();
}
