package xsql.ast;

import java.util.*;
import java.io.*;

import org.xml.sax.Locator;

/**
 * This class provides a Java representation of
 * the XML element <code>then</code>.
 */
public class ThenPart
implements Serializable
{
   /**
    * The location of source XML element for this object.
    */
   public transient Locator locator;
   /**
   * A list of <code>XSQLStatements</code>, which correspond
   * to the XML elements <code>xsql-statement</code>.
   */
   public List  statementList = new LinkedList ();


}
