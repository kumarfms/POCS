package xsql.util;

import org.w3c.dom.*;
import org.apache.xerces.util.XMLChar;

/**
 * Library of various utility methods useful for handling XML.
 */

public class XMLUtils
{
   /**
    * Escape characters that have special meaning to
    * HTML and XML.
    *
    * Also, invalid XML characters are ignored.
    */
   public static String xmlEscape (String s)
   {
      if (s == null)
         return null;
      
      int length          = s.length ();
      StringBuffer retval = new StringBuffer (length + 100);
      
      // (the default StringBuffer is very short;
      //  we don't have to get this exactly right, because
      //  it will expand if necessary)
      
      for (int i = 0; i < length; i++)
      {
         char c = s.charAt (i);
         switch (c)
         {
            case '<':
               retval.append ("&lt;");
               break;
            case '>':
               retval.append ("&gt;");
               break;
            case '&':
               retval.append ("&amp;");
               break;
            case '\"':
               retval.append ("&quot;");
               break;
            case '\'':
               retval.append ("&#39;");
               break;
            default:
               if (XMLChar.isValid (c))
               {
                  retval.append (c);
               }
               break;
         }
      }
      return retval.toString ();
   }


   /**
    * Test whether a given node is an element node.
    */
   public static boolean isElement (Node node)
   {
      if (node == null)
         return false;

      return node instanceof Element;
   }


   /**
    * Test whether a given node is an element node with the specified name.
    */
   public static boolean isElement (Node node, String name)
   {
      if (node == null)
         return false;

      if (!(node instanceof Element))
         return false;

      return name.equals (node.getLocalName ());
   }


   /**
    * Returns the character data associated with a specified element node.
    */
   public static String getContents (Node node)
   {
      String result = null;
      node.normalize ();
      Node child = node.getFirstChild ();
      while (child != null)
      {
         if (child instanceof CharacterData)
         {
            if (result == null)
               result = ((CharacterData) child).getData ();
            else
               result += ((CharacterData) child).getData ();
         }
         else if (child instanceof EntityReference)
            result += getContents (child);

         child = child.getNextSibling ();
      }
      return result;
   }


   /**
    * Returns trimmed character data associated with a specified element node.
    * Unlike getContents, if there is no character data associated with the
    * node it returns the null string instead of the value <code>null</code>.
    */
   public static String getTrimmedContents (Node node)
   {
      String result = getContents (node);

      if (result == null)
         result = "";
      else
         result = result.trim ();

      return result;
   }




   public static Node getFirstChildElement (Node node)
   {
      Node child = node.getFirstChild();
      if (!isElement (child))
      {
         return getNextSiblingElement (child);
      }
      return child;
   }


   public static Node getNextSiblingElement (Node node)
   {
      Node sibling = node.getNextSibling();

      while (!isElement (sibling) && sibling != null)
      {
         sibling = sibling.getNextSibling ();
      }
      return sibling;
   }



  // simplified helper method -- may not be final version!
  public static boolean getBooleanContents(Node node) {
    String contentsStr = getContents(node);
    return getBooleanFromString(contentsStr);
  }

  protected static boolean getBooleanFromString(String contentsStr) {
    if (contentsStr != null && (contentsStr.equals("true") || contentsStr.equals("yes") ||
        contentsStr.equals("1")))
          return true;

    return false;
  }

  public static String getAttribute(String attribute, NamedNodeMap atts) {
    Node attNode = atts.getNamedItem(attribute);
    if (attNode == null)
      return null;
    return (attNode.getNodeValue());
  }

  public static boolean getBooleanAttribute(String attribute, NamedNodeMap atts) {
    String attString = getAttribute(attribute, atts);
    return getBooleanFromString(attString);
  }
}
