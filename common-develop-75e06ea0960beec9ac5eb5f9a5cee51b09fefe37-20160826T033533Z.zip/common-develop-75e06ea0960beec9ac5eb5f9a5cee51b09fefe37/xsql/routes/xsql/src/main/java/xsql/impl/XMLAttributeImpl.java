package xsql.impl;

import java.util.*;
import java.io.*;

import xsql.*;
import xsql.ast.*;

public class XMLAttributeImpl extends XMLAttribute
{
   public void write (Writer writer)
   throws Exception
   {
      writer.write (name);
      writer.write ("=\"");
      writer.write (value);
      writer.write ("\"");      
   }
}
