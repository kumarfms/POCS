package xsql.expr;

public class Node
{
   public ExpressionContext context;
   public Node parent;


   public Node (ExpressionContext context)
   {
      this.context = context;
   }


   public boolean isPackageTypeOrMethodName ()
   {
      return false;
   }


   public String getName ()
   {
      return null;
   }


   public Object eval ()
   throws Exception
   {
      return null;
   }


   public Object toString (Object v)
   {
      return v + "";
   }


   public Object toDouble (Object v)
   throws Exception
   {
      if (v instanceof Double)
      {
         return v;
      }
      else if (v instanceof Number)
      {
         return new Double (((Number)v).doubleValue ());
      }
      else if (v instanceof String)
      {
         try
         {
            return Double.valueOf ((String) v);
         }
         catch (NumberFormatException e)
         {
            throw new InvalidTypeException (v, "Double");
         }
      }
      else
         throw new InvalidTypeException (v, "Double");
   }


   public Object toLong (Object v)
   throws Exception
   {
      if (v instanceof Long)
      {
         return v;
      }
      else if (v instanceof Number)
      {
         return new Long (((Number)v).longValue ());
      }
      else if (v instanceof String)
      {
         try
         {
            return Long.valueOf ((String) v);
         }
         catch (NumberFormatException e)
         {
            throw new InvalidTypeException (v, "Long");
         }
      }
      else
         throw new InvalidTypeException (v, "Long");
   }


   public Object toInteger (Object v)
   throws Exception
   {
      if (v instanceof Integer)
      {
         return v;
      }
      else if (v instanceof Number)
      {
         return new Integer (((Number)v).intValue ());
      }
      else if (v instanceof String)
      {
         try
         {
            return Integer.valueOf ((String) v);
         }
         catch (NumberFormatException e)
         {
            throw new InvalidTypeException (v, "Integer");
         }
      }
      else
         throw new InvalidTypeException (v, "Integer");
   }


   public int toInt (Object v)
   throws Exception
   {
      Integer value = (Integer) toInteger (v);
      return value.intValue ();
   }


   public Object toBoolean (Object v)
   throws Exception
   {
      if (v instanceof Boolean)
      {
         return v;
      }
      else
         throw new InvalidTypeException (v, "Boolean");
   }
}
