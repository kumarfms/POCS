package xsql.impl;

import java.io.*;
import java.sql.*;
import java.util.*;

import xsql.*;
import xsql.ast.*;
import xsql.util.*;
import xsql.expr.*;
  
public class WhileStatementImpl extends WhileStatement
{ 
   StatementContext context = null;

   public void execute (StatementContext context)
   throws Exception
   {
      this.context = context;
      boolean b = context.evalBooleanExpression (condition);
      while (b)
      {
         context.executeStatementList (statementList);
         b = context.evalBooleanExpression (condition);
      }
   }
}
