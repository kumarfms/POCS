package xsql.impl;

import java.util.*;
import java.io.*;

import xsql.*;
import xsql.ast.*;
import xsql.util.*;

public class LogStatementImpl extends LogStatement
{
   public void execute (StatementContext context)
   throws Exception
   {
      Logger logger = context.getLogger ();
      String value = getValue ();
      value = context.resolveExpressions (value);

      if ("debug".equals (level))
         logger.debug (value);
      else if ("warning".equals (level))
         logger.warning (value);
      else if ("error".equals (level))
         logger.error (value);
      else
         logger.info (value);
   }


   private String getValue ()
   {
      if (value != null)
         return value;
      else
         return longValue;
   }
}
