package xsql.impl;

import xsql.*;
import xsql.ast.*;
import xsql.util.*;
import xsql.expr.*;
  
public class DocumentStatementImpl extends DocumentStatement
{ 
   public void execute (StatementContext context)
   throws Exception
   {
      if ("clear".equalsIgnoreCase(action))
      {
          context.clearDocument ();
      }
   }
}
