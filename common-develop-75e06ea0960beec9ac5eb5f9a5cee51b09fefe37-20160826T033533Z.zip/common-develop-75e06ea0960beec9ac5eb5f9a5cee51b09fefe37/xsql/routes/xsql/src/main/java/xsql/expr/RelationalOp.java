package xsql.expr;

public class RelationalOp extends BinaryOp
{
   public RelationalOp (ExpressionContext context,
                        String opSymbol,
                        Node left,
                        Node right)
   {
      super (context, opSymbol, left, right);
   }


   public Object eval ()
   throws Exception
   {
      evalOperands ();
      prepareValuesForRelationalOp ();
      if (leftValue instanceof Double)
      {
         Number l = (Number) leftValue;
         Number r = (Number) rightValue;
         if (opSymbol.equals ("<"))
            return new Boolean (l.doubleValue () < r.doubleValue ());
         else if (opSymbol.equals ("<="))
            return new Boolean (l.doubleValue () <= r.doubleValue ());
         else if (opSymbol.equals (">"))
            return new Boolean (l.doubleValue () > r.doubleValue ());
         else if (opSymbol.equals (">="))
            return new Boolean (l.doubleValue () >= r.doubleValue ());
         else if (opSymbol.equals ("=="))
            return new Boolean (l.doubleValue () == r.doubleValue ());
         else if (opSymbol.equals ("!="))
            return new Boolean (l.doubleValue () != r.doubleValue ());
         else
            throw new UndefinedOperatorException (opSymbol);
      }
      else if (leftValue instanceof Number)
      {
         Number l = (Number) leftValue;
         Number r = (Number) rightValue;
         if (opSymbol.equals ("<"))
            return new Boolean (l.longValue () < r.longValue ());
         else if (opSymbol.equals ("<="))
            return new Boolean (l.longValue () <= r.longValue ());
         else if (opSymbol.equals (">"))
            return new Boolean (l.longValue () > r.longValue ());
         else if (opSymbol.equals (">="))
            return new Boolean (l.longValue () >= r.longValue ());
         else if (opSymbol.equals ("=="))
            return new Boolean (l.longValue () == r.longValue ());
         else if (opSymbol.equals ("!="))
            return new Boolean (l.longValue () != r.longValue ());
         else
            throw new UndefinedOperatorException (opSymbol);
      }
      else
      {
         String l = (String) leftValue;
         String r = (String) rightValue;
         int cmp = l.compareTo (r);
         if (opSymbol.equals ("<"))
            return new Boolean (cmp < 0);
         else if (opSymbol.equals ("<="))
            return new Boolean (cmp <= 0);
         else if (opSymbol.equals (">"))
            return new Boolean (cmp > 0);
         else if (opSymbol.equals (">="))
            return new Boolean (cmp >= 0);
         else if (opSymbol.equals ("=="))
            return new Boolean (cmp == 0);
         else if (opSymbol.equals ("!="))
            return new Boolean (cmp != 0);
         else
            throw new UndefinedOperatorException (opSymbol);
      }
   }
}
