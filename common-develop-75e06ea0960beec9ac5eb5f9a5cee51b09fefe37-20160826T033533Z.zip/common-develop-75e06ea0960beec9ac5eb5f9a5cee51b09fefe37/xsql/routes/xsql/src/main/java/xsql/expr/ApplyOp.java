package xsql.expr;

import java.util.*;
import java.lang.reflect.*;

public class ApplyOp extends IndexOp
{
   List arguments = new LinkedList ();


   public ApplyOp (ExpressionContext context)
   {
      super (context);
   }


   public void addArg (Node expr)
   {
      expr.parent = this;
      arguments.add (expr);
   }


   public Object eval () throws Exception
   {
      Object value = left.eval ();

      if (value instanceof Function)
      {
         return invoke ((Function) value);
      }
      else if (value instanceof Class)
      {
         return instantiate ((Class) value);
      }
      else
      {
         throw new InvalidTypeException (value, "method");
      }
   }


   Object instantiate (Class c)
   throws Exception
   {
      Object [] args = getArgs ();
      Constructor constructor = getConstructor (c, args);
      return constructor.newInstance (args);
   }


   Object invoke (Function f)
   throws Exception
   {
      Object [] args = getArgs ();
      Method method = getMethod (f, args);
      if (f.obj instanceof Class)
         return method.invoke (f.obj, args);
      else
         return method.invoke (f.obj, args);
   }


   Object[] getArgs ()
   throws Exception
   {
      Object[] result = new Object [arguments.size ()];
      int ix = 0;
      for (Iterator i = arguments.iterator (); i.hasNext ();)
      {
         Node expr = (Node) i.next ();
         result [ix++] = expr.eval ();
      }
      return result;
   }


   Constructor getConstructor (Class c, Object [] args)
   throws Exception
   {
      Constructor result = null;

      Constructor [] constructors = c.getConstructors ();

      for (int i = 0; i < constructors.length; i++)
      {
         Constructor constructor = constructors [i];
         if (argsCompatible (constructor.getParameterTypes (), args))
         {
            result = constructor;
            break;
         }
      }
      if (result == null)
      {
         String profile = c.getName ();

         profile += "(";
         for (int i = 0; i < args.length; i++)
         {
            if (i > 0)
               profile += ",";
            profile += args [i].getClass ().getName ();
         }
         profile += ")";
         throw new ExpressionException ("No such constructor :: " + profile);
      }

      return result;
   }


   Method getMethod (Function f, Object [] args)
   throws Exception
   {
      Method result = null;

      Class c = null;
      if (f.obj instanceof Class)
      {
         c = (Class) f.obj;
      }
      else
      {
         c = f.obj.getClass ();
      }

      Method [] methods = c.getMethods ();

      for (int i = 0; i < methods.length; i++)
      {
         Method m = methods [i];
         if (m.getName ().equals (f.methodName) &&
           Modifier.isPublic (m.getModifiers ()) &&
           argsCompatible (m.getParameterTypes (), args))
         {
            result = m;
            break;
         }
      }
      if (result == null)
      {
         String profile;
         if (c != null)
            profile = c.getName () + "." + f.methodName;
         else
            profile = f.methodName;

         profile += "(";
         for (int i = 0; i < args.length; i++)
         {
            if (i > 0)
               profile += ",";
            profile += args [i].getClass ().getName ();
         }
         profile += ")";
         throw new ExpressionException ("No such method :: " + profile);
      }

      return result;
   }


   boolean argsCompatible (Class [] paramTypes, Object [] args)
   throws Exception
   {
      if (paramTypes.length != args.length)
         return false;

      for (int i = 0; i < args.length; i++)
      {
         if (!isArgCompatible (paramTypes [i], args [i]))
            return false;
      }
      return true;
   }


   boolean isArgCompatible (Class c, Object arg)
   throws Exception
   {
      if (c.isInstance (arg))
         return true;

      if (c.getName ().equals ("int"))
         return arg instanceof Integer
           || arg instanceof Short
           || arg instanceof Character
           || arg instanceof Byte;

      if (c.getName ().equals ("double"))
         return arg instanceof Double
           || arg instanceof Float
           || arg instanceof Long
           || arg instanceof Integer
           || arg instanceof Short
           || arg instanceof Character
           || arg instanceof Byte;

      if (c.getName ().equals ("boolean"))
         return arg instanceof Boolean;

      if (c.getName ().equals ("float"))
         return arg instanceof Float
           || arg instanceof Long
           || arg instanceof Integer
           || arg instanceof Short
           || arg instanceof Character
           || arg instanceof Byte;

      if (c.getName ().equals ("long"))
         return arg instanceof Long
           || arg instanceof Integer
           || arg instanceof Short
           || arg instanceof Character
           || arg instanceof Byte;

      if (c.getName ().equals ("char"))
         return arg instanceof Character
           || arg instanceof Byte;

      if (c.getName ().equals ("short"))
         return arg instanceof Short
           || arg instanceof Byte;

      if (c.getName ().equals ("byte"))
         return arg instanceof Byte;

      return false;
   }
}
