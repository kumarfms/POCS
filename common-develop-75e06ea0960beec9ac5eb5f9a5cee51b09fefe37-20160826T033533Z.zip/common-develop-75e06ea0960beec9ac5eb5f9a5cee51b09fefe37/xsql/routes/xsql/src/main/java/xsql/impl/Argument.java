package xsql.impl;

import xsql.ast.ArgumentDef;

public class Argument extends ArgumentDef
{
   public Argument ()
   {
   }


   public Argument (String name, String value)
   {
      this.name = name;
      this.value = value;
   }


   public String getValue ()
   {
      if (longValue != null)
         return longValue;
      else
         return value;
   }

   
   public String getJDBCType ()
   throws Exception
   {
      if (jdbcType != null)
      {
         if (simpleDateFormat != null)
         {
            if (!(jdbcType.equals("DATE") ||
                  jdbcType.equals("TIME") ||
                  jdbcType.equals("TIMESTAMP")))
            {
               String e = null;
               e = "When a jdbc type and a simple date format are " +
                   "specified, the jdbc type must be one of: "      +
                   "DATE, TIME, or TIMESTAMP.";
               throw new IllegalArgumentException (e);
            }
         }
         return jdbcType;
      }
      else
      {
         if (dateType != null) // Deprecated attribute for an argument.
         {
            if (dateType.equalsIgnoreCase("DATE"))
            {
               jdbcType = "DATE";
            }
            else if (dateType.equalsIgnoreCase("TIME"))
            {
               jdbcType = "TIME";
            }
            else if (dateType.equalsIgnoreCase("TIMESTAMP"))
            {
               jdbcType = "TIMESTAMP";
            }
         }
         else
         {
            if (simpleDateFormat != null)
            {
               jdbcType = "DATE";
            }
            else
            {
               jdbcType = "VARCHAR";
            }
         }
         return jdbcType;
      }
   }


   public String getSimpleDateFormat ()
   throws Exception
   {
      String jdbcType = getJDBCType ();
      if (jdbcType.equals("DATE") ||
          jdbcType.equals("TIME") ||
          jdbcType.equals("TIMESTAMP"))
      {
         if (simpleDateFormat == null)
         {
            String e = null;
            e = "When a jdbc type of DATE, TIME, or TIMESTAMP is specified" +
                " a simple date format must also be specified.";
            throw new IllegalArgumentException (e);
         }
      }
      return simpleDateFormat;
   }


   public String getName ()
   {
      if (name != null)
      {
         return name;
      }
      else
      {
         if (pos != null)
         {
            name = pos.toString ();
         }
         return name;
      }
   }
}
