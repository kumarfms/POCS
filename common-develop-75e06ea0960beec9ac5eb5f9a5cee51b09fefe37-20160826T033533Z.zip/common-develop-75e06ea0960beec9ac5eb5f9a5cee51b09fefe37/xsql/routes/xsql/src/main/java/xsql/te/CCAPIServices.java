package xsql.te;

import xsql.util.Logger;
import java.util.*;
import java.sql.Connection;
import xsql.util.DBUtil;
import oracle.jdbc.OracleCallableStatement;


/**
 *  CCAPIServices class contains common methods used by CC Api Adapter.
 *  When an object of this class is constructed, it automatically gets an Oracle
 *  connection that can be used by all the CompassCONNECT Api TEs.  This class
 *  also contains the SyncNull, Commit, Rollback calls to the TEs.
 */

public class CCAPIServices
{

     private Connection connection;
     private String schema;
     private Logger log;
     private String luwId = "ERROR";
     private int luwSeq = 0;
     private int syncrc;
     private boolean teCalled = false;


   public CCAPIServices (Connection connection,
                         String schema,
                         Logger log)
   {
      this.connection = connection;
      this.schema = schema;
      this.log = log;
   }


   public String getSchema ()
   {
      return schema;
   }


     /**
      *  Set the value of the TE Called field
      *  @param inTeCalled true, to set TE Called indication on;
      *                     false, to set TE Called indication off
      */

     public void setTeCalled(boolean inTeCalled) {
          teCalled = inTeCalled;
     }


     /**
      *  Get the value of the TE Called Flag field
      *  @return the value of TE Called Flag field
      */

     public boolean getTeCalled() {
          return teCalled;
     }


     /**
      *  Get the current Oracle connection
      *  @return the current Oracle connection;
      *          if no connection currently exists, a new one is established and
      *          returned.
      */

     public Connection getConnection()
     throws Exception
     {
        return connection;
     }


     /**
      *  Close the current Oracle connection
      *  @exception Exception if there are SQL code errors
      */

     public void closeConnection() throws Exception {
        connection.close ();
        connection = null;
     }


     /**
      *  Call Sync Null
      *  @exception Exception if there are SQL code errors
      */

     public int syncNull() throws Exception {

          String str;
          if (schema == null)
             str = "{? = call pkgsys_tec.exec_all(?)}";
          else
             str = "{? = call " + schema + ".pkgsys_tec.exec_all(?)}";

          OracleCallableStatement stmt =
               (OracleCallableStatement)getConnection().prepareCall(str);
          stmt.setInt(1, 9);        // pre-set syncrc to 9
          stmt.setNull(2, java.sql.Types.CHAR);
          stmt.registerOutParameter(1, java.sql.Types.NUMERIC);

          try {
               stmt.execute();
               syncrc = stmt.getInt(1);
               return syncrc;
          } catch (Exception e) {
               log.error(this, "syncNull(): " + e);
               throw e;
          } finally {
               DBUtil.closeStatement(stmt);
          } // End of try-catch block

     } // End of syncNull()


     /**
      *  Call Sync Commit
      *  @exception Exception if there are SQL code errors
      */

     public int syncCommit() throws Exception {

	  String str;
          if (schema == null)
	     str = "{? = call pkgsys_tec.exec_all(?)}";
          else
	     str = "{? = call " + schema + ".pkgsys_tec.exec_all(?)}";

          OracleCallableStatement stmt =
            (OracleCallableStatement)getConnection().prepareCall(str);
          stmt.setInt(1, 9);        // pre-set syncrc to 9
          stmt.setString(2, "COMMIT");
          stmt.registerOutParameter(1, java.sql.Types.NUMERIC);

          try {
               stmt.execute();
               syncrc = stmt.getInt(1);
               log.debug(this, "syncCommit: syncrc = " + syncrc);
               return syncrc;
          } catch (Exception e) {
               log.error(this, "syncCommit()", e);
               throw e;
          } finally {
               DBUtil.closeStatement(stmt);

          } // End of try-catch block

     } // End of syncCommit()


     /**
      *  Call Sync Rollback
      *  @exception Exception if there are SQL code errors
      */

     public int syncRollback() throws Exception {

	  String str;
          if (schema == null)
	     str = "{? = call pkgsys_tec.exec_all(?)}";
          else
	     str = "{? = call " + schema + ".pkgsys_tec.exec_all(?)}";

          OracleCallableStatement stmt =
             (OracleCallableStatement)getConnection().prepareCall(str);
          stmt.setInt(1, 9);        //pre-set syncrc to 9
          stmt.setString(2, "ROLLBACK");
          stmt.registerOutParameter(1, java.sql.Types.NUMERIC);

          try {
               stmt.execute();
               syncrc = stmt.getInt(1);
               log.debug(this, "syncRollback: syncrc = " + syncrc);
               return syncrc;
          } catch (Exception e) {
               log.error(this, "syncRollback()", e);
               throw e;
          } finally {
               DBUtil.closeStatement(stmt);
          } // End of try-catch block


     } // End of syncRollback()


     public int purgePipe() throws Exception {

          String str;
          if (schema == null)
             str = "{? = call cdb_actions.purge_pipe()}";
          else
             str = "{? = call " + schema + ".cdb_actions.purge_pipe()}";

          OracleCallableStatement stmt =
             (OracleCallableStatement)getConnection().prepareCall(str);
          stmt.registerOutParameter(1, java.sql.Types.NUMERIC);

          try {
               stmt.execute();
               syncrc = stmt.getInt(1);
               log.debug(this, "purge Pipe: rc = " + syncrc);
               return syncrc;
          } catch (Exception e) {
               log.error(this, "purgePipe()", e);
               throw e;
          } finally {
               DBUtil.closeStatement(stmt);
          } // End of try-catch block
     } 


     /**
      *  Get a new Luw Id field
      *  @param inApplId value of Application Id
      *         inClientType value of the Client Type
      *         inUserId value of the User Id
      *  @return the value of the generated Luw Id field
      *  @exception Exception if there are SQL code errors
      */

     public String getLuwId(String inApplId,
                            String inClientType,
                            String inUserId) throws Exception {

/*
          String str = "{? = call logreco.rlog_pkg1.exec_all" +
*/
          String str = "{? = call rlog_pkg1.exec_all" +
               "(?,?,?,?,?)}";
          OracleCallableStatement stmt =
              (OracleCallableStatement)getConnection().prepareCall(str);
          stmt.setString(2, inApplId);
          stmt.setString(3, inClientType);
          stmt.setString(4, inUserId);
          stmt.registerOutParameter(1, java.sql.Types.NUMERIC);
          stmt.registerOutParameter(5, java.sql.Types.CHAR);
          stmt.registerOutParameter(6, java.sql.Types.CHAR);

          try {
               String luwDate = null;
               String seqNum = null;
			   String otherParm = null;
               luwSeq = 0;

               stmt.execute();
               luwDate = stmt.getString(5);
               seqNum = stmt.getString(6);
			   otherParm = stmt.getString(1);

               if (luwDate != null && seqNum != null) {

                   log.debug(this, "getLuwId(): luwDate = " +
                     luwDate.substring(0,8) + " seqNum = " +
                     seqNum.substring(0,8) + " other parm: " + otherParm );

                   luwId = inApplId + inClientType + inUserId +
                         luwDate.substring(0,8) + seqNum.substring(0,8);
               } else {
                   log.error(this, "getLuwId(): " +
                     "Unable to retrieve Luw ID.");
                   luwId = "ERROR";
               }

               stmt.close();

               return luwId;

          } catch (Exception e) {
               log.error(this, "getLuwId()", e);
               luwId = "ERROR";
               return luwId;
          } // End of try-catch block

     } // End of getLuwId()


     /**
      *  Get the current Luw Id field
      *  @return the value of the Luw Id field
      */

     public String getLuwId() {
          return luwId;
     }


     /**
      *  Get the current Luw Sequence field
      *  @return the value of the Luw Sequence field
      */

     public String getLuwSeq(boolean newLuwSeq) {

          String strLuwSeq;

          if (newLuwSeq) {
               if (luwSeq == 99) {
                    luwSeq = 1;
               } else {
                    luwSeq += 1;
               }
               strLuwSeq = String.valueOf(luwSeq);
          } else {
               if (luwSeq == 0) {
                    luwSeq = 1;
               }
               strLuwSeq = String.valueOf(luwSeq);
          } // End of if (newLuwSeq)

          if (strLuwSeq.length() < 2) {
               strLuwSeq = "0" + strLuwSeq;
          }

          return strLuwSeq;
     } // End of getLuwSeq()


     public String getLuwSeq() {
          return getLuwSeq(false);
     }



   /**
    *  Retrieve all the error and warning messages generated by the TE call.
    *  @return a list of all the error and warning messages generated
    *  @exception Exception if there are SQL code errors
    */

   public List readMessages ()
   throws Exception
   {
      OracleCallableStatement stmt = null;
      List result = new LinkedList ();

      String str;
      if (schema == null)
         str = "{? = call pkgsys_svc.read_message" + "(?,?,?,?,?,?,?,?,?,?)}";
      else
         str = "{? = call " + schema + ".pkgsys_svc.read_message" +
          "(?,?,?,?,?,?,?,?,?,?)}";

      stmt = (OracleCallableStatement) getConnection().prepareCall(str);

      try
      {
         stmt.registerOutParameter(1, java.sql.Types.NUMERIC);
         stmt.registerOutParameter(2, java.sql.Types.CHAR);
         stmt.registerOutParameter(3, java.sql.Types.CHAR);
         stmt.registerOutParameter(4, java.sql.Types.CHAR);
         stmt.registerOutParameter(5, java.sql.Types.CHAR);
         stmt.registerOutParameter(6, java.sql.Types.NUMERIC);
         stmt.registerOutParameter(7, java.sql.Types.NUMERIC);
         stmt.registerOutParameter(8, java.sql.Types.NUMERIC);
         stmt.registerOutParameter(9, java.sql.Types.CHAR);
         stmt.registerOutParameter(10, java.sql.Types.CHAR);
         stmt.registerOutParameter(11, java.sql.Types.CHAR);

         while (true)
         {
            stmt.execute();
            int rc = stmt.getInt(1);

            if (rc == 0)
            {
               CCAPITEMessage msg = new CCAPITEMessage();
               result.add (msg);
               msg.setMsgRuleType(stmt.getString(2));
               msg.setMsgEvent(stmt.getString(3));
               msg.setMsgObject(stmt.getString(4));
               msg.setMsgAttribute(stmt.getString(5));
               msg.setMsgType(stmt.getInt(6));
               msg.setMsgNumber(stmt.getLong(7));
               msg.setMsgSqlError(stmt.getLong(8));
               msg.setMsgException(stmt.getString(9));
               String text = stmt.getString (10);
               StringBuffer finalText = new StringBuffer (text.length ());
               for (int i = 0; i < text.length (); i++)
               {
                  char ch = text.charAt (i);

                  if (ch < 128)
                  {
                     finalText.append (ch);
                  }
                  else
                  {
                     String hexValue = getHex (ch);
                     finalText.append (hexValue);
                  }
               }
               msg.setMsgText(finalText.toString ());
               msg.setMsgDate(stmt.getString(11));
            }
            else
            {
               break;
            }
         }
      }
      finally
      {
         stmt.close();
      }
      return result;
   }


   private String getHex (int ch)
   {
      String result = "";
      for (int i = 1; i <= 4; i++)
      {
         int d = ch & 15;
         if (d < 10)
            result = ((char)(d + '0')) + result;
         else
            result = ((char)((d - 10) + 'a')) + result;
         ch = ch >> 4;
      }
      result = "0x" + result;
      return result;
   }


   public String convertCCAPIMessagesToString (List messages)
   {
      StringBuffer ccapiMessageText = new StringBuffer ();

      for (Iterator i = messages.iterator (); i.hasNext (); )
      {
         CCAPITEMessage errorMsg = (CCAPITEMessage) i.next();
         ccapiMessageText.append ("   " + errorMsg.toString () + "\n");
      }
      return ccapiMessageText.toString ();
   }
}
