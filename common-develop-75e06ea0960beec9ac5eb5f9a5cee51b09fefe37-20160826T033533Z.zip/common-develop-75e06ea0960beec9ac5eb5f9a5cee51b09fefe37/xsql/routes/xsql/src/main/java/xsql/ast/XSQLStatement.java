package xsql.ast;

import java.util.*;
import java.io.*;

import org.xml.sax.Locator;
import xsql.*;


/**
A statement defines an action to be performed when it is exeucted.
<p>
XSQL supports several kinds of statements. Each type of statement is
explained in later sections.
*/
abstract public class XSQLStatement
implements Serializable
{
   /**
    * The location of source XML element for this object.
    */
   public transient Locator locator;


   public void execute (StatementContext context)
   throws Exception
   {
   }



}
