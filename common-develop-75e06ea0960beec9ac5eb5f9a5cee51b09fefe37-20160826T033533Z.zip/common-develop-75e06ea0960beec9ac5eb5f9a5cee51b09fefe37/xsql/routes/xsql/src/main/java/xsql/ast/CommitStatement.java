package xsql.ast;

import java.util.*;
import java.io.*;


/**
A <i>commit statement</i> enables the user to commit their current database
activity.  This is useful during an insert-then-update scenario where one
wishes to keep the rollback storage requirements at a reasonable level.
*/
abstract public class CommitStatement extends XSQLStatement
implements Serializable
{


}
