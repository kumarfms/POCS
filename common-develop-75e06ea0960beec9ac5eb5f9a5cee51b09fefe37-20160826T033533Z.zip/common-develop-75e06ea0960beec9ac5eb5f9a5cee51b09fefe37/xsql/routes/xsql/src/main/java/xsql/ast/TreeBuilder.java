package xsql.ast;

import java.util.*;
import java.io.*;
import javax.swing.tree.DefaultMutableTreeNode;
import xsql.util.XMLUtils;

public class TreeBuilder
{


   public void buildTree (DefaultMutableTreeNode top, XSQL x)
   {
      if (x == null) return;

      DefaultMutableTreeNode treeNode =
        new DefaultMutableTreeNode(x);
      top.add(treeNode);
      treeNode.setAllowsChildren (true);
      for (Iterator i = x.statementList.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         buildTree (treeNode, (XSQLStatement) item);
      }
   }


   public void buildTree (DefaultMutableTreeNode top, XSQLStatement x)
   {
      if (x == null) return;

      if (x instanceof IfStatement)
         buildTree (top, (IfStatement) x);
      else if (x instanceof WhileStatement)
         buildTree (top, (WhileStatement) x);
      else if (x instanceof VarStatement)
         buildTree (top, (VarStatement) x);
      else if (x instanceof SetStatement)
         buildTree (top, (SetStatement) x);
      else if (x instanceof EvalStatement)
         buildTree (top, (EvalStatement) x);
      else if (x instanceof WriteStatement)
         buildTree (top, (WriteStatement) x);
      else if (x instanceof LogStatement)
         buildTree (top, (LogStatement) x);
      else if (x instanceof XMLStatement)
         buildTree (top, (XMLStatement) x);
      else if (x instanceof QueryStatement)
         buildTree (top, (QueryStatement) x);
      else if (x instanceof SelectStatement)
         buildTree (top, (SelectStatement) x);
      else if (x instanceof xsql.impl.InsertStatementImpl)
         buildTree (top, (xsql.impl.InsertStatementImpl) x);
      else if (x instanceof xsql.impl.UpdateStatementImpl)
         buildTree (top, (xsql.impl.UpdateStatementImpl) x);
      else if (x instanceof xsql.impl.DeleteStatementImpl)
         buildTree (top, (xsql.impl.DeleteStatementImpl) x);
      else if (x instanceof DefineProc)
         buildTree (top, (DefineProc) x);
      else if (x instanceof CallProcDef)
         buildTree (top, (CallProcDef) x);
      else if (x instanceof TEProcess)
         buildTree (top, (TEProcess) x);
      else if (x instanceof TECall)
         buildTree (top, (TECall) x);
      else if (x instanceof NWPProcess)
         buildTree (top, (NWPProcess) x);
      else if (x instanceof NWPCall)
         buildTree (top, (NWPCall) x);
      else if (x instanceof ImportClass)
         buildTree (top, (ImportClass) x);
      else if (x instanceof DocumentStatement)
         buildTree (top, (DocumentStatement) x);
      else if (x instanceof ThrowStatement)
         buildTree (top, (ThrowStatement) x);
      else if (x instanceof CommitStatement)
         buildTree (top, (CommitStatement) x);
      else if (x instanceof RollbackStatement)
         buildTree (top, (RollbackStatement) x);
   }


   public void buildTree (DefaultMutableTreeNode top, IfStatement ifstatement)
   {
      if (ifstatement == null) return;

      DefaultMutableTreeNode treeNode =
        new DefaultMutableTreeNode(ifstatement);
      top.add(treeNode);
      treeNode.setAllowsChildren (true);
      buildTree (treeNode, ifstatement.thenPart);
      buildTree (treeNode, ifstatement.elsePart);
   }


   public void buildTree (DefaultMutableTreeNode top, ThenPart t)
   {
      if (t == null) return;

      DefaultMutableTreeNode treeNode =
        new DefaultMutableTreeNode(t);
      top.add(treeNode);
      treeNode.setAllowsChildren (true);
      for (Iterator i = t.statementList.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         buildTree (treeNode, (XSQLStatement) item);
      }
   }


   public void buildTree (DefaultMutableTreeNode top, ElsePart e)
   {
      if (e == null) return;

      DefaultMutableTreeNode treeNode =
        new DefaultMutableTreeNode(e);
      top.add(treeNode);
      treeNode.setAllowsChildren (true);
      for (Iterator i = e.statementList.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         buildTree (treeNode, (XSQLStatement) item);
      }
   }


   public void buildTree (DefaultMutableTreeNode top, WhileStatement w)
   {
      if (w == null) return;

      DefaultMutableTreeNode treeNode =
        new DefaultMutableTreeNode(w);
      top.add(treeNode);
      treeNode.setAllowsChildren (true);
      for (Iterator i = w.statementList.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         buildTree (treeNode, (XSQLStatement) item);
      }
   }


   public void buildTree (DefaultMutableTreeNode top, VarStatement v)
   {
      if (v == null) return;

      DefaultMutableTreeNode treeNode =
        new DefaultMutableTreeNode(v);
      top.add(treeNode);
      treeNode.setAllowsChildren (true);
      // buildSimpleNode ("expr", v.longExpr);
   }


   public void buildTree (DefaultMutableTreeNode top, SetStatement s)
   {
      if (s == null) return;

      DefaultMutableTreeNode treeNode =
        new DefaultMutableTreeNode(s);
      top.add(treeNode);
      treeNode.setAllowsChildren (true);
      // buildSimpleNode ("expr", s.longExpr);
   }


   public void buildTree (DefaultMutableTreeNode top, EvalStatement e)
   {
      if (e == null) return;

      DefaultMutableTreeNode treeNode =
        new DefaultMutableTreeNode(e);
      top.add(treeNode);
      treeNode.setAllowsChildren (true);
      // buildSimpleNode ("expr", e.longExpr);
   }


   public void buildTree (DefaultMutableTreeNode top, WriteStatement w)
   {
      if (w == null) return;

      DefaultMutableTreeNode treeNode =
        new DefaultMutableTreeNode(w);
      top.add(treeNode);
      treeNode.setAllowsChildren (true);
      // buildSimpleNode ("value", w.longValue);
   }


   public void buildTree (DefaultMutableTreeNode top, LogStatement l)
   {
      if (l == null) return;

      DefaultMutableTreeNode treeNode =
        new DefaultMutableTreeNode(l);
      top.add(treeNode);
      treeNode.setAllowsChildren (true);
      // buildSimpleNode ("value", l.longValue);
   }


   public void buildTree (DefaultMutableTreeNode top, XMLStatement x)
   {
      if (x == null) return;

      DefaultMutableTreeNode treeNode =
        new DefaultMutableTreeNode(x);
      top.add(treeNode);
      treeNode.setAllowsChildren (true);
      // buildSimpleNode ("value", x.longValue);
      for (Iterator i = x.statementList.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         buildTree (treeNode, (XSQLStatement) item);
      }
   }


   public void buildTree (DefaultMutableTreeNode top, QueryStatement q)
   {
      if (q == null) return;

      if (q instanceof SelectStatement)
         buildTree (top, (SelectStatement) q);
      else if (q instanceof xsql.impl.InsertStatementImpl)
         buildTree (top, (xsql.impl.InsertStatementImpl) q);
      else if (q instanceof xsql.impl.UpdateStatementImpl)
         buildTree (top, (xsql.impl.UpdateStatementImpl) q);
      else if (q instanceof xsql.impl.DeleteStatementImpl)
         buildTree (top, (xsql.impl.DeleteStatementImpl) q);
   }


   public void buildTree (DefaultMutableTreeNode top, SelectStatement s)
   {
      if (s == null) return;

      DefaultMutableTreeNode treeNode =
        new DefaultMutableTreeNode(s);
      top.add(treeNode);
      treeNode.setAllowsChildren (true);
      // buildSimpleNode ("sql", s.sql);
      for (Iterator i = s.args.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         buildTree (treeNode, (xsql.impl.Argument) item);
      }
      for (Iterator i = s.statementList.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         buildTree (treeNode, (XSQLStatement) item);
      }
   }


   public void buildTree (DefaultMutableTreeNode top, xsql.impl.InsertStatementImpl insertstatement)
   {
      if (insertstatement == null) return;

      DefaultMutableTreeNode treeNode =
        new DefaultMutableTreeNode(insertstatement);
      top.add(treeNode);
      treeNode.setAllowsChildren (true);
      // buildSimpleNode ("sql", insertstatement.sql);
      for (Iterator i = insertstatement.args.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         buildTree (treeNode, (xsql.impl.Argument) item);
      }
   }


   public void buildTree (DefaultMutableTreeNode top, xsql.impl.UpdateStatementImpl u)
   {
      if (u == null) return;

      DefaultMutableTreeNode treeNode =
        new DefaultMutableTreeNode(u);
      top.add(treeNode);
      treeNode.setAllowsChildren (true);
      // buildSimpleNode ("sql", u.sql);
      for (Iterator i = u.args.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         buildTree (treeNode, (xsql.impl.Argument) item);
      }
   }


   public void buildTree (DefaultMutableTreeNode top, xsql.impl.DeleteStatementImpl d)
   {
      if (d == null) return;

      DefaultMutableTreeNode treeNode =
        new DefaultMutableTreeNode(d);
      top.add(treeNode);
      treeNode.setAllowsChildren (true);
      // buildSimpleNode ("sql", d.sql);
      for (Iterator i = d.args.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         buildTree (treeNode, (xsql.impl.Argument) item);
      }
   }


   public void buildTree (DefaultMutableTreeNode top, DefineProc d)
   {
      if (d == null) return;

      DefaultMutableTreeNode treeNode =
        new DefaultMutableTreeNode(d);
      top.add(treeNode);
      treeNode.setAllowsChildren (true);
      buildTree (treeNode, d.definition);
   }


   public void buildTree (DefaultMutableTreeNode top, StoredProcDef s)
   {
      if (s == null) return;

      DefaultMutableTreeNode treeNode =
        new DefaultMutableTreeNode(s);
      top.add(treeNode);
      treeNode.setAllowsChildren (true);
      buildTree (treeNode, s.returnParameter);
      for (Iterator i = s.parameterList.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         buildTree (treeNode, (xsql.impl.Parameter) item);
      }
   }


   public void buildTree (DefaultMutableTreeNode top, ParameterDef p)
   {
      if (p == null) return;

      DefaultMutableTreeNode treeNode =
        new DefaultMutableTreeNode(p);
      top.add(treeNode);
      treeNode.setAllowsChildren (false);
   }


   public void buildTree (DefaultMutableTreeNode top, CallProcDef c)
   {
      if (c == null) return;

      DefaultMutableTreeNode treeNode =
        new DefaultMutableTreeNode(c);
      top.add(treeNode);
      treeNode.setAllowsChildren (true);
      for (Iterator i = c.args.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         buildTree (treeNode, (xsql.impl.Argument) item);
      }
      for (Iterator i = c.statementList.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         buildTree (treeNode, (XSQLStatement) item);
      }
   }


   public void buildTree (DefaultMutableTreeNode top, ArgumentDef a)
   {
      if (a == null) return;

      DefaultMutableTreeNode treeNode =
        new DefaultMutableTreeNode(a);
      top.add(treeNode);
      treeNode.setAllowsChildren (true);
      // buildSimpleNode ("value", a.longValue);
   }


   public void buildTree (DefaultMutableTreeNode top, TEProcess t)
   {
      if (t == null) return;

      DefaultMutableTreeNode treeNode =
        new DefaultMutableTreeNode(t);
      top.add(treeNode);
      treeNode.setAllowsChildren (true);
      for (Iterator i = t.statementList.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         buildTree (treeNode, (XSQLStatement) item);
      }
   }


   public void buildTree (DefaultMutableTreeNode top, TECall t)
   {
      if (t == null) return;

      DefaultMutableTreeNode treeNode =
        new DefaultMutableTreeNode(t);
      top.add(treeNode);
      treeNode.setAllowsChildren (true);
      for (Iterator i = t.args.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         buildTree (treeNode, (xsql.impl.Argument) item);
      }
   }


   public void buildTree (DefaultMutableTreeNode top, NWPProcess n)
   {
      if (n == null) return;

      DefaultMutableTreeNode treeNode =
        new DefaultMutableTreeNode(n);
      top.add(treeNode);
      treeNode.setAllowsChildren (true);
      for (Iterator i = n.statementList.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         buildTree (treeNode, (XSQLStatement) item);
      }
   }


   public void buildTree (DefaultMutableTreeNode top, NWPCall n)
   {
      if (n == null) return;

      DefaultMutableTreeNode treeNode =
        new DefaultMutableTreeNode(n);
      top.add(treeNode);
      treeNode.setAllowsChildren (true);
      for (Iterator i = n.args.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         buildTree (treeNode, (xsql.impl.Argument) item);
      }
   }


   public void buildTree (DefaultMutableTreeNode top, ImportClass importclass)
   {
      if (importclass == null) return;

      DefaultMutableTreeNode treeNode =
        new DefaultMutableTreeNode(importclass);
      top.add(treeNode);
      treeNode.setAllowsChildren (false);
   }


   public void buildTree (DefaultMutableTreeNode top, DocumentStatement d)
   {
      if (d == null) return;

      DefaultMutableTreeNode treeNode =
        new DefaultMutableTreeNode(d);
      top.add(treeNode);
      treeNode.setAllowsChildren (false);
   }


   public void buildTree (DefaultMutableTreeNode top, ThrowStatement t)
   {
      if (t == null) return;

      DefaultMutableTreeNode treeNode =
        new DefaultMutableTreeNode(t);
      top.add(treeNode);
      treeNode.setAllowsChildren (true);
      // buildSimpleNode ("reason", t.elementReason);
   }


   public void buildTree (DefaultMutableTreeNode top, CommitStatement c)
   {
      if (c == null) return;

      DefaultMutableTreeNode treeNode =
        new DefaultMutableTreeNode(c);
      top.add(treeNode);
      treeNode.setAllowsChildren (false);
   }


   public void buildTree (DefaultMutableTreeNode top, RollbackStatement r)
   {
      if (r == null) return;

      DefaultMutableTreeNode treeNode =
        new DefaultMutableTreeNode(r);
      top.add(treeNode);
      treeNode.setAllowsChildren (false);
   }
}
