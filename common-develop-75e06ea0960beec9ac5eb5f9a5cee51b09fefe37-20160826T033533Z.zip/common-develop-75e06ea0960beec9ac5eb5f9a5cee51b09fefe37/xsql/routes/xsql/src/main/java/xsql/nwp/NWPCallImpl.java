package xsql.nwp;

import xsql.util.*;
import xsql.*;
import xsql.impl.*;
import xsql.expr.*;
import xsql.ast.*;
import java.sql.*;
import java.util.*;
import xsql.jdbc.Database;
import xsql.jdbc.StoredProcResult;

public class NWPCallImpl extends NWPCall
{
   private StatementContext context;
   private SymbolTable      symtab;
   private Logger logger = null;
   private String schemaName = null;
   private String defineProcName = null;
   private Database db = null;
   private StoredProcDefImpl def = null;

   private static NWPErrorAnalyzer errorAnalyzer = new NWPErrorAnalyzer ();

   public void execute (StatementContext context)
   throws Exception
   {
      this.context = context;
      logger = context.getLogger ();
      symtab = context.getSymbolTable ();
      db = context.getDatabase ();

      NWPProcessStatus status = (NWPProcessStatus) symtab.
        lookup (NWPProcessImpl.NWP_PROCESS_STATUS_NAME);
      if (status == null)
      {
         String reason =
           "NWP Call is outside the scope of a NWP Process Statement.";
         throw new XSQLRuntimeException (reason);
      }
      status.numCallsMade += 1;

      ElementNode myDoc = new ElementNode ("call-nwp-" + packageName);
      ElementNode parentDoc = context.getCurrentXMLDocument ();
      parentDoc.addChild (myDoc);

      CCAPIServices ccapiServices = status.ccapiServices;
      this.schemaName = ccapiServices.getSchema ();
      int rc = executeNWPCall (ccapiServices, myDoc);

      List ccapiMessages = ccapiServices.readMessages ();

      ElementNode ccapiMessageDoc = convertCCAPIMessagesToXML (ccapiMessages);
      status.nwpMessages.add (ccapiMessageDoc);
      myDoc.addChild (ccapiMessageDoc);

      if (rc == 1)
      {
         String message =
           "The NWP call returned the following warning message(s):\n" +
           ccapiServices.convertCCAPIMessagesToString (ccapiMessages);
         logger.warning (message);
      }
      if (rc > 1)
      {
         if (errorAnalyzer.isCriticalError (ccapiMessages))
         {
            String message =
              "A critical error occurred processing a NWP call. " +
              "The NWP call returned the following error message(s):\n" +
              ccapiServices.convertCCAPIMessagesToString (ccapiMessages);

            throw new NWPRuntimeException (message);
         }
         else
         {
            String message =
              "The NWP call returned the following error message(s):\n" +
              ccapiServices.convertCCAPIMessagesToString (ccapiMessages);
            logger.error (message);
            status.nwpCallFailed = true;
            status.failedCall = this;
            throw new NWPProcessBreakException ();
         }
      }
   }

   public int executeNWPCall (CCAPIServices ccapiServices,
                             ElementNode myDoc)
   throws Exception
   {
      String message = "Calling ";

      if (schemaName != null)
         message += (schemaName + ".");

      message += (packageName + "." + procedureName);

      logger.info (this, message);

      resolveInstanceVariables ();

      def = getStoredProcDef ();

      CallProc cp = createCallProc (def);

      cp.checkArgList ();

      StoredProcResult result = db.makeCall (cp);

      if (name != null)
      {
         symtab.add (name, result);
      }

      myDoc.addRecordFields (result);
      Object returnValue = result.getFieldValue (def.returnParameter.name);
      message = "NWP return value: " + returnValue.toString ();
      logger.info (this, message);
      int rc = Integer.parseInt (returnValue.toString ());
      return rc;
   }


   private ElementNode convertCCAPIMessagesToXML (List messages)
   {
      ElementNode document = new ElementNode("ccapi-messages");

      for (Iterator i = messages.iterator (); i.hasNext (); )
      {
         CCAPIMessage errorMsg = (CCAPIMessage) i.next();
         TextElementNode errorMessageHeader =
           new TextElementNode("message", errorMsg.toString());
         document.addChild (errorMessageHeader);
      }
      return document;
   }

   public StoredProcDefImpl getStoredProcDef ()
   throws Exception
   {
      if (def != null) return def;

      if (defineProcName == null)
      {
         def = db.getStoredProcDef (schemaName,
                                    packageName,
                                    procedureName,
                                    null,
                                    null);
      }
      else
      {
         def = (StoredProcDefImpl) symtab.lookupGlobal(defineProcName);

         if (def == null)
         {
            String reason = "A stored procedure named " + defineProcName
              + " is not defined.";
            throw new XSQLRuntimeException (reason);
         }
      }

      return def;
   }

   private void resolveInstanceVariables ()
   throws Exception
   {
      this.packageName = context.resolveExpressions (this.packageName);
      this.procedureName = context.resolveExpressions (this.procedureName);
      this.schemaName = context.resolveExpressions (this.schemaName);
   }

   private CallProc createCallProc (StoredProcDefImpl def)
   throws Exception
   {
      CallProc cp = new CallProc ();
      cp.args = this.args;
      cp.defineProcName = this.defineProcName;
      cp.name = this.name;
      cp.packageName = this.packageName;
      cp.procedureName = this.procedureName;
      cp.schemaName = this.schemaName;
      cp.def = def;
      return cp;
   }
}
