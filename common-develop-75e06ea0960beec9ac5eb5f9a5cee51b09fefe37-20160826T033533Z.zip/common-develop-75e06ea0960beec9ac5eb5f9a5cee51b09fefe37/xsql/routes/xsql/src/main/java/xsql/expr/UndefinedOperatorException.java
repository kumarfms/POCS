package xsql.expr;

public class UndefinedOperatorException extends ExpressionException
{
   public UndefinedOperatorException (String operator)
   {
      super (buildMessage (operator));
   }


   private static String buildMessage (String operator)
   {
      String message = "Undefined operator :: " + operator;

      return message;
   }
}
