package xsql.impl;

import java.util.*;
import java.io.*;

import xsql.*;
import xsql.ast.*;
import xsql.expr.*;

public class EvalStatementImpl extends EvalStatement
{
   public void execute (StatementContext context)
   throws Exception
   {
      String expr = getExpr ();
      Object value = context.evalExpression (expr);
   }


   private String getExpr ()
   {
      if (expr != null)
         return expr;
      else
         return longExpr;
   }
}
