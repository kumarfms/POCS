package xsql;

import java.util.*;
import java.io.*;
import xsql.ast.*;
import xsql.expr.*;


public class XSQLRuntimeException extends XSQLException
{
   private XSQLStatement statement;


   public XSQLRuntimeException (Throwable cause)
   {
      super (cause.getMessage (), cause);
   }


   public XSQLRuntimeException (String message)
   {
      super (message);
   }


   public XSQLRuntimeException (String message, Throwable cause)
   {
      super (message, cause);
   }


   public XSQLRuntimeException (XSQLStatement statement,
                                String message,
                                Throwable cause)
   {
      super (message, cause);
      this.statement = statement;
   }


   public void setStatement (XSQLStatement statement)
   {
      this.statement = statement;
   }


   public XSQLStatement getStatement ()
   {
      return this.statement;
   }


   public int getLine ()
   {
      if (statement == null)
         return 0;
      else
      {
         int line = statement.locator.getLineNumber ();
         return line;
      }
   }
}
