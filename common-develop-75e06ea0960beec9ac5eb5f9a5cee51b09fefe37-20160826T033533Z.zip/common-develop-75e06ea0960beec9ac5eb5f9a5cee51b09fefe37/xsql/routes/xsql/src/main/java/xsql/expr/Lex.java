package xsql.expr;

public class Lex extends LexAnalyzer
{
   public static final int string_sym = LexAnalyzer.string_sym;
   public static final int number_sym = LexAnalyzer.number_sym;
   public static final int identifier_sym = LexAnalyzer.identifier_sym;
   public static final int rbracket = 1000;
   public static final int dot = 1001;
   public static final int minus = 1002;
   public static final int lbracket = 1003;
   public static final int comma = 1004;
   public static final int plus = 1005;
   public static final int star = 1006;
   public static final int less_than_equal = 1007;
   public static final int rparen = 1008;
   public static final int ampersand_ampersand = 1009;
   public static final int lparen = 1010;
   public static final int percent = 1011;
   public static final int exclamation = 1012;
   public static final int equal_equal = 1013;
   public static final int bar_bar = 1014;
   public static final int greater_than = 1015;
   public static final int less_than = 1016;
   public static final int greater_than_equal = 1017;
   public static final int exclamation_equal = 1018;
   public static final int slash = 1019;

   String [] getSpecialSyms ()
   {
      return new String [] {
                 "]",
                 ".",
                 "-",
                 "[",
                 ",",
                 "+",
                 "*",
                 "<=",
                 ")",
                 "&&",
                 "(",
                 "%",
                 "!",
                 "==",
                 "||",
                 ">",
                 "<",
                 ">=",
                 "!=",
                 "/" };
   }

   String [] getKeywords ()
   {
      return new String [] {
                  };
   }
}
