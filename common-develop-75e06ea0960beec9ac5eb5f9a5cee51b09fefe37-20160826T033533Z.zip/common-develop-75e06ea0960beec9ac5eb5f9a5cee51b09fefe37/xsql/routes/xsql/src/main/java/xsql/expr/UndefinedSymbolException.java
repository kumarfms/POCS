package xsql.expr;

public class UndefinedSymbolException extends ExpressionException
{
   public UndefinedSymbolException (String symbolName)
   {
      super (buildMessage (symbolName));
   }


   private static String buildMessage (String symbolName)
   {
      return "Undefined symbol :: " + symbolName;
   }
}
