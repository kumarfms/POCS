package xsql.ast;

import java.util.*;
import java.io.*;


/**
The <i>select statement</i> is used to read data from a database
and store the result in an XML document.
*/
abstract public class SelectStatement extends QueryStatement
implements Serializable
{
   /**
    * The value to be used for the surrounding XML document tag for each
    * record returned from the record set.
    */
   public String  recordTag;
   /**
    * Defines a list of XSQL statements to be executed.
    * These statements will be executed for each row returned
    * by the select statement. Before these statements are executed
    * the current XML document will be set to the element produced
    * for the associated row. Thus, these statements will add any
    * XML document they produce to the document for the row.
    * 
    */
   public List  statementList = new LinkedList ();


}
