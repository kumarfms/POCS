package xsql.nwp;

import xsql.*;
import xsql.ast.*;

import java.util.*;

public class NWPProcessStatus
{
   public boolean nwpCallFailed = false;
   public NWPCallImpl failedCall = null;
   public int numCallsMade = 0;
   public CCAPIServices ccapiServices;
   public List nwpMessages = new LinkedList ();
}
