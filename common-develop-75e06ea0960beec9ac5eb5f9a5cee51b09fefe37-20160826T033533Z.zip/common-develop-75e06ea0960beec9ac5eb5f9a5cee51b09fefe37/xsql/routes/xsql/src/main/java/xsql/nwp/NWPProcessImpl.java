package xsql.nwp;

import xsql.*;
import xsql.expr.*;
import xsql.ast.*;
import xsql.impl.*;
import xsql.util.*;
import java.sql.*;
import java.util.*;
import java.io.*;


public class NWPProcessImpl extends NWPProcess
implements NWPGlobalDefs
{
   public static final String NWP_PROCESS_STATUS_NAME = "NWP_PROCESS_STATUS";
   private SymbolTable symtab = null;
   private StatementContext context;
   private Logger logger = null;


   public void execute (StatementContext context)
   throws Exception
   {
      this.context = context;
      logger = context.getLogger ();
      symtab = context.getSymbolTable ();

      logger.info ("Beginning NWP Process: " + name);
      
      NWPProcessStatus status =
        (NWPProcessStatus) symtab.lookupGlobal (NWP_PROCESS_STATUS_NAME);
      if (status != null)
      {
         String reason =
           "This NWP process is nested inside another NWP process.";
         throw new XSQLRuntimeException (reason);
      }

      status = new NWPProcessStatus ();
      status.ccapiServices = establishCCAPIServices();
      symtab.addGlobal (NWP_PROCESS_STATUS_NAME, status);
      
      boolean nwpProcessCompleted = false;
      try
      {
         context.executeStatementList(statementList);
         commitNWPProcess (status);
         nwpProcessCompleted = true;
      }
      catch (NWPProcessBreakException e)
      {
         // Stop the exception from propagating and rollback the process.
         context.setConnectionValid (false);
         rollbackNWPProcess (status);
         nwpProcessCompleted = true;
      }
      finally
      {
         if (!nwpProcessCompleted)
         {
            context.setConnectionValid (false);
            rollbackNWPProcess (status);
         }
         symtab.addGlobal (NWP_PROCESS_STATUS_NAME, null);
      }
   }
   
   
   private synchronized CCAPIServices establishCCAPIServices ()
   throws Exception
   {
      String schema = this.schema;
      Connection dbConn = context.getDefaultConnection ();
      CCAPIServices ccapiServices = new CCAPIServices (dbConn, schema, logger);
      return ccapiServices;
   }
   
   
   private void commitNWPProcess (NWPProcessStatus status)
   throws Exception
   {
      CCAPIServices ccapiServices = status.ccapiServices;
      
      if(status.numCallsMade > 0)
      {
         logger.debug (this, "Committing NWP process");

         Connection dbConn = ccapiServices.getConnection ();
         dbConn.commit ();

         String msg =
           "NWP Process completed successfully, commit performed. "
           + status.numCallsMade + " NWP call(s) made.";
         logger.info (this, msg);
      }
   }


   private void rollbackNWPProcess (NWPProcessStatus status)
   throws Exception
   {
      CCAPIServices ccapiServices = status.ccapiServices;
      
      if (status.numCallsMade > 0)
      {
         logger.debug (this, "Rolling back NWP process");

         Connection dbConn = ccapiServices.getConnection ();
         dbConn.rollback ();

         String msg =
           "NWP Process completed with errors, rollback performed. "
           + status.numCallsMade + " NWP call(s) made.";
         logger.error (this, msg);
      }
   }
}
