package xsql.impl;

import java.util.*;
import java.io.*;

import xsql.*;
import xsql.ast.*;

public class XMLStatementImpl extends XMLStatement
{
   public void execute (StatementContext context)
   throws Exception
   {
      ElementNode currentDocument = (ElementNode)
        context.getCurrentXMLDocument ();
      String v = getValue ();
      if (v != null)
      {
         v = context.resolveExpressions (v);
         currentDocument.addChild (new TextElementNode (tag, v, attributes));
      }
      else
      {
         ElementNode newDocument = new ElementNode (tag, attributes);
         currentDocument.addChild (newDocument);
         context.setCurrentXMLDocument (newDocument);
         try
         {
            context.executeStatementList (statementList);
         }
         finally
         {
            context.setCurrentXMLDocument (currentDocument);
         }
      }
   }


   private String getValue ()
   {
      if (value != null)
         return value;
      else
         return longValue;
   }
}
