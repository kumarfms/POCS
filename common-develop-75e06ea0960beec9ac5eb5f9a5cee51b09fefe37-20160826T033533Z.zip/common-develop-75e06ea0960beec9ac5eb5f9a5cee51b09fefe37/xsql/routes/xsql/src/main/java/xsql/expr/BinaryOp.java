package xsql.expr;

public class BinaryOp extends Node
{
   public String opSymbol;
   public Node left;
   public Node right;
   public Object leftValue;
   public Object rightValue;


   public BinaryOp (ExpressionContext context,
                    String opSymbol,
                    Node left,
                    Node right)
   {
      super (context);
      this.opSymbol = opSymbol;
      this.left = left;
      this.right = right;
      left.parent = this;
      right.parent = this;
   }


   public void evalOperands ()
   throws Exception
   {
      leftValue = left.eval ();
      rightValue = right.eval ();
   }


   public void prepareValuesForArithmeticOp ()
   throws Exception
   {
      if (leftValue instanceof Double || rightValue instanceof Double)
      {
         leftValue = toDouble (leftValue);
         rightValue = toDouble (rightValue);
      }   
      else if (leftValue instanceof Long || rightValue instanceof Long)
      {
         leftValue = toLong (leftValue);
         rightValue = toLong (rightValue);
      }   
      else if (leftValue.toString().indexOf ('.') != -1 ||
        rightValue.toString().indexOf ('.') != -1)
      {
         leftValue = toDouble (leftValue);
         rightValue = toDouble (rightValue);
      }
      else
      {
         leftValue = toInteger (leftValue);
         rightValue = toInteger (rightValue);
      }   
   }


   public void prepareValuesForRelationalOp ()
   throws Exception
   {
      if (leftValue instanceof Number || rightValue instanceof Number)
      {
         prepareValuesForArithmeticOp ();
      }   
      else
      {
         leftValue = toString (leftValue);
         rightValue = toString (rightValue);
      }   
   }


   public void prepareValuesForAddOp ()
   throws Exception
   {
      if (leftValue instanceof String || rightValue instanceof String)
      {
         leftValue = toString (leftValue);
         rightValue = toString (rightValue);
      }   
      else
      {
         prepareValuesForArithmeticOp ();
      }   
   }


   public void prepareValuesForLogicalOp ()
   throws Exception
   {
      leftValue = toBoolean (leftValue);
      rightValue = toBoolean (rightValue);
   }
}
