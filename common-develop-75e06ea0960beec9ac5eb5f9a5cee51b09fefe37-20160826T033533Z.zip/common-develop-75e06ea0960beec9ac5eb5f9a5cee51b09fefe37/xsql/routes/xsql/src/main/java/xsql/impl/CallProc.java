package xsql.impl;

import java.util.Iterator;
import java.util.List;

import xsql.XSQLRuntimeException;
import xsql.StatementContext;
import xsql.ast.CallProcDef;
import xsql.expr.Field;
import xsql.expr.SymbolTable;
import xsql.impl.StoredProcDefImpl;
import xsql.jdbc.Database;
import xsql.jdbc.RecordSet;
import xsql.util.Logger;
import xsql.jdbc.StoredProcResult;

public class CallProc extends CallProcDef
{
   private SymbolTable symbolTable = null;
   private StatementContext context = null;
   private Logger logger = null;
   private Database db = null;
   public StoredProcDefImpl def;

   public void execute (StatementContext context)
   throws Exception
   { 
      ElementNode parentDoc = null;
      
      this.context = context;
      logger = context.getLogger ();
      parentDoc = context.getCurrentXMLDocument(); 
      symbolTable = context.getSymbolTable();
      db = context.getDatabase ();
      
      try
      { 
         logger.info (this, "Executing call-proc statement named " + name);
         resolveInstanceVariables ();
         
         def = getStoredProcDef ();

         checkArgList ();

         StoredProcResult result = db.makeCall (this); 
         
         symbolTable.add(name, result);

         ElementNode myDoc = new ElementNode(name);
         parentDoc.addChild(myDoc);
         context.setCurrentXMLDocument(myDoc);

         // Copy the non-null record fields to the document,
         // except for the resultant record set, if one exists.
         // The rows of the record set will be copied during the
         // processing of the dependent statements.
         copyRecordFields (myDoc, result);
         
         RecordSet recordSet = result.getRecordSet ();         
         if (recordSet != null)
         {
            if (recordSet.length () > 0)
            {
               ElementNode recordSetNode = new ElementNode(recordSet.getName ());
               myDoc.addChild(recordSetNode);
               context.setCurrentXMLDocument(recordSetNode);

               ForeachStatementImpl.processDependentStatements
                 (context, recordSet, statementList);
            }
         }
         else
         {
            ForeachStatementImpl.processDependentStatements
              (context, recordSet, statementList);
         }
      }
      catch (Exception e)
      {
         String logMsg =
           "Unable to execute call-proc statement named " + this.name;
         throw new XSQLRuntimeException (logMsg, e);
      }
      finally
      {
         context.setCurrentXMLDocument(parentDoc);
      }
   }


   public StoredProcDefImpl getStoredProcDef ()
   throws Exception
   {
      if (def != null) return def;
      
      if (defineProcName == null) 
      {
         def = db.getStoredProcDef (schemaName,   
                                    packageName, 
                                    procedureName,
                                    recordSetTag, 
                                    recordTag);
      } 
      else
      {
         def = (StoredProcDefImpl) symbolTable.lookupGlobal(defineProcName);
        
         if (def == null) 
         {
            String reason = "A stored procedure named " + defineProcName
              + " is not defined.";
            throw new XSQLRuntimeException (reason);
         }
         else
         {
            logger.info(this,"Obtained stored procedure definition inline to program.");
         }
      }
      
      return def;
   }


   public Argument getArgument(String argName)
   throws Exception
   {
      for (Iterator i = args.iterator(); i.hasNext();)
      {
         Argument a = (Argument) i.next ();
         if (a.name.equals(argName))
         {
            return a;
         }
      }
      return null;
   }

   
   private void resolveInstanceVariables ()
   throws Exception
   {
      this.packageName = context.resolveExpressions (this.packageName);
      this.procedureName = context.resolveExpressions (this.procedureName);
      this.schemaName = context.resolveExpressions (this.schemaName);
      this.recordSetTag = context.resolveExpressions (this.recordSetTag);
      this.recordTag = context.resolveExpressions (this.recordTag);
   }
   
   /**
   * Copies the non-null record fields of the StoredProcResult
   * to the document, except for the resultant record set,
   * if one exists.
   */
   public void copyRecordFields (ElementNode doc,
                                 StoredProcResult result)
   {
      List fieldList = result.getFieldList ();
      RecordSet recordSet = result.getRecordSet ();         
      for (Iterator i = fieldList.iterator (); i.hasNext(); )
      {
         Field f = (Field) i.next ();
         if (f.value != null)
         {
            if (f.value != recordSet)
               doc.addChild (new TextElementNode (f.name, f.value)); 
         }
      }
   }
   
   public void checkArgList ()
   throws Exception
   {
      for (Iterator i = args.iterator (); i.hasNext ();)
      {
         Argument arg = (Argument) i.next ();
         Parameter p = null;
         if (arg.name != null)
         { 
            if (arg.pos != null)
            {
               String errMsg =
                 "A name and position cannot both be specified for an " +
                 "argument.";
               throw new XSQLRuntimeException (errMsg);
            }

            p = def.getParameter (arg.name);
            if (p == null)
            {
               String errMsg = "Undefined parameter for argument whose " +
                               "name = " + arg.name;
               throw new XSQLRuntimeException (errMsg);
            }
            else if (p.isOutParameter && !p.isInParameter)
            {
               Object value = arg.getValue ();
               if (value != null)
               {
                  String logMsg =
                    "Argument named  "  + p.name + " was for " +
                    "an output parameter.  Provided value will be ignored.";
                  logger.info (this, logMsg);
               }
            }
         }
         else if (arg.pos != null)
         {
            int position = arg.pos.intValue ();
            
            p = def.getParameter (position);

            if (p == null)
            {
               String errMsg = "Undefined parameter for argument whose " +
                               "position = " + position;
               throw new XSQLRuntimeException (errMsg);
            }
            else if (p.pos.intValue () == 1 && def.returnParameter != null)
            {
               String errMsg =
                 "Cannot specify an argument with position = 1 when " +
                 "stored procedure also has a return parameter.";
               throw new XSQLRuntimeException (errMsg);               
            }
            else if (p.isOutParameter && !p.isInParameter)
            {
               Object value = arg.getValue ();
               if (value != null)
               {
                  String logMsg =
                    "Argument specified for position " + position + " was for" +
                    " an output parameter.  Provided value will be ignored.";
                  logger.info (this, logMsg);
               }
            }
            
            arg.name = p.name;
         }
         else
         {
            String errMsg =
              "A name or position must be specified for an " +
              "argument.";
            throw new XSQLRuntimeException (errMsg);
         }
      }
   }
   
   public String getSQL ()
   {
      if (def != null)
         return def.getSQL ();
      else
         return null;
   }
   
   public Parameter getReturnParameter ()
   {
      if (def != null)
         return def.returnParameter;
      else
         return null;
   }
   
   public List getParameterList ()
   {
      if (def != null)
         return def.getParameterList (); 
      else
         return null;
   }
   
   public String getRecordSetTag ()
   {
      if (def != null)
      {
         String recordSetTag = def.recordSetTag;
         if (recordSetTag == null)
            return ("recordSet");
         else
            return recordSetTag;
      }
      else
      {
         return null;
      }
   }
   
   public String getRecordTag ()
   {
      if (def != null)
      {
         String recordTag = def.recordTag;
         if (recordTag == null)
            return ("record");
         else
            return recordTag;
      }
      else
      {
         return null;
      }
   }
}
