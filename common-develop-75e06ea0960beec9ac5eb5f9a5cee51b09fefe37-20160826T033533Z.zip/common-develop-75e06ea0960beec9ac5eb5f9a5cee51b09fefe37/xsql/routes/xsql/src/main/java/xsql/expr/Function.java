package xsql.expr;

import java.lang.reflect.Method;

public class Function
{
   public Object obj;
   public String methodName;

   public Function (Object obj, String name)
   {
      this.obj = obj;
      methodName = name; 
   }
}
