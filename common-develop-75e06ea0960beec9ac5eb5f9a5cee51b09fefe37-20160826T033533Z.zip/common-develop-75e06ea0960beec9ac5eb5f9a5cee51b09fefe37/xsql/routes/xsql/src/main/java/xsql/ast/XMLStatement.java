package xsql.ast;

import java.util.*;
import java.io.*;


/**
An <i>XML statement</i> adds an element to the current XML document.
*/
abstract public class XMLStatement extends XSQLStatement
implements Serializable
{
   /**
    * The tag for the element to be added.
    */
   public String  tag;
   /**
    * The text contents of the element.
    */
   public String  value;
   /**
    * The text contents of the element specified by an element instead
    * of an attribute.
    */
   public String  longValue;
   /**
    * A list of attributes to be added to the xml element.
    */
   public List  attributes = new LinkedList ();
   /**
    * Defines a list of XSQL statements to be executed.
    * These statements will
    * add any XML they produce to the element created by this statement.
    */
   public List  statementList = new LinkedList ();


}
