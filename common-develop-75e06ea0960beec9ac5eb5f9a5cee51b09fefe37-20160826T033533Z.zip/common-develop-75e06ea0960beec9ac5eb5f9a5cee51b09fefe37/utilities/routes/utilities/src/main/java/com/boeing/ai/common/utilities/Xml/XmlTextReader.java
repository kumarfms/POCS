/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 04-14-2016
 * Authors      : Tim Schramer
 * File         : XmlTextReader.java - .NET type functionality in Java
 *                (based on code from:
 *                 https://github.com/twiglet/cs2j/tree/master/CSharpTranslator)
 *-----------------------------------------------------------------------------
 * Revision History (Release 1.0.0)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *--------------|-------------------|------------------------------------------
 * -.-.-/1.0.0  | Tim Schramer      | New
 *              | 04-14-2016        |
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.utilities.Xml;
/*---------------------------------------------------------------------------*/
import java.io.IOException;
import java.io.StringReader;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;
import com.boeing.ai.common.utilities.NotImplementedException;
import com.boeing.ai.common.utilities.Xml.XmlDocument;
/*---------------------------------------------------------------------------*/
public class XmlTextReader {
    protected XmlDocument xmlDocument = null;

    protected XmlDocument getXmlDocument() throws ParserConfigurationException {
        if (xmlDocument == null) {
            xmlDocument = new XmlDocument();
        }
        return xmlDocument;
    }
    public XmlTextReader() throws NotImplementedException {
        throw new NotImplementedException();
    }

    public XmlTextReader(StringReader stringReader) throws NotImplementedException, ParserConfigurationException, SAXException, IOException {
        getXmlDocument().load(stringReader);
    }

    public String ToString() throws ParserConfigurationException {
        return getXmlDocument().getOuterXml();
    }
}

