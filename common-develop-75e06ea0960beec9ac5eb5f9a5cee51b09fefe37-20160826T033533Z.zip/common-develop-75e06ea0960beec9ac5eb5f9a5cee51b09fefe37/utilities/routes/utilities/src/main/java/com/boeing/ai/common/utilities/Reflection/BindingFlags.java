/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 04-14-2016
 * Authors      : Tim Schramer
 * File         : BindingFlags.java - .NET type functionality in Java
 *                (based on code from:
 *                 https://github.com/twiglet/cs2j/tree/master/CSharpTranslator)
 *-----------------------------------------------------------------------------
 * Revision History (Release 1.0.0)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *--------------|-------------------|------------------------------------------
 * -.-.-/1.0.0  | Tim Schramer      | New
 *              | 04-14-2016        |
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.utilities.Reflection;
/*---------------------------------------------------------------------------*/
public class BindingFlags {
    // It doesn't seem to be defined what is DEFAULT, and it also doesn't seem
    // to be defined what is getFields with no flags.
    // Here we assume no flags == DEFAULT, and we make up a likely DEFAULT
    public static int getDefault() {
        return getPublic() | getInstance();
    }

    public static int getIgnoreCase() {
        return 2;
    }

    public static int getDeclaredOnly() {
        return 4;
    }

    public static int getInstance() {
        return 8;
    }

    public static int getStatic() {
        return 0x10;
    }

    public static int getPublic() {
        return 0x20;
    }

    public static int getNonPublic() {
        return 0x40;
    }

    public static int getFlattenHierarchy() {
        return 0x80;
    }
}

