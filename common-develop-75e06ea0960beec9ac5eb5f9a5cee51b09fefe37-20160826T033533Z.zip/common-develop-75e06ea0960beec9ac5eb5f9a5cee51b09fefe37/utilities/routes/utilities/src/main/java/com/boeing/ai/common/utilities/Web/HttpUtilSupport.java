/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 04-14-2016
 * Authors      : Tim Schramer
 * File         : HttpUtilSupport.java - .NET type functionality in Java
 *                (based on code from:
 *                 https://github.com/twiglet/cs2j/tree/master/CSharpTranslator)
 *-----------------------------------------------------------------------------
 * Revision History (Release 1.0.1)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *--------------|-------------------|------------------------------------------
 * -.-.-/1.0.0  | Tim Schramer      | New
 *              | 04-14-2016        |
 *--------------|-------------------|------------------------------------------
 * 1.0.0/1.0.1  | Tim Schramer      | Added URIEncode() method. 
 *              | 04-21-2016        | 
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.utilities.Web;
/*---------------------------------------------------------------------------*/
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import org.apache.commons.lang.*;
/*---------------------------------------------------------------------------*/
public class HttpUtilSupport {
    public static String HtmlEncode(String s) {
        if (s == null)
            return "";
        return StringEscapeUtils.escapeHtml(s);
    }

    public static String HtmlDecode(String s) {
        if (s == null)
            return "";
        return StringEscapeUtils.unescapeHtml(s);
    }

    public static String UrlEncode(String s) throws UnsupportedEncodingException {
        if (s == null)
            return "";
        return java.net.URLEncoder.encode(s, "UTF-8");
    }

    public static String UrlDecode(String s) throws UnsupportedEncodingException {
        if (s == null)
            return "";
        return java.net.URLDecoder.decode(s, "UTF-8");
    }

    // Safe URI string encoding
    // http://stackoverflow.com/questions/724043/http-url-address-encoding-in-java
    // Preprocess the encoding with a trim() and explicit encoding, although the latter
    // may be unnecessary, ie:
    //
    //    new String(Charset.forName("UTF-8").uriencode(q).array(), "ISO-8859-1").trim();
    //
    // The trim() is needed as uriencode() appends null bytes at the end which the String
    // constructor doesn't remove.
    // _______________________________________________________________________________
    public static String URIEncode(String input) throws UnsupportedEncodingException {
        String utf8String = "";
        if (input != null) {
            // Preprocess string for UTF-8 before encoding
            utf8String = new String(Charset.forName("utf-8").encode(input).array(), "ISO-8859-1").trim();
            utf8String = uriencode(utf8String);
        }
        return utf8String;
    }
    public static String uriencode(String input) {
        StringBuilder resultStr = new StringBuilder();
        for (char ch : input.toCharArray()) {
            if (isUnsafe(ch)) {
                resultStr.append('%');
                resultStr.append(toHex(ch / 16));
                resultStr.append(toHex(ch % 16));
            } else {
                resultStr.append(ch);
            }
        }
        return resultStr.toString();
    }
    private static char toHex(int ch) {
        return (char) (ch < 10 ? '0' + ch : 'A' + ch - 10);
    }
    private static boolean isUnsafe(char ch) {
        if (ch > 128 || ch < 0)
            return true;
        return " %$&+,/:;=?@<>#%".indexOf(ch) >= 0;
    }
}

