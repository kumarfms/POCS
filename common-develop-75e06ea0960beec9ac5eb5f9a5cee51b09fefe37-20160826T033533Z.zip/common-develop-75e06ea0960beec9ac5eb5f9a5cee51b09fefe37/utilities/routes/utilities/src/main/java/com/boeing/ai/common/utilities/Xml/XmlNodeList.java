/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 04-14-2016
 * Authors      : Tim Schramer
 * File         : XmlNodeList.java - .NET type functionality in Java
 *                (based on code from:
 *                 https://github.com/twiglet/cs2j/tree/master/CSharpTranslator)
 *-----------------------------------------------------------------------------
 * Revision History (Release 1.0.0)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *--------------|-------------------|------------------------------------------
 * -.-.-/1.0.0  | Tim Schramer      | New
 *              | 04-14-2016        |
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.utilities.Xml;
/*---------------------------------------------------------------------------*/
import java.util.AbstractList;
import org.w3c.dom.NodeList;
/*---------------------------------------------------------------------------*/
public class XmlNodeList extends AbstractList<XmlNode> {
    private NodeList ns;

    protected XmlNodeList() {

    }

    public XmlNodeList(NodeList in_ns) {
        ns = in_ns;
    }

    public XmlNode get(int arg0) {
        return XmlNode.wrapNode(ns.item(arg0));
    }

    public boolean isEmpty() {
        return ns.getLength() > 0;
    }


    public int size() {
        return ns.getLength();
    }
}

