/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 04-14-2016
 * Authors      : Tim Schramer
 * File         : SocketFlags.java - .NET type functionality in Java
 *                (based on code from:
 *                 https://github.com/twiglet/cs2j/tree/master/CSharpTranslator)
 *-----------------------------------------------------------------------------
 * Revision History (Release 1.0.0)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *--------------|-------------------|------------------------------------------
 * -.-.-/1.0.0  | Tim Schramer      | New
 *              | 04-14-2016        |
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.utilities.Net.Sockets;
/*---------------------------------------------------------------------------*/
public enum SocketFlags {
    None,		//	Use no flags for this call.
    OutOfBand,	//	Process out-of-band data.
    Peek,		//	Peek at the incoming message.
    DontRoute,	//	Send without using routing tables.
    MaxIOVectorLength,	//	Provides a standard value for the number of WSABUF structures that are used to send and receive data.
    Truncated,	//	The message was too large to fit into the specified buffer and was truncated.
    ControlDataTruncated,	//	Indicates that the control data did not fit into an internal 64-KB buffer and was truncated.
    Broadcast,	//	Indicates a broadcast packet.
    Multicast,	//	Indicates a multicast packet.
    Partial	//	Partial send or receive for message.
}

