/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 04-14-2016
 * Authors      : Tim Schramer
 * File         : DirectorySupport.java - .NET type functionality in Java
 *                (based on code from:
 *                 https://github.com/twiglet/cs2j/tree/master/CSharpTranslator)
 *-----------------------------------------------------------------------------
 * Revision History (Release 1.0.0)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *--------------|-------------------|------------------------------------------
 * -.-.-/1.0.0  | Tim Schramer      | New
 *              | 04-14-2016        |
 *--------------|-------------------|------------------------------------------
 * 1.0.0/1.0.1  | Tim Schramer      | Added verifyDirectory() method. 
 *              | 04-21-2016        | 
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.utilities.IO;
/*---------------------------------------------------------------------------*/
import com.boeing.ai.common.utilities.StringSupport;
import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Pattern;
/*---------------------------------------------------------------------------*/
public class DirectorySupport {
    // Support for patterns containing ? and * characters.  .
    private static String globToRegex(String filePattern) {

        StringBuilder ret = new StringBuilder();
        // remember start of current literal sequence
        int litStart = 0;
        for (int i = 0; i < filePattern.length(); i++) {
            char c = filePattern.charAt(i);
            if (c == '*') {
                if (litStart < i) {
                    ret.append(Pattern.quote(filePattern.substring(litStart, i)));
                }
                litStart = i + 1;
                ret.append(".*");
            } else if (c == '?') {
                if (litStart < i) {
                    ret.append(Pattern.quote(filePattern.substring(litStart, i)));
                }
                litStart = i + 1;
                ret.append('.');
            }
        }
        if (litStart < filePattern.length()) {
            ret.append(Pattern.quote(filePattern.substring(litStart, filePattern.length())));
        }
        return ret.toString();
    }

    // This filter only returns files
    private static FilenameFilter fileFilter = new FilenameFilter() {
        public boolean accept(File dir, String file) {
            return new File(dir, file).isFile();
        }
    };

    // This filter only returns files
    private static FilenameFilter fileFilter(String filePattern) {
        final String globPattern = globToRegex(filePattern);
        return new FilenameFilter() {
            public boolean accept(File dir, String file) {
                boolean isFile = new File(dir, file).isFile();
                boolean isMatch = file.matches(globPattern);
                return isFile && isMatch;
            }
        };
    }

    // This filter only returns directories
    private static FilenameFilter dirFilter = new FilenameFilter() {
        public boolean accept(File dir, String file) {
            return new File(dir, file).isDirectory();
        }
    };

    // This filter only returns files
    private static FilenameFilter dirFilter(String filePattern) {
        final String globPattern = globToRegex(filePattern);
        return new FilenameFilter() {
            public boolean accept(File dir, String file) {
                boolean isDir = new File(dir, file).isDirectory();
                boolean isMatch = file.matches(globPattern);
                return isDir && isMatch;
            }

        };
    }

    // Implementation of Directory.GetFiles(path)
    public static String[] getFiles(String path) throws IOException {
        File[] allFiles = new File(path).listFiles(DirectorySupport.fileFilter);

        String[] allFilePaths = new String[allFiles.length];

        for (int i = 0; i < allFilePaths.length; i++) {
            allFilePaths[i] = allFiles[i].getAbsolutePath();
        }

        return allFilePaths;

    }

    // Implementation of Directory.GetFiles(path,searchpattern)
    public static String[] getFiles(String path, String searchpattern) throws IOException {
        // In .Net Directory.GetFiles, if the searchpattern contains directory path separators
        // then it will search subdirs.

        ArrayList<String> allMatches = new ArrayList<String>();

        // we split on both / and \ characters
        String[] patternComponents = searchpattern.split("[/\\\\]",2);

        if (patternComponents.length > 1) {
            File[] matchDirs = new File(path).listFiles(DirectorySupport.dirFilter(patternComponents[0]));
            for (File d : matchDirs) {
                allMatches.addAll(Arrays.asList(getFiles(d.getAbsolutePath(),patternComponents[1])));
            }

        } else
        {
            File[] allFiles = new File(path).listFiles(DirectorySupport.fileFilter(searchpattern));


            for (int i = 0; i < allFiles.length; i++) {
                allMatches.add(i,((File)allFiles[i]).getAbsolutePath());
            }
        }

        return allMatches.toArray(new String[allMatches.size()]);

    }

    // Implementation of Directory.GetDirectories()
    public static String[] getDirectories(String path) throws IOException {

        File[] allDirs = new File(path).listFiles(DirectorySupport.dirFilter);

        String[] allDirPaths = new String[allDirs.length];

        for (int i = 0; i < allDirPaths.length; i++) {
            allDirPaths[i] = allDirs[i].getAbsolutePath();
        }

        return allDirPaths;
    }

    // Implementation of Directory.Delete)
    public static void delete(String path, boolean recursive) throws IOException {
        File dp = new File(path);
        if (!dp.isDirectory())
            throw new IOException("Directory expected");

        if (recursive) {
            String[] children = dp.list();
            for (int i=0; i<children.length; i++) {
                File child = new File(dp, children[i]);
                if (child.isDirectory())
                    DirectorySupport.delete(child.getPath(), true);
                else
                    child.delete();
            }
        } else
            // Will fail if not writeable, empty
            dp.delete();
    }

    // Check for valid directory and make if it doesn't exist.
    // Note: verbose logic is due to isDirectory() call returning true for files. - TGS
    public static Boolean verifyDirectory(String directory) {
        File verifydir;
        Boolean check = false;

        if (StringSupport.isBlank(directory)) {
            check = false;
        } else {
            try {
                verifydir = new File(directory);
                if (!verifydir.exists()) {
                    verifydir.mkdirs();
                    check = true;
                } else if (verifydir.isDirectory()) {
                    check = true;
                } else {
                    check = false;
                }
            } catch (Exception e) {
                check = false;
            }
        }
        return check;
    }
}

