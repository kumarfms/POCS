/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 04-14-2016
 * Authors      : Tim Schramer
 * File         : FileNotFoundException.java - .NET type functionality in Java
 *                (based on code from:
 *                 https://github.com/twiglet/cs2j/tree/master/CSharpTranslator)
 *-----------------------------------------------------------------------------
 * Revision History (Release 1.0.0)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *--------------|-------------------|------------------------------------------
 * -.-.-/1.0.0  | Tim Schramer      | New
 *              | 04-14-2016        |
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.utilities.IO;
/*---------------------------------------------------------------------------*/
public class FileNotFoundException extends Exception {
    /**
     *
     */
    private static final long serialVersionUID = 5653568996987933925L;
    /**
     *
     */

    private String fileName = null;

    /**
     * @param arg0
     */
    public FileNotFoundException(String arg0) {
        super(arg0);
        // TODO Auto-generated constructor stub
    }

    public FileNotFoundException(String message, String fileName) {
        super(message);
        this.fileName = fileName;
    }

    /**
     * @param arg0
     */
    public FileNotFoundException(Throwable arg0) {
        super(arg0);
        // TODO Auto-generated constructor stub
    }

    /**
     * @param arg0
     * @param arg1
     */
    public FileNotFoundException(String arg0, Throwable arg1) {
        super(arg0, arg1);
        // TODO Auto-generated constructor stub
    }

}

