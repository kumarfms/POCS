/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 04-14-2016
 * Authors      : Tim Schramer
 * File         : Disposable.java - .NET type functionality in Java
 *                (based on code from:
 *                 https://github.com/twiglet/cs2j/tree/master/CSharpTranslator)
 *-----------------------------------------------------------------------------
 * Revision History (Release 1.0.0)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *--------------|-------------------|------------------------------------------
 * -.-.-/1.0.0  | Tim Schramer      | New
 *              | 04-14-2016        |
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.utilities.LCC;
/*---------------------------------------------------------------------------*/
import java.io.Closeable;
import com.boeing.ai.common.utilities.LCC.IDisposable;
/*---------------------------------------------------------------------------*/
public class Disposable implements IDisposable {
    private Closeable closerVal = null;
    private IDisposable dispVal = null;

    public static Disposable mkDisposable(Closeable obj) {
        Disposable ret = new Disposable();
        ret.closerVal = obj;
        return ret;
    }

    public static Disposable mkDisposable(IDisposable obj) {
        Disposable ret = new Disposable();
        ret.dispVal = obj;
        return ret;
    }

    /* (non-Javadoc)
     * @see com.boeing.ai.common.utilities.IDisposable#Dispose()
     */
    public void dispose() throws Exception {
        if (dispVal != null)
            dispVal.dispose();
        else if (closerVal != null)
            closerVal.close();
    }
}

