package com.boeing.ai.fuse.framework;

import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Context {
	
	private static final transient Logger LOG = LoggerFactory.getLogger(Context.class);

	protected static ThreadLocalContext context = new ThreadLocalContext();

	protected HashMap<String, Object> properties = new HashMap<String, Object>();

	public static Context getInstance() throws Exception {
		return context.get();
	}

	public void destroy() {
		context.remove();
	}

	public void setProperty(String name, Object value) {
		properties.put(name, value);
	}

	public Object getProperty(String name) {
		return properties.get(name);
	}
	
	public void removeProperty(String name) {
		properties.remove(name);
	}
}
