package com.boeing.ai.fuse.framework.sched;

import java.util.*;

/**
A <i>timer</i> keeps track of list of scheduled tasks along with the earliest
time they should execute.
When the time they should execute occurs, the timer calls their execute method
and removes them from the list.
<p>
This class implements the singleton pattern, because
only one instance of the timer is needed to notify zero or more instances
of scheduled tasks.
*/
public class Timer extends Thread
{
   /**
    * The period in milliseconds that the timer checks for tasks which need
    * to be executed.
    */
   public static final long TIMER_RESOLUTION = 1000;

   private static Timer instance = new Timer ();
   private boolean started = false;
   private Vector<ScheduledTask> tasks = new Vector<ScheduledTask> (100);

   /**
    * Creates an instance of timer.
    */
   public Timer ()
   {
   }


   /**
    * Returns the singleton instance of the timer.
    */
   public static Timer getInstance ()
   {
      return instance;
   }


   /**
    * Adds a scheduled task to the list of registered tasks.
    */
   public synchronized void add (ScheduledTask task)
   {
      if (!started)
      {
         start ();
         started = true;
      }

      tasks.add (task);
   }


   /**
    * Implements the run method of a timer thread. It repeatedly
    * performs the following steps:
    * <ul>
    * <li>sleeps for the <code>TIMER_RESOLUTION</code>,
    * <li> and then checks for tasks which need execution.
    * </ul>
    */
   public void run ()
   {
      while (true)
      {
         delay (TIMER_RESOLUTION);
         updateTime ();
      }
   }


   private synchronized void delay (long timeout)
   {
      try
      {
         wait (timeout);
      }
      catch (InterruptedException e)
      {
      }
   }


   private synchronized void updateTime ()
   {
      Date currentTime = new Date ();
      List<ScheduledTask> ready = new LinkedList<ScheduledTask> ();
      for (ScheduledTask task: tasks)
      {
         if (currentTime.compareTo (task.getTimeToExecute ()) >= 0)
         {
            ready.add (task);
         }
      }
      for (ScheduledTask task: ready)
      {
         tasks.remove (task);
         task.run ();
      }
   }
}
