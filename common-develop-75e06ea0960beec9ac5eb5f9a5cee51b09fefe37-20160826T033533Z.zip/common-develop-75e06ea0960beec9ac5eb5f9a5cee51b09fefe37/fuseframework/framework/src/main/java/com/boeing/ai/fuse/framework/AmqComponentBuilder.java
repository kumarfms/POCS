package com.boeing.ai.fuse.framework;

import java.util.Dictionary;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.ActiveMQSslConnectionFactory;
import org.apache.activemq.ActiveMQXAConnectionFactory;
import org.apache.activemq.RedeliveryPolicy;
import org.apache.activemq.jms.pool.GenericResourceManager;
import org.apache.activemq.pool.JcaPooledConnectionFactory;
import org.apache.activemq.pool.PooledConnectionFactory;
import org.apache.aries.blueprint.ParserContext;
import org.apache.aries.blueprint.mutable.MutableBeanMetadata;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Element;

public class AmqComponentBuilder extends JmsComponentBuilder {

	private static final transient Logger LOG = LoggerFactory.getLogger(AmqComponentBuilder.class);
	
	

	public MutableBeanMetadata buildConnectionFactory(ParserContext parserContext, Element element, Dictionary<String,Object> properties, String concurrentConsumers) {

		// redelivery policy
    	MutableBeanMetadata redeliveryPolicyMeta = parserContext.createMetadata(MutableBeanMetadata.class);
    	redeliveryPolicyMeta.setRuntimeClass(RedeliveryPolicy.class);
    	redeliveryPolicyMeta.addProperty("maximumRedeliveries", createValue(parserContext,getValue(properties,"maximumRedeliveries","-1")));
    	
    	// amq connection factory
    	MutableBeanMetadata amqCFMetadata = parserContext.createMetadata(MutableBeanMetadata.class);
    	if (xa) {
    		amqCFMetadata.setRuntimeClass(ActiveMQXAConnectionFactory.class);
    	} else if (ssl) {
    		amqCFMetadata.setRuntimeClass(ActiveMQSslConnectionFactory.class);
    	} else {
    		amqCFMetadata.setRuntimeClass(ActiveMQConnectionFactory.class);
    	}
		String brokerURL = getValue(properties,"brokerURL","failover:(tcp://localhost:61616)").trim();
		String brokerURLArgs = getValue(properties,"brokerURLArgs","").trim();
		String brokerURLArgsAttribute =  element.getAttribute(FwJmsComponent.BROKERURL_ARGS).trim();
		if (!brokerURLArgsAttribute.equals("")) {
			if (brokerURL.contains("?")) {
				brokerURL += brokerURLArgsAttribute;
			} else {
				brokerURL = brokerURL + "?" + brokerURLArgsAttribute;
			}
		} else { // do we have defaults?
			if (!brokerURLArgs.equals("")) {
				if (brokerURL.contains("?")) {
					brokerURL += brokerURLArgs;
				} else {
					brokerURL = brokerURL + "?" + brokerURLArgs;
				}
			}
		}

		String trustStore = ssl ? getValue(properties,"trustStore","") : "";
		String trustStorePassword = ssl ? getValue(properties,"trustStorePassword","") : "";

		amqCFMetadata.addProperty("brokerURL", createStringValue(parserContext,brokerURL));
		amqCFMetadata.addProperty("userName", createStringValue(parserContext,getValue(properties,"username","admin").trim()));
		amqCFMetadata.addProperty("password", createStringValue(parserContext,getValue(properties,"password","admin").trim()));
		amqCFMetadata.addProperty("redeliveryPolicy", redeliveryPolicyMeta);
		
		if(ssl && (!trustStore.equals(""))&& (!trustStorePassword.equals(""))){
			amqCFMetadata.addProperty("trustStore", createStringValue(parserContext,trustStore));
			amqCFMetadata.addProperty("trustStorePassword", createStringValue(parserContext,trustStorePassword));
		}

		
		// connection pool
		MutableBeanMetadata connectionPoolMeta = parserContext.createMetadata(MutableBeanMetadata.class);
		if (xa) {
			connectionPoolMeta.setRuntimeClass(JcaPooledConnectionFactory.class);
		} else {
			connectionPoolMeta.setRuntimeClass(PooledConnectionFactory.class);
		}
    	
		connectionPoolMeta.setInitMethod("start");
		connectionPoolMeta.setDestroyMethod("stop");
		if (xa) {
			connectionPoolMeta.addProperty("name",createValue(parserContext,id + ".brokerCP"));
		}
		connectionPoolMeta.addProperty("connectionFactory", amqCFMetadata);
		connectionPoolMeta.addProperty("maxConnections", createValue(parserContext,concurrentConsumers));

		//  setup the recovery manager
		if (xa) {
			MutableBeanMetadata resourceManagerMeta = parserContext.createMetadata(MutableBeanMetadata.class);
			resourceManagerMeta.setRuntimeClass(GenericResourceManager.class);
			resourceManagerMeta.setInitMethod("recoverResource");
			resourceManagerMeta.setId("resourceManager-" + id);
			resourceManagerMeta.addProperty("connectionFactory",amqCFMetadata);
			resourceManagerMeta.addProperty("transactionManager",  createValue(parserContext,recoverableTransactionManager));
			resourceManagerMeta.addProperty("resourceName",createValue(parserContext,id + ".brokerCP"));
			
			parserContext.getComponentDefinitionRegistry().registerComponentDefinition(resourceManagerMeta);
		}
		
		return connectionPoolMeta;
	}

	
}
