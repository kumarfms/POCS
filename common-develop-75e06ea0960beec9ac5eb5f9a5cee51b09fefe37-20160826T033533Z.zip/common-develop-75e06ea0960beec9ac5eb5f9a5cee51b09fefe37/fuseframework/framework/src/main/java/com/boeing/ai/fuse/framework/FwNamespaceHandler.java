package com.boeing.ai.fuse.framework;

import java.net.URL;
import java.util.Arrays;
import java.util.Dictionary;
import java.util.HashSet;
import java.util.Set;

import javax.transaction.TransactionManager;

import org.apache.aries.blueprint.ComponentDefinitionRegistry;
import org.apache.aries.blueprint.NamespaceHandler;
import org.apache.aries.blueprint.ParserContext;
import org.apache.aries.blueprint.PassThroughMetadata;
import org.apache.aries.blueprint.mutable.MutableBeanMetadata;
import org.apache.aries.blueprint.mutable.MutablePassThroughMetadata;
import org.apache.aries.blueprint.mutable.MutableRefMetadata;
import org.apache.aries.blueprint.mutable.MutableReferenceMetadata;
import org.apache.aries.blueprint.mutable.MutableValueMetadata;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;
import org.osgi.service.blueprint.container.ComponentDefinitionException;
import org.osgi.service.blueprint.reflect.BeanMetadata;
import org.osgi.service.blueprint.reflect.ComponentMetadata;
import org.osgi.service.blueprint.reflect.Metadata;
import org.osgi.service.blueprint.reflect.RefMetadata;
import org.osgi.service.blueprint.reflect.ReferenceMetadata;
import org.osgi.service.blueprint.reflect.ValueMetadata;
import org.osgi.service.cm.Configuration;
import org.osgi.service.cm.ConfigurationAdmin;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.boeing.ai.fuse.framework.internal.CmUtils;
import com.boeing.ai.fuse.framework.internal.ManagedObjectManager;

import org.apache.karaf.jaas.jasypt.handler.*;
import org.jasypt.encryption.*;

public class FwNamespaceHandler implements NamespaceHandler {

    public static final String ID_ATTRIBUTE = "id";
    public static final String PERSISTENT_ID_ATTRIBUTE = "persistent-id";
    private static final String MANAGED_OBJECT_MANAGER_NAME = "com.boeing.ai.fuse.framework.managedObjectManager";
    
    
    public FwNamespaceHandler(){
    	super();
    }

	private int idCounter;

    public int getIdCounter() {
        return idCounter;
    }

    public void setIdCounter(int idCounter) {
        this.idCounter = idCounter;
    }
	
	@Override
	public ComponentMetadata decorate(Node element, ComponentMetadata compoentMetadata, ParserContext parserContext) {
		throw new ComponentDefinitionException("Unsupported element location for element: " + element.getNodeName());
	}

	@Override
	public Set<Class> getManagedClasses() {
		return new HashSet<Class>(Arrays.asList(
                FwJmsComponent.class
        ));
	}

	@Override
	public URL getSchemaLocation(String arg0) {
		return this.getClass().getClassLoader().getResource("schema/framework.xsd");
	}

	@Override
	public Metadata parse(Element element, ParserContext parserContext) {

		Metadata result = null;
		String error = null;
		
		ComponentDefinitionRegistry registry = parserContext.getComponentDefinitionRegistry();
		registerManagedObjectManager(parserContext, registry);
		Set<String> names = registry.getComponentDefinitionNames();
		
		PassThroughMetadata blueprintBundleContextMeta = (PassThroughMetadata)registry.getComponentDefinition("blueprintBundleContext");
		BundleContext bundleContext = (BundleContext)blueprintBundleContextMeta.getObject();
		
		//add decrypter component to context
		if((element.getLocalName().equals("framework")) && (!parserContext.getComponentDefinitionRegistry().containsComponentDefinition("decrypter"))){
				addPropertyPlaceholder(parserContext, bundleContext, element);
		}
		else if (element.getLocalName().equals("jmsComponent")) {
			result = parseImportComponent(parserContext,element);
			
			if(!parserContext.getComponentDefinitionRegistry().containsComponentDefinition("decrypter")){
				addPropertyPlaceholder(parserContext, bundleContext, element);
			}
				

			ServiceReference configurationAdminReference =  bundleContext.getServiceReference(ConfigurationAdmin.class.getName());

	        if (configurationAdminReference != null) 
	        {  
	            ConfigurationAdmin configAdmin = (ConfigurationAdmin) bundleContext.getService(configurationAdminReference);

	            Configuration config = null;
	            try {
	            	config = CmUtils.getConfiguration(configAdmin, element.getAttribute(PERSISTENT_ID_ATTRIBUTE));           
			        if (config != null) {
			        	Dictionary<String,Object> properties = config.getProperties();
			            if (properties != null) {
			            	
			            	String type = element.getAttribute(PERSISTENT_ID_ATTRIBUTE).substring(0,3);
			            	
			            	// has the pid overridden the type?
			            	if (properties.get("type") != null) {
			            		type = (String)properties.get("type");
			            	}
			            	
			            	if (type.equals("amq")) {
			            		new AmqComponentBuilder().build(parserContext, bundleContext, element, properties);
			            		
			            	} else if (type.equals("wmq")) {
			            		new WmqComponentBuilder().build(parserContext, bundleContext, element, properties);
			            		
			            	} else if (type.equals("oaq")) {
			            		new OaqComponentBuilder().build(parserContext, bundleContext, element, properties);
			            		
			            	} else {
			            		error = new String("unkown broker type: " + type);
			            	}
			            
			            }
			        } else {
			        	error = new String("no configuraion available for PID: " + element.getAttribute(PERSISTENT_ID_ATTRIBUTE));
			        }
	            } catch (Exception ex) {
	            	error = ex.toString();
	            }
		        
		        bundleContext.ungetService(configurationAdminReference);
	        }
			
		} else {
			 throw new ComponentDefinitionException("Unsupported element: " + element.getNodeName());
		}
		
		if (error != null) {
			throw new ComponentDefinitionException(error);
		}
	
		return result;
	}

    private ComponentMetadata parseImportComponent(ParserContext context, Element element) {
        MutableBeanMetadata metadata = context.createMetadata(MutableBeanMetadata.class);
        metadata.setProcessor(true);
        metadata.setId(getId(context, element));
        metadata.setScope(BeanMetadata.SCOPE_SINGLETON);
        metadata.setRuntimeClass(FwJmsComponent.class);
        metadata.setInitMethod("init");
        metadata.setDestroyMethod("destroy");
        metadata.addProperty("blueprintContainer", createRef(context, "blueprintContainer"));
        metadata.addProperty("configAdmin", createConfigurationAdminRef(context));
        metadata.addProperty("persistentId", createStringValue(context, element.getAttribute(PERSISTENT_ID_ATTRIBUTE)));
        metadata.addProperty("id", createStringValue(context, element.getAttribute(PERSISTENT_ID_ATTRIBUTE)));
        metadata.addProperty("managedObjectManager", createRef(context, MANAGED_OBJECT_MANAGER_NAME));
       

        //PlaceholdersUtils.validatePlaceholder(metadata, context.getComponentDefinitionRegistry());
        
        return metadata;
    }

    public String getId(ParserContext context, Element element) {
        if (element.hasAttribute(ID_ATTRIBUTE)) {
            return "fw-" + element.getAttribute(ID_ATTRIBUTE);
        } else {
            return generateId(context);
        }
    }
    private String generateId(ParserContext context) {
        String id;
        do {
            id = "fw-" + ++idCounter;
        } while (context.getComponentDefinitionRegistry().containsComponentDefinition(id));
        return id;
    }
    private static RefMetadata createRef(ParserContext context, String value) {
        MutableRefMetadata m = context.createMetadata(MutableRefMetadata.class);
        m.setComponentId(value);
        return m;
    }
    
    private void registerManagedObjectManager(ParserContext context, ComponentDefinitionRegistry registry) {
        if (registry.getComponentDefinition(MANAGED_OBJECT_MANAGER_NAME) == null) {
            MutableBeanMetadata beanMetadata = context.createMetadata(MutableBeanMetadata.class);
            beanMetadata.setScope(BeanMetadata.SCOPE_SINGLETON);
            beanMetadata.setId(MANAGED_OBJECT_MANAGER_NAME);
            beanMetadata.setRuntimeClass(ManagedObjectManager.class);            
            registry.registerComponentDefinition(beanMetadata);
        }
    }

    private MutableReferenceMetadata createConfigurationAdminRef(ParserContext context) {
        return createServiceRef(context, ConfigurationAdmin.class, null);
    }
    
    private MutableReferenceMetadata createServiceRef(ParserContext context, Class<?> cls, String filter) {
        MutableReferenceMetadata m = context.createMetadata(MutableReferenceMetadata.class);
        m.setRuntimeInterface(cls);
        m.setInterface(cls.getName());
        m.setActivation(ReferenceMetadata.ACTIVATION_EAGER);
        m.setAvailability(ReferenceMetadata.AVAILABILITY_MANDATORY);
        
        if (filter != null) {
            m.setFilter(filter);
        }
        
        return m;
    }

    private static ValueMetadata createStringValue(ParserContext context, String value) {
        return createValue(context, value, null);
    }
    private static ValueMetadata createValue(ParserContext context, String value, String type) {
        MutableValueMetadata m = context.createMetadata(MutableValueMetadata.class);
        m.setStringValue(value);
        m.setType(type);
        return m;
    }
    
    //Decrypter
    
    private void addPropertyPlaceholder(ParserContext parserContext, BundleContext bundleContext, Element element) {
    	
    	StringEncryptor stringEncryptor =null;
    	
    	ServiceReference strEncryptorReference =  bundleContext.getServiceReference(StringEncryptor.class.getName());
    	
    	if(strEncryptorReference!=null)
    		stringEncryptor = (StringEncryptor) bundleContext.getService(strEncryptorReference);
    	else
    		return;
    	
    	MutableBeanMetadata metadata = parserContext.createMetadata(MutableBeanMetadata.class);
        metadata.setProcessor(true);
        //metadata.setId(getId(parserContext, element));
        metadata.setId("decrypter");
        metadata.setScope(BeanMetadata.SCOPE_SINGLETON);
        metadata.setRuntimeClass(EncryptablePropertyPlaceholder.class);
        metadata.setInitMethod("init");
        metadata.addProperty("placeholderPrefix", createValue(parserContext,"ENC("));
        metadata.addProperty("placeholderSuffix", createValue(parserContext, ")"));
        metadata.addProperty("encryptor", createValue(parserContext,stringEncryptor));
        
        parserContext.getComponentDefinitionRegistry().registerComponentDefinition(metadata);
        
    }
    
    private static ValueMetadata createValue(ParserContext context, String value) {
        return createValue(context, value, null);
    }
    
	protected MutablePassThroughMetadata createValue(ParserContext context, Object value) { 
		MutablePassThroughMetadata v = context.createMetadata(MutablePassThroughMetadata.class);
		v.setObject(value);
		return v;
	}

}
