package com.boeing.ai.fuse.framework;

import java.util.Dictionary;
import java.util.Properties;

import oracle.jms.AQjmsFactory;

import org.apache.activemq.jms.pool.GenericResourceManager;
import org.apache.activemq.jms.pool.JcaPooledConnectionFactory;
import org.apache.activemq.jms.pool.PooledConnectionFactory;
import org.apache.aries.blueprint.ParserContext;
import org.apache.aries.blueprint.mutable.MutableBeanMetadata;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Element;

public class OaqComponentBuilder extends JmsComponentBuilder {

	private static final transient Logger LOG = LoggerFactory.getLogger(OaqComponentBuilder.class);
	
	
	public MutableBeanMetadata buildConnectionFactory(ParserContext parserContext, Element element, Dictionary<String,Object> properties, String concurrentConsumers) {
		    	
    	// oqa connection factory
    	MutableBeanMetadata omqCFMetadata = parserContext.createMetadata(MutableBeanMetadata.class);
    	omqCFMetadata.setRuntimeClass(AQjmsFactory.class);
    	omqCFMetadata.addArgument(createValue(parserContext,getValue(properties,"jdbcURL","").trim()),null,0);
    	
    	Properties configProperties = new Properties();
    	configProperties.setProperty("user", getValue(properties,"username","").trim());
    	configProperties.setProperty("password", getValue(properties,"password","").trim());
    	omqCFMetadata.addArgument(createValue(parserContext,configProperties),null,1);
    	
    	if (xa) {
    		omqCFMetadata.setFactoryMethod("getXAConnectionFactory");
    	} else {
    		omqCFMetadata.setFactoryMethod("getConnectionFactory");
    	}
    	
//    	   <bean id="aqjms-xa-connection-factory" class="oracle.jms.AQjmsFactory" factory-method="getXAConnectionFactory">
//           <argument value="jdbc:oracle:thin:@//ussedv76.cs.boeing.com:14550/db0096d1.boeingdb"/>
//           <argument>
//               <props>
//                   <prop key="user" value="a2ar"/>
//                   <prop key="password" value="a2ar"/>
//               </props>
//           </argument>
//        </bean>

//    	if (xa) {
//    		omqCFMetadata.setRuntimeClass(AQjmsXAConnectionFactory.class);
//    	} else {
//    		omqCFMetadata.setRuntimeClass(AQjmsConnectionFactory.class);
//    	}
//
//		omqCFMetadata.addProperty("jdbcURL", createStringValue(parserContext,getValue(properties,"jdbcURL","").trim()));
//		omqCFMetadata.addProperty("username", createStringValue(parserContext,getValue(properties,"username","").trim()));
//		omqCFMetadata.addProperty("password", createStringValue(parserContext,getValue(properties,"password","").trim()));
//    
		// connection pool
		MutableBeanMetadata connectionPoolMeta = parserContext.createMetadata(MutableBeanMetadata.class);
		if (xa) {
			connectionPoolMeta.setRuntimeClass(JcaPooledConnectionFactory.class);
		} else {
			connectionPoolMeta.setRuntimeClass(PooledConnectionFactory.class);
		}
    	
		connectionPoolMeta.setInitMethod("start");
		connectionPoolMeta.setDestroyMethod("stop");
		if (xa) {
			connectionPoolMeta.addProperty("name",createValue(parserContext,id + ".brokerCP"));
		}
		connectionPoolMeta.addProperty("connectionFactory", omqCFMetadata);
		connectionPoolMeta.addProperty("maxConnections", createValue(parserContext,concurrentConsumers));

		//  setup the recovery manager
		if (xa) {
			MutableBeanMetadata resourceManagerMeta = parserContext.createMetadata(MutableBeanMetadata.class);
			resourceManagerMeta.setRuntimeClass(GenericResourceManager.class);
			resourceManagerMeta.setInitMethod("recoverResource");
			resourceManagerMeta.setId("resourceManager-" + id);
			resourceManagerMeta.addProperty("connectionFactory",omqCFMetadata);
			resourceManagerMeta.addProperty("transactionManager",  createValue(parserContext,recoverableTransactionManager));
			resourceManagerMeta.addProperty("resourceName",createValue(parserContext,id + ".brokerCP"));
			
			parserContext.getComponentDefinitionRegistry().registerComponentDefinition(resourceManagerMeta);
		}
		
		return connectionPoolMeta;
	}

	
}
