package com.boeing.a2a.transaction;

import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.boeing.ai.fuse.framework.Context;

public class TransactionContext {

	private static final Logger LOG = LoggerFactory.getLogger(TransactionContext.class);

	
	private Exchange exchange;
	
	public TransactionContext() {
		
	}
	public TransactionContext(Object exchange) {
		this.exchange = (Exchange)exchange;
	}

	public Exchange getExchange() {
		return exchange;
	}
	
	public static Object getInstance() {
		TransactionContext tc = null;
		try {
			Context context = Context.getInstance();
			Exchange exchange = (Exchange)context.getProperty("exchange");
			tc = new TransactionContext(exchange);
		} catch (Exception ex) {
			LOG.error("error obtaining transaction context: " + ex);
		}
		return tc;
	}
	
	public static Object getFTPFileName(Object tc) {
		return (String)((TransactionContext)tc).getExchange().getIn().getHeader("CamelFileName");
	}
	
}
