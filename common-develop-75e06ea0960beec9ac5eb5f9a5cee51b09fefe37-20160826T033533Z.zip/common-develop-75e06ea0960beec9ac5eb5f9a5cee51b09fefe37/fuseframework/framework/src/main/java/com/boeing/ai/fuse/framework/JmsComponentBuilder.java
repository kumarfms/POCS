package com.boeing.ai.fuse.framework;

import java.util.Dictionary;

import javax.transaction.TransactionManager;

import org.apache.activemq.pool.ActiveMQResourceManager;
import org.apache.aries.blueprint.ParserContext;
import org.apache.aries.blueprint.mutable.MutableBeanMetadata;
import org.apache.aries.blueprint.mutable.MutablePassThroughMetadata;
import org.apache.aries.blueprint.mutable.MutableValueMetadata;
import org.apache.camel.component.jms.JmsComponent;
import org.apache.camel.component.jms.JmsConfiguration;
import org.apache.geronimo.transaction.manager.RecoverableTransactionManager;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;
import org.osgi.service.blueprint.reflect.ValueMetadata;
import org.springframework.jms.connection.JmsTransactionManager;
import org.springframework.jms.listener.DefaultMessageListenerContainer;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.jta.JtaTransactionManager;
import org.w3c.dom.Element;

public abstract class JmsComponentBuilder implements JmsComponentFactory {

	// attributes
	protected boolean transacted;
	protected boolean jta;
	protected boolean xa;
	protected String id;
	protected boolean ssl;
	
	// transaction managers
	protected MutableBeanMetadata transactionManagerMeta = null;
	protected TransactionManager transactionManager = null;
	protected PlatformTransactionManager platformTransactionManager = null;
	protected RecoverableTransactionManager recoverableTransactionManager = null;
	
	public void build(ParserContext parserContext, BundleContext bundleContext, Element element,  Dictionary<String,Object> properties) {
		
		String concurrentConsumers = element.getAttribute(FwJmsComponent.CONCURRENT_CONSUMERS);
		if (concurrentConsumers == null || concurrentConsumers.endsWith("")) {
			concurrentConsumers = "1";
		}
		
		transacted = Boolean.parseBoolean(element.getAttribute(FwJmsComponent.TRANSACTED));
		jta = Boolean.parseBoolean(element.getAttribute(FwJmsComponent.JTA));
		xa = Boolean.parseBoolean(element.getAttribute(FwJmsComponent.XA));
		ssl = Boolean.parseBoolean(element.getAttribute(FwJmsComponent.SSL));
		id = element.getAttribute(FwNamespaceHandler.ID_ATTRIBUTE);
		
		// connection pool
		MutableBeanMetadata connectionPoolMeta = buildConnectionFactory(parserContext, element, properties, concurrentConsumers);
		
		// TODO - find out where to unget the services
		
		// get the recoverable transaction manager
		ServiceReference rTxManagerReference =  bundleContext.getServiceReference(RecoverableTransactionManager.class.getName());
		if (rTxManagerReference != null) {
			recoverableTransactionManager = (RecoverableTransactionManager)bundleContext.getService(rTxManagerReference);
		}
		
		if (transacted || xa) {

			if (xa || jta) {
				// get the javax transaction manager	
				ServiceReference txManagerReference =  bundleContext.getServiceReference(TransactionManager.class.getName());
				if (txManagerReference != null) {
					transactionManager = (TransactionManager)bundleContext.getService(txManagerReference);
				}
			}
			if (xa) {
				// get the spring platform transaction manager
				ServiceReference pTxManagerReference =  bundleContext.getServiceReference(PlatformTransactionManager.class.getName());
				if (pTxManagerReference != null) {
					platformTransactionManager = (PlatformTransactionManager)bundleContext.getService(pTxManagerReference);
				}

				// do we already have the spring jta transaction manager?
				transactionManagerMeta = (MutableBeanMetadata)parserContext.getComponentDefinitionRegistry().getComponentDefinition("jtaTransactionManager");
				if (transactionManagerMeta == null && transactionManager != null) {
						transactionManagerMeta = parserContext.createMetadata(MutableBeanMetadata.class);
						transactionManagerMeta.setRuntimeClass(JtaTransactionManager.class);
						transactionManagerMeta.setId("jtaTransactionManager");
						transactionManagerMeta.setInitMethod("afterPropertiesSet");
						transactionManagerMeta.addProperty("transactionManager", createValue(parserContext,platformTransactionManager));
						
						// save it for reuse
						parserContext.getComponentDefinitionRegistry().registerComponentDefinition(transactionManagerMeta);
				}
				
			} else {
				if (jta) {
					// do we already have the spring jta transaction manager?
					transactionManagerMeta = (MutableBeanMetadata)parserContext.getComponentDefinitionRegistry().getComponentDefinition("jtaTransactionManager");
					if (transactionManagerMeta == null && transactionManager != null) {
						// use the jta transaction manager
						transactionManagerMeta = parserContext.createMetadata(MutableBeanMetadata.class);
						transactionManagerMeta.setRuntimeClass(JtaTransactionManager.class);
						transactionManagerMeta.setId("jtaTransactionManager");
						transactionManagerMeta.setInitMethod("afterPropertiesSet");
						transactionManagerMeta.addProperty("transactionManager", createValue(parserContext,transactionManager));
						parserContext.getComponentDefinitionRegistry().registerComponentDefinition(transactionManagerMeta);
					}
				} else {
					// use the jms local transaction manager
					transactionManagerMeta = parserContext.createMetadata(MutableBeanMetadata.class);
					transactionManagerMeta.setRuntimeClass(JmsTransactionManager.class);
					transactionManagerMeta.setId(id + "TransactionManager");
					transactionManagerMeta.setInitMethod("afterPropertiesSet");
					transactionManagerMeta.addProperty("connectionFactory", connectionPoolMeta);
					parserContext.getComponentDefinitionRegistry().registerComponentDefinition(transactionManagerMeta);
				}
			}
			
		}
		
		if (xa && recoverableTransactionManager !=  null) {
			// set it on the connection pool also
			connectionPoolMeta.addProperty("transactionManager", createValue(parserContext,recoverableTransactionManager));

		}
		
		// jms configuration
		MutableBeanMetadata jmsConfigurationMeta = parserContext.createMetadata(MutableBeanMetadata.class);
		jmsConfigurationMeta.setRuntimeClass(JmsConfiguration.class);
		jmsConfigurationMeta.addProperty("connectionFactory", connectionPoolMeta);
		// set the cacheLevel
		String cacheLevel = (String)properties.get("cacheLevel");
		if (cacheLevel != null && !cacheLevel.equals("")) {
			jmsConfigurationMeta.addProperty("cacheLevel",createIntValue(parserContext,Integer.parseInt(cacheLevel)));
		} else {
			if (!xa) {
				jmsConfigurationMeta.addProperty("cacheLevel",createIntValue(parserContext,DefaultMessageListenerContainer.CACHE_CONSUMER));
			} else {
				jmsConfigurationMeta.addProperty("cacheLevel",createIntValue(parserContext,DefaultMessageListenerContainer.CACHE_CONNECTION));
			}
		}
		// for jms local transactions approach
		if (transacted) {
			if (xa) {
				jmsConfigurationMeta.addProperty("transacted", createBoolValue(parserContext,false));
			} else {
				jmsConfigurationMeta.addProperty("transacted", createBoolValue(parserContext,true));
			}
			jmsConfigurationMeta.addProperty("transactionManager",transactionManagerMeta);
		}
		jmsConfigurationMeta.addProperty("concurrentConsumers",createValue(parserContext,concurrentConsumers));
		
		// jms component
		MutableBeanMetadata jmsComponentMeta = parserContext.createMetadata(MutableBeanMetadata.class);
		jmsComponentMeta.setRuntimeClass(JmsComponent.class);
		jmsComponentMeta.addProperty("configuration", jmsConfigurationMeta);
		jmsComponentMeta.setId(id);
		
		parserContext.getComponentDefinitionRegistry().registerComponentDefinition(jmsComponentMeta);

	}
	
	protected ValueMetadata createStringValue(ParserContext context, String value) {
        return createValue(context, value, null);
    }
	protected ValueMetadata createIntValue(ParserContext context, int value) {
        return createValue(context, ""+value, "int");
    }
	protected ValueMetadata createBoolValue(ParserContext context, boolean value) {
        return createValue(context, ""+value, "boolean");
    }
	protected ValueMetadata createValue(ParserContext context, String value, String type) {
        MutableValueMetadata m = context.createMetadata(MutableValueMetadata.class);
        m.setStringValue(value);
        m.setType(type);
        return m;
    }
	protected MutablePassThroughMetadata createValue(ParserContext context, Object value) { 
		MutablePassThroughMetadata v = context.createMetadata(MutablePassThroughMetadata.class);
		v.setObject(value);
		return v;
	}

	protected String getValue(Dictionary<String, Object> dictionary, String key, String defaultValue) {
		
		if (dictionary.get(key) != null) {
			return (String)dictionary.get(key);
		} else {
			return defaultValue;
		}
	}
	
	protected boolean gotValue(Dictionary<String, Object> dictionary, String key) {
		if (dictionary.get(key) != null) {
			return true;
		} else {
			return false;
		}
	}
}
