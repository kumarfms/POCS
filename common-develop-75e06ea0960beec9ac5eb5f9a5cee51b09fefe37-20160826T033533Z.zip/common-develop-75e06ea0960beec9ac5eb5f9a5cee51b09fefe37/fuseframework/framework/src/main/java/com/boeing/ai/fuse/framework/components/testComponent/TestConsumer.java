package com.boeing.ai.fuse.framework.components.testComponent;

import java.util.Date;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.impl.ScheduledPollConsumer;
import org.apache.camel.spi.ExceptionHandler;

/**
 * The Test Component consumer.
 */
public class TestConsumer
extends ScheduledPollConsumer
{
   private final TestEndpoint endpoint;
   private int invocationCount = 0;


   public TestConsumer(TestEndpoint endpoint, Processor processor)
   {
      super (endpoint, processor);
      this.endpoint = endpoint;
   }


   @Override
   protected int poll()
   throws Exception
   {
      Exchange exchange = endpoint.createExchange();

      invocationCount += 1;
      log.info ("Poll called. Invocation count: {}", invocationCount);
      // create a message body
      Date now = new Date();
      exchange.getIn().setBody("Hello World! The time is " + now);

      try
      {
         // send message to next processor in the route
         log.info ("Starting route processing.");
         getProcessor().process(exchange);
         System.out.println ("Route processing complete..");
         return 1; // number of messages polled
      }
      catch (Exception e)
      {
         log.info ("Caught exception: ", e);
         return 1;
      }
      finally
      {
         // log exception if an exception occurred and was not handled
         if (exchange.getException() != null)
         {
            if (true)
            {
               System.out.println ("performing exception handling.");
               ExceptionHandler exceptionHandler = getExceptionHandler();
               System.out.println ("using ExceptionHandler: " + exceptionHandler);
               exceptionHandler.handleException("Error processing exchange",
                 exchange, exchange.getException());
               System.out.println ("exception handling complete.");
            }
            else
            {
               System.out.println ("Skipping exception handling.");
            }
       
         }
      }
   }
}
