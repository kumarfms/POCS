package com.boeing.ai.fuse.framework.components.xslt;

import java.util.Map;

import javax.xml.transform.URIResolver;

import org.apache.camel.Endpoint;
import org.apache.camel.builder.xml.XsltUriResolver;
import org.apache.camel.component.xslt.XsltComponent;
import org.apache.camel.util.ResourceHelper;
import org.osgi.framework.BundleContext;
import org.osgi.framework.FrameworkUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class FwXsltComponent extends XsltComponent {

	private static final Logger LOG = LoggerFactory.getLogger(FwXsltComponent.class);

	
    protected Endpoint createEndpoint(String uri, String remaining, Map<String, Object> parameters) throws Exception {
    	
    	FwXsltEndpoint endpoint = new FwXsltEndpoint(uri, this);
    	
    	if (parameters.containsKey("development")) {
    		endpoint.setDevelopment(Boolean.parseBoolean((String)parameters.get("development")));
    	} else {
    		// let's use osgi config lookup
    		BundleContext ctx = FrameworkUtil.getBundle(FwXsltComponent.class).getBundleContext();
    		//TODO
    	}
    	setContentCache(false);    	
    	
    	// component specific stuff
        endpoint.setTransformerFactoryClass("org.apache.xalan.xsltc.trax.TransformerFactoryImpl");
        endpoint.setAllowStAX(false);
        endpoint.setSaxon(false);
        
        // base xslt functionality
    	endpoint.setConverter(getXmlConverter());
        endpoint.setContentCache(isContentCache());

        String resourceUri = remaining;

        // if its a http uri, then append additional parameters as they are part of the uri
        if (ResourceHelper.isHttpUri(resourceUri)) {
            resourceUri = ResourceHelper.appendParameters(resourceUri, parameters);
        }
        LOG.debug("{} using schema resource: {}", this, resourceUri);
        endpoint.setResourceUri(resourceUri);

        // lookup custom resolver to use
        URIResolver resolver = resolveAndRemoveReferenceParameter(parameters, "uriResolver", URIResolver.class);
        if (resolver == null) {
            // not in endpoint then use component specific resolver
            resolver = getUriResolver();
        }       
        // TODO  - this logic is updated in upstreeam master version (new classes)
        if (resolver == null) {
        	// fallback to use a Camel specific resolver 
        	resolver = new XsltUriResolver(getCamelContext().getClassResolver(), remaining); 
        }
        endpoint.setUriResolver(resolver);

        setProperties(endpoint, parameters);
        if (!parameters.isEmpty()) {
            // additional parameters need to be stored on endpoint as they can be used to configure xslt builder additionally
            endpoint.setParameters(parameters);
        }
        return endpoint;
    }


}
