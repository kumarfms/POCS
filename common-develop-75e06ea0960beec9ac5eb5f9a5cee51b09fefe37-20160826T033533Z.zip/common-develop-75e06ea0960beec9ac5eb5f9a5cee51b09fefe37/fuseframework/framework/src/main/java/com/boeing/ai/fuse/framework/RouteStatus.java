package com.boeing.ai.fuse.framework;

import com.boeing.ai.fuse.framework.sched.*;


public class RouteStatus
{
   protected int defaultAlarmThreshold = 6;
   protected int defaultRetryInterval = 1000 * 60 * 5; //5 minutes (300,000 ms).

   /**
    * Number of retries before raising an alarm.
    */
   protected int alarmThreshold = defaultAlarmThreshold;

   protected int retryInterval = defaultRetryInterval;

   protected int retryCount = 0;

   protected ScheduledTask resumeTask = null;


   public void setRetryCount (int retryCount)
   {
      this.retryCount = retryCount;
   }


   public int getAlarmThreshold ()
   {
      return alarmThreshold;
   }


   public int getRetryInterval ()
   {
      return retryInterval;
   }


   public int getRetryCount ()
   {
      return retryCount;
   }


   public ScheduledTask getResumeTask ()
   {
      return resumeTask;
   }


   public void setResumeTask (ScheduledTask resumeTask)
   {
      this.resumeTask = resumeTask;
   }
}
