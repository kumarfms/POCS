package com.boeing.ai.fuse.framework.components.xslt;

import org.apache.camel.ContextTestSupport;
import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;


public class XsltJavaExtensionTestBroken extends ContextTestSupport {

    public void testXsltOutput() throws Exception {
        MockEndpoint mock = getMockEndpoint("mock:result");
        mock.expectedBodiesReceived("<?xml version=\"1.0\" encoding=\"UTF-8\"?><goodbye>TestFile!</goodbye>");
        mock.message(0).body().isInstanceOf(String.class);

        template.sendBodyAndHeader("direct:start", "<hello>world!</hello>","CamelFileName","/hello");
        //template.sendBody("direct:start", "<hello>world!</hello>");
        for (Exchange exchange : mock.getReceivedExchanges()) {
        	System.out.println(exchange.getIn().getBody());
        }
        assertMockEndpointsSatisfied();
    }

    @Override
    protected RouteBuilder createRouteBuilder() throws Exception {

        return new RouteBuilder() {
            @Override
            public void configure() throws Exception {
                from("direct:start")
                    .to("fwxslt:com/boeing/ai/fuse/framework/components/xslt/javaExtension.xsl?development=true")
                    .to("mock:result");
            }
        };
    }
}
