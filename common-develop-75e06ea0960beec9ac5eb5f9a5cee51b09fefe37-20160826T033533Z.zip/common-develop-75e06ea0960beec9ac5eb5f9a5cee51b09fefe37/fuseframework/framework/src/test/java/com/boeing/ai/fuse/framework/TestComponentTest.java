package com.boeing.ai.fuse.framework;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.junit.Test;

import com.boeing.ai.fuse.framework.SimpleRoutePolicy;

public class TestComponentTest extends CamelTestSupport {

    @Test
    public void testTestComponent() throws Exception {
        MockEndpoint mock = getMockEndpoint("mock:result");
        mock.expectedMinimumMessageCount(1);       
        
        assertMockEndpointsSatisfied();
    }

    @Override
    protected RouteBuilder createRouteBuilder()
    throws Exception
    {
        return new TestRouteBuilder ();
    }


   protected class TestRouteBuilder
   extends RouteBuilder
   {
      public void configure()
      {
         SimpleRoutePolicy routePolicy = new SimpleRoutePolicy ();

         from("test-component://foo")
         .routePolicy (routePolicy)
         .to("test-component://bar")
         .to("mock:result");

/*
         from("test-component://foo1")
         .routePolicy (routePolicy)
         .to("test-component://bar")
         .to("mock:result");
*/
      }
   }
}
