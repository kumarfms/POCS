/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 04-21-2016
 * Authors      : Tim Schramer
 * File         : CeersUtils.java - Misc methods used throughout other classes
 *-----------------------------------------------------------------------------
 * Revision History (Release 2.5.5)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *--------------|-------------------|------------------------------------------
 * 2.0.0/2.5.0  | Tim Schramer      | Added with version 2.5.0
 *              | 04-21-2016        |
 *--------------|-------------------|------------------------------------------
 * 2.5.0/2.5.5  | Tim Schramer      | Restructured to natively support Classes
 *              | 04-28-2016        | ported from .NET.
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.components.ceers;
/*---------------------------------------------------------------------------*/
import com.boeing.ai.common.components.ceers.CeersEventManagerImpl;
import com.boeing.ai.common.components.ceers.EventLoggingDefaults;
import com.boeing.ai.common.components.ceers.EventLoggingUtility;
import com.boeing.ai.common.components.ceers.eventmanager.AuditEvent;
import com.boeing.ai.common.components.ceers.eventmanager.BaseEvent;
import com.boeing.ai.common.components.ceers.eventmanager.DataSensitivityType;
import com.boeing.ai.common.components.ceers.eventmanager.EventSeverity;
import com.boeing.ai.common.components.ceers.eventmanager.EventState;
import com.boeing.ai.common.components.ceers.eventmanager.EventTransferType;
import com.boeing.ai.common.components.ceers.eventmanager.EventType;
import com.boeing.ai.common.components.ceers.eventmanager.NotificationEvent;
import com.boeing.ai.common.components.ceers.eventmanager.PayloadType;
import com.boeing.ai.common.components.ceers.eventmanager.StateEvent;

import com.boeing.ai.common.utilities.ArgumentException;
import com.boeing.ai.common.utilities.ClassInfo;
import com.boeing.ai.common.utilities.Convert;
import com.boeing.ai.common.utilities.IO.DirectorySupport;
import com.boeing.ai.common.utilities.StringSupport;

import com.boeing.web.xmlns.ai.ceers.v1.Content;
import com.boeing.web.xmlns.ai.ceers.v1.Event;
import com.boeing.web.xmlns.ai.ceers.v1.EventData;
import com.boeing.web.xmlns.ai.ceers.v1.MessageBody;
import com.boeing.web.xmlns.ai.ceers.v1.ObjectFactory;
import com.boeing.web.xmlns.ai.ceers.v1.Payload;
import com.boeing.web.xmlns.ai.ceers.v1.ResubmitInfo;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;

import java.util.GregorianCalendar;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.camel.CamelContext;
import org.apache.camel.Endpoint;
import org.apache.camel.Exchange;
import org.apache.camel.Message;

import org.apache.commons.codec.binary.Base64;
import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.XMLSerializer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/*---------------------------------------------------------------------------*/
public class CeersUtils {
    private static final transient Logger LOG = LoggerFactory.getLogger(CeersUtils.class);
    private static Properties properties = null;

    // Initialize Common Event Fields
    private static EventLoggingUtility setupCommonFields(BaseEvent theEvent) throws Exception {
        EventLoggingUtility eventLogUtil = null;
        String tmpString = "";

        LOG.debug("Init eventLogUtil object");

        // Load ceers.properties if not done already.
        if (properties == null) {
            properties = new Properties();

            try {
                // check for the existence of ceers.properties
                File file = new File("etc/ceers.properties.cfg");
                if (file.exists()) {
                    InputStream fileStream = new FileInputStream(file);
                    properties.load(fileStream);
                }
            } catch (Exception pe) {
                if (!theEvent.getIgnoreEventErrors())
                    throw pe;
            }
        }

        // Define EventLogging object with alternate logging path, if any
        tmpString = theEvent.getAlternateLogFilePath();
        if (!StringSupport.isBlank(tmpString)) {
            if (!DirectorySupport.verifyDirectory(tmpString)) {
                throw new ArgumentException("Alternate Event Logging directory invalid or could not be created: " + tmpString);
            }
        } else {
            tmpString = "";
        }
        eventLogUtil = new EventLoggingUtility(tmpString);

        //  GlobalTxId - A unique value may be automatically assigned if none was provided earlier.
        tmpString = theEvent.getGlobalTransactionID();
        if (StringSupport.isBlank(tmpString)) {
            tmpString = UUID.randomUUID().toString();
        }
        eventLogUtil.setGlobalTransID(tmpString);

        // EventID
        if (StringSupport.isBlank(theEvent.getEventID())) {
           eventLogUtil.setEventID(UUID.randomUUID().toString());
           theEvent.setEventID(eventLogUtil.getEventID());
        } else {
           eventLogUtil.setEventID(theEvent.getEventID());
        }

        // EventGroupName - Initialize to EventGroup Name of incoming Event.
        tmpString = theEvent.getEventGroupName();
        if (StringSupport.isBlank(tmpString)) {
            tmpString = "NotSpecified";
        }
        eventLogUtil.setEventGroup(tmpString);

        // ApplicationName (research getting name of calling integration)
        tmpString = theEvent.getApplicationName();
        // If still not set, exception.
        if (StringSupport.isBlank(tmpString)) {
            throw new ArgumentException("ApplicationName is missing or null", "ApplicationName");
        }
        eventLogUtil.setApplicationName(tmpString);

        // MessageName - required but use default if missing.
        tmpString = theEvent.getMessageName();
        // If not set, use the default name for MessageName.
        if (StringSupport.isBlank(tmpString)) tmpString = EventLoggingDefaults.MESSAGE_NAME;
        eventLogUtil.setMessageName(tmpString);

        // ServerName
        tmpString = theEvent.getServerName();
        // If not specified, will use default set on EventLogging object.
        if (!StringSupport.isBlank(tmpString)) {
            eventLogUtil.setServerName(tmpString);
        }

        // EnvironmentName - If not set, get from properties file or system env.
        tmpString = theEvent.getEnvironmentName();
        if (StringSupport.isBlank(tmpString) || tmpString.contains("UNK"))    // Clearout if set to unknown earlier
            tmpString = "";
        if (StringSupport.isBlank(tmpString)) {
            tmpString = properties.getProperty("ceers.environmentname", "UNKNOWNDEV"); // CFG Property
        }
//        if (StringSupport.isBlank(tmpString)) {
//            tmpString = System.getenv("JBF_EnvName");                       // From System Environment variable
//        }
        if (StringSupport.isBlank(tmpString)) {
            tmpString = "UNKNOWNDEV";                                         // Still unknown
        }
        eventLogUtil.setEnvironmentName(tmpString);

        // ComponentName (research getting calling route)
        tmpString = theEvent.getComponentName();
        if (StringSupport.isBlank(tmpString) || tmpString.contains("UNK"))    // Clearout if set to unknown earlier
            tmpString = "";
        if (StringSupport.isBlank(tmpString)) {
            tmpString = ClassInfo.getCallerCallerClassName();   // Get from Calling Class
        }
        if (StringSupport.isBlank(tmpString) || tmpString.contains("CeersTransformer")) {
            tmpString = "NotSpecified";
        }
        eventLogUtil.setComponentName(tmpString);

        // TimeStamp
        XMLGregorianCalendar xmlCal = theEvent.getTimeStamp();
        if (xmlCal != null) {
            eventLogUtil.setEventTimestamp(xmlCal);
        } else
        {
            eventLogUtil.setEventTimestamp((GregorianCalendar)GregorianCalendar.getInstance());
        }

        LOG.debug("Setup MetaData");

        // Parse MetaData value if present, otherwise get from Message Context.
        String metaData = theEvent.getMetaData();
        if (StringSupport.isBlank(metaData)) metaData = "";
        if (!StringSupport.isBlank(metaData)) {
            metaData = CeersUtils.cleanupOfficeCharacters(metaData);

            if (metaData.length() > EventLoggingDefaults.MAX_METADATA) {
                metaData = metaData.substring(0, EventLoggingDefaults.MAX_METADATA);
                metaData = metaData.substring(0, metaData.lastIndexOf(","));
            }

            LOG.debug("Calling parseNameValueStringESC for MetaData");
            LOG.debug("MetaData = " + metaData);

            if (!metaData.contains("'=") && !metaData.contains("' =")) {
                throw new ArgumentException("Invalid MetaData Name/Value String. Use format: 'Name1'='Value1','Name2'='Value2'", "MetaData");
            }
            eventLogUtil.setMetaData(eventLogUtil.parseNameValueStringESC(metaData));
        }

        LOG.debug("Setup UserData");

        // UserData Name-Value pairs. - optional. Parse Name-Value pair string into attributes.
        String userData = theEvent.getUserData();
        if (StringSupport.isBlank(userData)) userData = "";
        if (!StringSupport.isBlank(userData)) {
            // Cleanup reserved words and Office characters if any.
            userData = userData.replace("XPATH (","XPATH(");
            userData = userData.replace("BYTERANGE (","BYTERANGE(");
            userData = CeersUtils.cleanupOfficeCharacters(userData);

            if (userData.length() > EventLoggingDefaults.MAX_USERDATA) {
                userData = userData.substring(0, EventLoggingDefaults.MAX_USERDATA);
                userData = userData.substring(0, userData.lastIndexOf(","));
            }

            LOG.debug("Calling parseNameValueStringESC for UserData");
            LOG.debug("UserData = " + userData);

            if (!userData.contains("'=") && !userData.contains("' =")) {
                throw new ArgumentException("Invalid UserData Name/Value String. Use format: 'Name1'='Value1','Name2'='Value2'", "UserData");
            }
            eventLogUtil.setUserData(eventLogUtil.parseNameValueString(userData));
        }

        // DataSensitivity
        DataSensitivityType dataSensitivity = theEvent.getDataSensitivity();
        String sensitivity = "RESTRICT";

        if (dataSensitivity == DataSensitivityType.BOEING_PROPRIETARY) {
            sensitivity = "BOEING PROPRIETARY";
        } else if (dataSensitivity == DataSensitivityType.FAR12) {
            sensitivity = "FAR12";
        } else if (dataSensitivity == DataSensitivityType.EAR) {
            sensitivity = "EAR";
        } else if (dataSensitivity == DataSensitivityType.ITAR) {
            sensitivity = "ITAR";
        } else if (dataSensitivity == DataSensitivityType.NONE) {
            sensitivity = "NONE";
        } else if (dataSensitivity != DataSensitivityType.RESTRICT) {
            LOG.warn("Invalid DataSensitivity specifed. Setting to RESTRICT. - " + sensitivity);
        }
        eventLogUtil.getEventMessage().setDataSensitivity(sensitivity);

        return eventLogUtil;
    }

    public static EventLoggingUtility setupAuditEvent(AuditEvent theEvent) throws Exception {
        LOG.debug("About to setup Audit Event");
        EventLoggingUtility eventLogUtil = null;
        String resubmitParameters = "";
        String resubmitEventId = "";
        String tmpString = "";

        if (theEvent == null) return eventLogUtil;

        try
        {
            String refID = "";
            LOG.debug("Init auditEvent object");

            ObjectFactory objectFactory = new ObjectFactory();
            com.boeing.web.xmlns.ai.ceers.v1.AuditEvent auditEvent = objectFactory.createAuditEvent();

            EventData eventData = objectFactory.createEventData();

            LOG.debug("Init auditpayload object");
            Payload payload = objectFactory.createPayload();

            LOG.debug("Init auditresubmit object");
            ResubmitInfo resubmitInfo = objectFactory.createResubmitInfo();

            eventLogUtil = setupCommonFields(theEvent);

            // For UserData, cycle through the Name snd evaluate XPATH or BYTERANGE expressions. Update the values.
            String userData = theEvent.getUserData();
            if (StringSupport.isBlank(userData)) userData = "";
            if (userData.toUpperCase().contains("XPATH(") || userData.toUpperCase().contains("BYTERANGE(")) {
                if (theEvent.getPayloadMsgBuffer() != null) {
                    LOG.debug("Calling GetPayloadValues for UserData");
                    eventLogUtil.setUserData(eventLogUtil.getPayloadValues(eventLogUtil.getUserData(), theEvent.getPayloadMsgBuffer().toString()));
                }
            }

            // Payload logic
            // When AmountOfPayloadToLog is "NONE", then the API should not include any <message-body> in the event message.
            LOG.debug("Paylog Logic");
            String payloadLogAmount = theEvent.getPayloadLogAmount();
            if (StringSupport.isBlank(payloadLogAmount)) payloadLogAmount = "ALL";
            if (!payloadLogAmount.toUpperCase().equals("NONE")) {
                // Content
                Content content = objectFactory.createContent();
                String refEventId = theEvent.getPayloadRefEventID();

                if (StringSupport.isBlank(refEventId)) refEventId = "";
                if (refEventId.toUpperCase().equals("ORIGINAL")) {
                    // Get Original ID from message context saved earlier.
                    refID = theEvent.getOriginalEventID();

                    // If not set, throw exception.
                    if (StringSupport.isBlank(refID)) {
                        theEvent.setIgnoreEventErrors(false);
                        throw new ArgumentException("No Original EventID found in message context", "PayloadRefEventID=\"ORIGINAL\"");
                    }

                    // Set the content of payload to be the Original Reference id.
                    payload.setRefEventId(refID);

                }
                // If the RefEventID parameter within the Ceers Message contains a user specified
                // Event ID guid value, then the API should place the user specified value in the
                // <ref-event-id> field in the audit event message
                else if (refEventId.length() >= 25) {
                    payload.setRefEventId(refEventId);
                }
                // If the RefEventID parameter within the Ceers Message contains a null string "",
                // then the API should not include <ref-event-id> in the <payload> portion of the
                // event message. This will probably result in <payload><content> being included in
                // the audit event message instead (depending on other parameters).
                else if (StringSupport.isBlank(refEventId)) {
                    Object payloadObject = theEvent.getPayloadMsgBuffer();
                    String messagePayload = null;
                    if(payloadObject != null) messagePayload = payloadObject.toString();

                    if (messagePayload != null) {
                        MessageBody messagebody = objectFactory.createMessageBody();
                        String bodyString = "";

                        if (payloadLogAmount.toUpperCase().startsWith("XPATH")) {
                            LOG.debug("Parsing XPATH");

                            try {
                                bodyString = eventLogUtil.parseBufferXpath(payloadLogAmount, messagePayload);
                            } catch (Exception pe) {
                                if (!theEvent.getIgnoreEventErrors())
                                    throw pe;
                            }
                        } else if (payloadLogAmount.toUpperCase().startsWith("BYTERANGE")) {
                            LOG.debug("Parsing BYTERANGE");

                            try {
                                bodyString = eventLogUtil.parseBufferByteRange(payloadLogAmount, messagePayload);
                            } catch (Exception pe) {
                                if (!theEvent.getIgnoreEventErrors())
                                    throw pe;
                            }
                        } else if (payloadLogAmount.toUpperCase().equals("ALL")) {
                            try {
                                bodyString = eventLogUtil.parseBufferAll(messagePayload);
                            } catch (Exception pe) {
                                if (!theEvent.getIgnoreEventErrors())
                                    throw pe;
                            }
                        } else {
                            throw new ArgumentException("Invalid Payload Amount Argument", payloadLogAmount);
                        }

                        // <text-content>
                        if (theEvent.getPayloadMsgType() == PayloadType.MessageExchange) {
                            messagebody.setTextContent(bodyString);
                        } else // <binary-content>
                            // ParseBuffer routines return Encoded String for ByteArray messages. Convert back.
                            if (theEvent.getPayloadMsgType() == PayloadType.ByteArray) {
                                messagebody.setBinaryContent(Base64.decodeBase64(bodyString));
                            }
                        content.setMessageBody(messagebody);
                    }

                    // PayloadMsgHeader Name-Value pairs. - optional. Parse Name-Value pair string into attributes.
                    String payloadMsgHeader = theEvent.getPayloadMsgHeader();
                    if (!StringSupport.isBlank(payloadMsgHeader)) {
                        if (!payloadMsgHeader.contains("'=") && !payloadMsgHeader.contains("' =")) {
                            throw new ArgumentException("Invalid PayloadMsgHeader Name/Value String. Use format: 'Name1'='Value1','Name2'='Value2'", "PayloadMsgHeader");
                        }

                        content.setMessageHeader(eventLogUtil.parseNameValueString(payloadMsgHeader));
                    }

                    // Set the content of payload to be the content object constructued.
                    payload.setContent(content);
                }
            }

            // Set the payload of the event to the payload object constructued;
            auditEvent.setPayload(payload);

            LOG.debug("Resubmit Logic");

            // Resubmit Logic
            // If the ResubmitEventID parameter within the Ceers Message contains a null string "",
            // then don't include any <resubmit-info> fields in the audit event message.
            resubmitParameters = theEvent.getResubmitParameters();
            if(StringSupport.isBlank(resubmitParameters)) resubmitParameters = "";
            if (StringSupport.isBlank(resubmitParameters)) theEvent.setResubmitEventID("");
            resubmitEventId = theEvent.getResubmitEventID();
            if (StringSupport.isBlank(resubmitEventId)) resubmitEventId = "";

            if (!StringSupport.isBlank(resubmitParameters) && !StringSupport.isBlank(resubmitEventId)) {
                // If the ResubmitEventID parameter within the Ceers Message contains "THIS", then
                // the API should place this event message's Event ID in the <resubmit-event-id> field.
                // If the ResubmitEventID parameter within the Ceers Message contains a user specified guid value
                // then the API should place the user specified value in the <resubmit-event-id> field in the audit event message.
                if (resubmitEventId.toUpperCase().equals("THIS")) {
                    resubmitInfo.setResubmitEventId(eventLogUtil.getEventID());
                } else if (resubmitEventId.length() >= 25) {
                    resubmitInfo.setResubmitEventId(resubmitEventId);
                }

                // ResubmitServiceName
                tmpString = theEvent.getResubmitServiceName();
                if (StringSupport.isBlank(tmpString) || tmpString.contains("UNK"))
                    tmpString = "";                                // Clearout if set to unknown earlier
                if (StringSupport.isBlank(tmpString)) {
                    tmpString = properties.getProperty("ceers.resubmitservice", "UNKNOWNSERVICE");  // CFG value
                }
                if (StringSupport.isBlank(tmpString)) {
                    tmpString = "UNKNOWNSERVICE";                  // Still unknown
                }
                resubmitInfo.setResubmitServiceName(tmpString);

                // ResubmitParameters Name-Value pairs. - optional. Parse Name-Value pair string into attributes.
                if (!StringSupport.isBlank(resubmitParameters)) {
                    if (!resubmitParameters.contains("'=") && !resubmitParameters.contains("' =")) {
                        throw new ArgumentException("Invalid ResubmitParameters Name/Value String. Use format: 'Name1'='Value1','Name2'='Value2'", "ResubmitParameters");
                    }

                    resubmitInfo.setResubmitParameters(eventLogUtil.parseNameValueString(resubmitParameters));
                }

                // Set resubmitinfo object of event to the one constructed.
                auditEvent.setResubmitInfo(resubmitInfo);
            }

            // Set audit class of event to the one constructed.
            eventLogUtil.setEventType(EventType.AUDIT);

            // TransferType set with Property or URI value earlier. Default is LOG.
            auditEvent.setTransferType("LOG");
            EventTransferType transferType = theEvent.getTransferType();
            if (transferType == EventTransferType.Rcv) {
                auditEvent.setTransferType("RCV");
            } else if (transferType == EventTransferType.Send) {
                auditEvent.setTransferType("SEND");
            }
            eventData.setAudit(auditEvent);

            eventLogUtil.getEventMessage().setEventData(eventData);

            LOG.debug("EventLogging Audit Setup Complete");
        } catch (Exception ex) {
            if(eventLogUtil != null) eventLogUtil.logErrorMessage(ex);
            if (!theEvent.getIgnoreEventErrors())
                throw ex;
        }
        return eventLogUtil;
    }

    public static EventLoggingUtility setupStateEvent(StateEvent theEvent) throws Exception {
        LOG.debug("About to send State Event");
        EventLoggingUtility eventLogUtil = null;

        if (theEvent == null) return eventLogUtil;

        try
        {
            LOG.debug("Init stateEvent object");

            ObjectFactory objectFactory = new ObjectFactory();
            com.boeing.web.xmlns.ai.ceers.v1.StateEvent stateEvent = objectFactory.createStateEvent();

            EventData eventData = objectFactory.createEventData();

            eventLogUtil = setupCommonFields(theEvent);

            // AdditionalInfo. Optional string.
            stateEvent.setAdditionalInfo(theEvent.getAdditionalInfo());

            // TransactionState. Default is INFO.
            stateEvent.setTransactionState("INFO");
            EventState eventState = theEvent.getTransactionState();
            if (eventState == EventState.Started) {
                stateEvent.setTransactionState("STARTED");
            } else if (eventState == EventState.Completed) {
                stateEvent.setTransactionState("COMPLETED");
            } else if (eventState == EventState.Wait) {
                stateEvent.setTransactionState("WAIT");
            } else if (eventState == EventState.Failed) {
                stateEvent.setTransactionState("FAILED");
            } else if (eventState == EventState.Debug) {
                stateEvent.setTransactionState("DEBUG");
            }
            // Set state class of event to the one constructed.
            eventLogUtil.setEventType(EventType.STATE);

            eventData.setState(stateEvent);

            eventLogUtil.getEventMessage().setEventData(eventData);

            LOG.debug("EventLogging State Setup Complete");
        } catch (Exception ex) {
            if(eventLogUtil != null) eventLogUtil.logErrorMessage(ex);
            if (!theEvent.getIgnoreEventErrors())
                throw ex;

        }
        return eventLogUtil;
    }

    public static EventLoggingUtility setupNotificationEvent(NotificationEvent theEvent) throws Exception {
        LOG.debug("About to send Notification Event");
        EventLoggingUtility eventLogUtil = null;
        String resubmitParameters = "";
        String resubmitEventId = "";
        String tmpString = "";

        if (theEvent == null) return eventLogUtil;

        try
        {
            String refID = "";
            LOG.debug("Init notificationEvent object");

            ObjectFactory objectFactory = new ObjectFactory();

            com.boeing.web.xmlns.ai.ceers.v1.NotificationEvent notificationEvent = objectFactory.createNotificationEvent();

            EventData eventData = objectFactory.createEventData();

            LOG.debug("Init notificationpayload object");
            Payload payload = objectFactory.createPayload();

            LOG.debug("Init notificationresubmit object");
            ResubmitInfo resubmitInfo = objectFactory.createResubmitInfo();

            eventLogUtil = setupCommonFields(theEvent);

            // For UserData, cycle through the Name snd evaluate XPATH or BYTERANGE expressions. Update the values.
            String userData = theEvent.getUserData();
            if (StringSupport.isBlank(userData)) userData = "";
            if (userData.toUpperCase().contains("XPATH(") || userData.toUpperCase().contains("BYTERANGE(")) {
                if (theEvent.getPayloadMsgBuffer() != null) {
                    LOG.debug("Calling GetPayloadValues for UserData");
                    eventLogUtil.setUserData(eventLogUtil.getPayloadValues(eventLogUtil.getUserData(), theEvent.getPayloadMsgBuffer().toString()));
                }
            }

            // Payload logic
            // When AmountOfPayloadToLog is "NONE", then the API should not include any <message-body> in the event message.
            LOG.debug("Paylog Logic");
            String payloadLogAmount = theEvent.getPayloadLogAmount();
            if (StringSupport.isBlank(payloadLogAmount)) payloadLogAmount = "ALL";
            if (!payloadLogAmount.toUpperCase().equals("NONE")) {
                // Content
                Content content = objectFactory.createContent();
                String refEventId = theEvent.getPayloadRefEventID();

                if (StringSupport.isBlank(refEventId)) refEventId = "";
                if (refEventId.toUpperCase().equals("ORIGINAL")) {
                    // Get Original ID from message context saved earlier.
                    refID = theEvent.getOriginalEventID();

                    // If not set, throw exception.
                    if (StringSupport.isBlank(refID)) {
                        theEvent.setIgnoreEventErrors(false);
                        throw new ArgumentException("No Original EventID found in message context", "PayloadRefEventID=\"ORIGINAL\"");
                    }

                    // Set the content of payload to be the Original Reference id.
                    payload.setRefEventId(refID);

                }
                // If the RefEventID parameter within the Ceers Message contains a user specified
                // Event ID guid value, then the API should place the user specified value in the
                // <ref-event-id> field in the notification event message
                else if (refEventId.length() >= 25) {
                    payload.setRefEventId(refEventId);
                }
                // If the RefEventID parameter within the Ceers Message contains a null string "",
                // then the API should not include <ref-event-id> in the <payload> portion of the
                // event message. This will probably result in <payload><content> being included in
                // the notification event message instead (depending on other parameters).
                else if (StringSupport.isBlank(refEventId)) {
                    Object payloadObject = theEvent.getPayloadMsgBuffer();
                    String messagePayload = null;
                    if(payloadObject != null) messagePayload = payloadObject.toString();

                    if (messagePayload != null) {
                        MessageBody messagebody = objectFactory.createMessageBody();
                        String bodyString = "";

                        if (payloadLogAmount.toUpperCase().startsWith("XPATH")) {
                            LOG.debug("Parsing XPATH");

                            try {
                                bodyString = eventLogUtil.parseBufferXpath(payloadLogAmount, messagePayload);
                            } catch (Exception pe) {
                                if (!theEvent.getIgnoreEventErrors())
                                    throw pe;
                            }
                        } else if (payloadLogAmount.toUpperCase().startsWith("BYTERANGE")) {
                            LOG.debug("Parsing BYTERANGE");

                            try {
                                bodyString = eventLogUtil.parseBufferByteRange(payloadLogAmount, messagePayload);
                            } catch (Exception pe) {
                                if (!theEvent.getIgnoreEventErrors())
                                    throw pe;
                            }
                        } else if (payloadLogAmount.toUpperCase().equals("ALL")) {
                            try {
                                bodyString = eventLogUtil.parseBufferAll(messagePayload);
                            } catch (Exception pe) {
                                if (!theEvent.getIgnoreEventErrors())
                                    throw pe;
                            }
                        } else {
                            throw new ArgumentException("Invalid Payload Amount Argument", payloadLogAmount);
                        }

                        // <text-content>
                        if (theEvent.getPayloadMsgType() == PayloadType.MessageExchange) {
                            messagebody.setTextContent(bodyString);
                        } else // <binary-content>
                            // ParseBuffer routines return Encoded String for ByteArray messages. Convert back.
                            if (theEvent.getPayloadMsgType() == PayloadType.ByteArray) {
                                messagebody.setBinaryContent(Base64.decodeBase64(bodyString));
                            }

                        content.setMessageBody(messagebody);
                    }

                    // PayloadMsgHeader Name-Value pairs. - optional. Parse Name-Value pair string into attributes.
                    String payloadMsgHeader = theEvent.getPayloadMsgHeader();
                    if (!StringSupport.isBlank(payloadMsgHeader)) {
                        if (!payloadMsgHeader.contains("'=") && !payloadMsgHeader.contains("' =")) {
                            throw new ArgumentException("Invalid PayloadMsgHeader Name/Value String. Use format: 'Name1'='Value1','Name2'='Value2'", "PayloadMsgHeader");
                        }

                        content.setMessageHeader(eventLogUtil.parseNameValueString(payloadMsgHeader));
                    }

                    // Set the content of payload to be the content object constructued.
                    payload.setContent(content);
                }
            }

            // Set the payload of the event to the payload object constructued;
            notificationEvent.setPayload(payload);

            LOG.debug("Resubmit Logic");

            // Resubmit Logic
            // If the ResubmitEventID parameter within the Ceers Message contains a null string "",
            // then don't include any <resubmit-info> fields in the notification event message.
            resubmitParameters = theEvent.getResubmitParameters();
            if(StringSupport.isBlank(resubmitParameters)) resubmitParameters = "";
            if (StringSupport.isBlank(resubmitParameters)) theEvent.setResubmitEventID("");
            resubmitEventId = theEvent.getResubmitEventID();
            if (StringSupport.isBlank(resubmitEventId)) resubmitEventId = "";

            if (!StringSupport.isBlank(resubmitParameters) && !StringSupport.isBlank(resubmitEventId)) {
                // If the ResubmitEventID parameter within the Ceers Message contains "THIS", then
                // the API should place this event message's Event ID in the <resubmit-event-id> field.
                // If the ResubmitEventID parameter within the Ceers Message contains a user specified guid value
                // then the API should place the user specified value in the <resubmit-event-id> field in the notification event message.
                if (resubmitEventId.toUpperCase().equals("THIS")) {
                    resubmitInfo.setResubmitEventId(eventLogUtil.getEventID());
                } else if (resubmitEventId.length() >= 25) {
                    resubmitInfo.setResubmitEventId(resubmitEventId);
                }

                // ResubmitServiceName
                tmpString = theEvent.getResubmitServiceName();
                if (StringSupport.isBlank(tmpString) || tmpString.contains("UNK"))
                    tmpString = "";                                // Clearout if set to unknown earlier
                if (StringSupport.isBlank(tmpString)) {
                    tmpString = properties.getProperty("ceers.resubmitservice", "UNKNOWNSERVICE");  // CFG value
                }
                if (StringSupport.isBlank(tmpString)) {
                    tmpString = "UNKNOWNSERVICE";                  // Still unknown
                }
                resubmitInfo.setResubmitServiceName(tmpString);

                // ResubmitParameters Name-Value pairs. - optional. Parse Name-Value pair string into attributes.
                if (!StringSupport.isBlank(resubmitParameters)) {
                    if (!resubmitParameters.contains("'=") && !resubmitParameters.contains("' =")) {
                        throw new ArgumentException("Invalid ResubmitParameters Name/Value String. Use format: 'Name1'='Value1','Name2'='Value2'", "ResubmitParameters");
                    }

                    resubmitInfo.setResubmitParameters(eventLogUtil.parseNameValueString(resubmitParameters));
                }

                // Set resubmitinfo object of event to the one constructed.
                notificationEvent.setResubmitInfo(resubmitInfo);
            }

            // Severity may have been set with URI value earlier. Default is INFO.
            notificationEvent.setSeverity("INFO");
            EventSeverity severity = theEvent.getSeverity();
            if (severity == EventSeverity.Warning) {
                notificationEvent.setSeverity("WARNING");
            } else if (severity == EventSeverity.Error) {
                notificationEvent.setSeverity("ERROR");
            } else if (severity == EventSeverity.Severe) {
                notificationEvent.setSeverity("SEVERE");
            }

            // ShortDescription
            tmpString = theEvent.getShortDescription();
            if (StringSupport.isBlank(tmpString)) {
                notificationEvent.setShortDescription("No Description Provided");
            } else
            {
                notificationEvent.setShortDescription(tmpString);
            }
            // DetailedMessage
            tmpString = theEvent.getDetailedDescription();
            if (!StringSupport.isBlank(tmpString)) {
                notificationEvent.setDetailedMessage(tmpString);
            }

            // Set notification class of event to the one constructed.
            eventLogUtil.setEventType(EventType.NOTIFICATION);

            eventData.setNotification(notificationEvent);

            eventLogUtil.getEventMessage().setEventData(eventData);

            LOG.debug("EventLogging Notification Setup Complete");
        } catch (Exception ex) {
            if(eventLogUtil != null) eventLogUtil.logErrorMessage(ex);
            if (!theEvent.getIgnoreEventErrors())
                throw ex;
        }
        return eventLogUtil;
    }

    // Grab Properties from Exchange and some of its subclasses.  Return as delimited string.
    public static String getExchangeMetadata(String oldMetadata, Exchange exchange) throws Exception {
        String newMetadata = "";
        if (exchange == null)
            return oldMetadata;
        if (StringSupport.isBlank(oldMetadata))
            oldMetadata = "";

        // Exchange data
        newMetadata = CeersUtils.setValueInPairString(oldMetadata, "ExchangeId", exchange.getExchangeId());
        newMetadata = CeersUtils.setValueInPairString(newMetadata, "ExchangeRouteId", exchange.getFromRouteId());
        Map<String, Object> exchangeMetadata = exchange.getProperties();
        for (Map.Entry<String, Object> entry : exchangeMetadata.entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();

            if (!key.startsWith("Exchange"))
                key = "Exchange" + key;
            if (value == null)
                value = "";
            newMetadata = CeersUtils.setValueInPairString(newMetadata, key, value.toString());
        }

        // Context data
        CamelContext context = exchange.getContext();
        newMetadata = CeersUtils.setValueInPairString(newMetadata, "ContextManagementName", context.getManagementName());
        newMetadata = CeersUtils.setValueInPairString(newMetadata, "ContextName", context.getName());
        newMetadata = CeersUtils.setValueInPairString(newMetadata, "ContextVersion", context.getVersion());
        Map<String, String> contextMetadata = context.getProperties();
        for (Map.Entry<String, String> entry : contextMetadata.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();

            if (!key.startsWith("Context"))
                key = "Context" + key;
            if (value == null)
                value = "";
            newMetadata = CeersUtils.setValueInPairString(newMetadata, key, value);
        }

        // Message data
        Message message = exchange.getIn();
        newMetadata = CeersUtils.setValueInPairString(newMetadata, "MessageId", message.getMessageId());
        Map<String, Object> messageMetadata = message.getHeaders();
        for (Map.Entry<String, Object> entry : messageMetadata.entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();

            if (!key.startsWith("Message"))
                key = "Message" + key;
            if (value == null)
                value = "";
            newMetadata = CeersUtils.setValueInPairString(newMetadata, key, value.toString());
        }

        // Endpoint data
        Endpoint endpoint = exchange.getFromEndpoint();
        newMetadata = CeersUtils.setValueInPairString(newMetadata, "EndpointKey", endpoint.getEndpointKey());
        newMetadata = CeersUtils.setValueInPairString(newMetadata, "EndpointUri", endpoint.getEndpointUri());

        return newMetadata;
    }

    // Pluck value from a key-value string given name
    public static String getValueInPairString(String pairString, String name) throws Exception {
        int numPairs = 0;
        String oldString = pairString;
        if (StringSupport.isBlank(name))
            return "";

        name = StringSupport.Trim(name);
        if (StringSupport.isBlank(name))
            return "";

        if (StringSupport.isBlank(pairString) || !pairString.contains("="))
            return "";

        pairString = StringSupport.Trim(pairString);
        if (StringSupport.isBlank(pairString))
            return "";

        try
        {
            pairString = cleanupOfficeCharacters(pairString);
            //            LOG.info("dataString 1 = " + pairString);
            // Cleanup delimiters
            pairString = pairString.replace("' =", "'=");
            pairString = pairString.replace("= '", "='");
            pairString = pairString.replace("' ,", "',");
            pairString = pairString.replace(", '", ",'");
            // Special case. Last value omitted.
            if (pairString.endsWith("'="))
                pairString = pairString + "'";

            numPairs = countStringOccurrences(pairString,"'='");
            if (numPairs == 0)
                return "";

            String[] pairs = new String[numPairs];
            String[] keyvalue = new String[2];
            // Replace delimiters for parsing
            pairString = pairString.replace("'='", "^");
            pairString = pairString.replace("','", "~");
            pairString = StringSupport.TrimStart(pairString, new char[] {'\''});
            pairString = StringSupport.TrimEnd(pairString, new char[] {'\''});
            pairs = StringSupport.Split(pairString, '~');
            for (int loop = 0; loop < numPairs; loop++) {
                keyvalue[0] = "";
                keyvalue[1] = "";
                keyvalue = StringSupport.Split(pairs[loop], '^');
                //                LOG.info("loop/key/value = " + loop.ToString() + "/" + keyvalue[0] + "/" + keyvalue[1]);
                if (StringSupport.equals(keyvalue[0], name))
                    return keyvalue[1];

            }
        } catch (Exception e) {
//            LOG.info("GetValueInPairString: Name/Value string Parse Exception = " + oldString + "\n\n" + e.getMessage() + "\n\n" + e.getStackTrace().toString());
            ArgumentException argE = new ArgumentException("Error parsing Name/Value string, " + oldString + "\n\n" + e.getMessage(), e);
            throw argE;
        }

        return "";
    }

    // Set value from a key-value string given name and value
    public static String setValueInPairString(String pairString, String name, String value) throws Exception {
        String oldString = pairString;
        String newString = pairString;
        if (StringSupport.isBlank(name))
            return newString;

        name = StringSupport.Trim(name);
        if (StringSupport.isBlank(name))
            return newString;

        if (StringSupport.isBlank(pairString))
            pairString = "";

        newString = "";
        try
        {
            int numPairs = 0;
            value = cleanupOfficeCharacters(value);
            // Cleanup delimiters
            pairString = pairString.replace("' =", "'=");
            pairString = pairString.replace("= '", "='");
            pairString = pairString.replace("' ,", "',");
            pairString = pairString.replace(", '", ",'");
            // Special case. Last value omitted.
            if (pairString.endsWith("'="))
                pairString = pairString + "'";

            numPairs = countStringOccurrences(pairString,"'='");
            String[] pairs = new String[numPairs];
            String[] keyvalue = new String[2];
            if (pairString.contains("'" + name + "'=")) {
                // Replace delimeters for parsing
                pairString = pairString.replace("'='", "^");
                pairString = pairString.replace("','", "~");
                pairString = StringSupport.TrimStart(pairString, new char[] {'\''});
                pairString = StringSupport.TrimEnd(pairString, new char[] {'\''});
                pairs = StringSupport.Split(pairString, '~');
                for (int loop = 0; loop < numPairs; loop++) {
                    keyvalue[0] = "";
                    keyvalue[1] = "";
                    keyvalue = StringSupport.Split(pairs[loop], '^');
                    if (StringSupport.equals(keyvalue[0], name))
                        keyvalue[1] = value;

                    newString = newString + keyvalue[0] + "^" + keyvalue[1] + "~";
                }
                newString = StringSupport.TrimEnd(newString, new char[] {'~'});
                newString = newString.replace("^", "'='");
                newString = newString.replace("~", "','");
                newString = "'" + newString + "'";
            } else
            {
                // LOG.debug("New pairString = " + newString);
                newString = pairString;
                newString = StringSupport.TrimEnd(newString, new char[] {','});
                newString = newString + ",'" + name + "'='" + value + "'";
                if (StringSupport.isBlank(pairString))
                    newString = StringSupport.TrimStart(newString, new char[] {','});
            }
        } catch (Exception e) {
//            LOG.debug("SetValueInPairString: Name/Value string Parse Exception = " + oldString + "\n\n" + e.getMessage() + "\n\n" + e.getStackTrace().toString());
            ArgumentException argE = new ArgumentException("Error parsing Name/Value string, " + oldString + "\n\n" + e.getMessage(), e);
            throw argE;
        }
        return newString;
    }

    /**
    * Count occurrences of strings.
    */
    public static int countStringOccurrences(String text, String pattern) throws Exception {
        // Loop through all instances of the string 'text'.
        int count = 0;
        int i = 0;
        while ((i = text.indexOf(pattern, i)) != -1) {
            i += pattern.length();
            count++;
        }
        return count;
    }

    /**
    * Replace Office special characters with normal equivalents.
    */
    public static String cleanupOfficeCharacters(String text) throws Exception {
        if (StringSupport.isBlank(text))
            return "";

        char sq = Convert.ToChar(39);
        char dq = Convert.ToChar(34);
        char ds = Convert.ToChar(45);
        char sq1 = Convert.ToChar(145);
        char sq2 = Convert.ToChar(146);
        char dq1 = Convert.ToChar(147);
        char dq2 = Convert.ToChar(148);
        char ds1 = Convert.ToChar(150);
        char ds2 = Convert.ToChar(151);
        text = text.replace(sq1, sq);
        text = text.replace(sq2, sq);
        text = text.replace(dq1, dq);
        text = text.replace(dq2, dq);
        text = text.replace(ds1, ds);
        text = text.replace(ds2, ds);
        return text;
    }

    public static String marshalCeersObject(Object messageObj, OutputStream outputStream) throws Exception {
        JAXBContext jaxbContext = null;
        String eventXml = "";

        if (messageObj != null && outputStream != null) {

            if (messageObj instanceof CeersEventManagerImpl) {
                LOG.info("Found valid Class to unmarshal: " + messageObj.getClass().getName());
                jaxbContext = JAXBContext.newInstance(CeersEventManagerImpl.class);
            } else {
                if (messageObj instanceof Event) {
                    LOG.info("Found valid Class to unmarshal: " + messageObj.getClass().getName());
                    jaxbContext = JAXBContext.newInstance(Event.class);
                } else {
                    LOG.error("Invalid Class to unmarshal: " + messageObj.getClass().getName());
                }
            }

            Marshaller marshaller = jaxbContext.createMarshaller();
            XMLSerializer eSerializer = getCeersXmlSerializer(outputStream);

            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            marshaller.marshal(messageObj, eSerializer);
            eventXml = outputStream.toString();
        }
        return eventXml;
    }

    private static XMLSerializer getCeersXmlSerializer(OutputStream outputStream) {
        // configure an OutputFormat to handle CDATA
        OutputFormat of = new OutputFormat();

        of.setCDataElements(new String[] {"http://xmlns.web.boeing.com/ai/ceers/V1^text-content", "http://xmlns.web.boeing.com/ai/ceers/V1^detailed-message"});

        // set any other options you'd like
        of.setPreserveSpace(true);
        of.setIndenting(true);

        // create the serializer
        XMLSerializer serializer = new XMLSerializer(of);
        serializer.setOutputByteStream(outputStream);

        return serializer;
    }
}



