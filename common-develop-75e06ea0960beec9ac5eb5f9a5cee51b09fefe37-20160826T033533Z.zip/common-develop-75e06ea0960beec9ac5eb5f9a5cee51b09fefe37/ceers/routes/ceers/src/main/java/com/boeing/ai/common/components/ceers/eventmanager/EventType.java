/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 04-13-2016
 * Authors      : Tim Schramer
 * File         : EventLoggingDefaults.java - EventLoggingUtility EventType enum.
 *                                            Converted from .NET API
 *-----------------------------------------------------------------------------
 * Revision History (Release 2.5.5)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *--------------|-------------------|------------------------------------------
 * 1.0.0/2.0.0  | Tim Schramer      | Added with version 2.0.0
 *              | 04-13-2016        |
 *--------------|-------------------|------------------------------------------
 * 2.0.0/2.5.0  | Tim Schramer      | Robust Unit tests. Added legacy .NET
 *              | Rohan Mars        | method calls. Additional functionality
 *              | 04-21-2016        | Restructured code.
 *--------------|-------------------|------------------------------------------
 * 2.5.0/2.5.5  | Tim Schramer      | Restructured to natively support Classes
 *              | 04-28-2016        | ported from .NET.
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.components.ceers.eventmanager;
/*---------------------------------------------------------------------------*/
public enum EventType {
    AUDIT,
    STATE,
    NOTIFICATION,
    PENDING,
    UNKNOWN
}



