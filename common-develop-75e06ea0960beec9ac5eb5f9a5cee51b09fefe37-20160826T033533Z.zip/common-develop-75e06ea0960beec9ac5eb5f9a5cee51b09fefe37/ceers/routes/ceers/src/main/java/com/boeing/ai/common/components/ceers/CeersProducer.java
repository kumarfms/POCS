/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 12-09-2016
 * Authors      : Alex Kretchetov, David Campbell, Rohan Mars, Tim Schramer
 * File         : CeersProducer .java - The Ceers producer for Component URI calls
 *-----------------------------------------------------------------------------
 * Revision History (Release 2.5.5)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *-----------------------------------------------------------------------------
 * -.-.-/1.0.0  | Alex Kretchetov   | Initial Create.
 *              | David Campbell    |
 *              | Rohan Mars        |
 *              | 12-09-2016        |
 *--------------|-------------------|------------------------------------------
 * 1.0.0/2.0.0  | Tim Schramer      | Major update and additions.
 *              | Rohan Mars        | Added missing CEERS API functionality
 *              | 04-13-2016        |
 *--------------|-------------------|------------------------------------------
 * 2.0.0/2.5.0  | Tim Schramer      | Robust Unit tests. Added legacy .NET
 *              | Rohan Mars        | method calls. Additional functionality
 *              | 04-21-2016        | Restructured code.
 *--------------|-------------------|------------------------------------------
 * 2.5.0/2.5.5  | Tim Schramer      | Restructured to natively support Classes
 *              | 04-28-2016        | ported from .NET.
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.components.ceers;
/*---------------------------------------------------------------------------*/
import com.boeing.ai.common.components.ceers.CeersEventManagerImpl;
import com.boeing.ai.common.components.ceers.eventmanager.BaseEvent;
import com.boeing.ai.common.components.ceers.eventmanager.AuditEvent;
import com.boeing.ai.common.components.ceers.eventmanager.EventSeverity;
import com.boeing.ai.common.components.ceers.eventmanager.EventState;
import com.boeing.ai.common.components.ceers.eventmanager.EventTransferType;
import com.boeing.ai.common.components.ceers.eventmanager.EventType;
import com.boeing.ai.common.components.ceers.eventmanager.NotificationEvent;
import com.boeing.ai.common.components.ceers.eventmanager.StateEvent;

import com.boeing.ai.common.components.ceers.CeersUtils;
import com.boeing.ai.common.utilities.ClassInfo;
import com.boeing.ai.common.utilities.StringSupport;
import com.boeing.ai.fuse.framework.Context;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
// For debgging
// import java.io.FileOutputStream;
// import java.io.OutputStream;

import java.util.Properties;
import java.util.UUID;

import org.apache.camel.Exchange;
import org.apache.camel.impl.DefaultProducer;
import org.apache.camel.Message;
import org.apache.camel.ProducerTemplate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/*---------------------------------------------------------------------------*/
public class CeersProducer extends DefaultProducer {
    private static final transient Logger LOG = LoggerFactory.getLogger(CeersProducer.class);
    private CeersEndpoint endpoint;
    private ProducerTemplate template;
    Properties properties = new Properties();
    private Boolean ignoreErrors = true;

    private String producerUrl = "direct-vm:ceers";

    @Override
    public CeersEndpoint getEndpoint() {
        return (CeersEndpoint) super.getEndpoint();
    }

    public CeersProducer(CeersEndpoint endpoint) {
        super(endpoint);
        this.endpoint = endpoint;

        try {
            // check for the existence of ceers.properties
            File file = new File("etc/ceers.properties.cfg");
            if (file.exists()) {
                InputStream fileStream = new FileInputStream(file);
                properties.load(fileStream);
                producerUrl = properties.getProperty("componentProducerUrl","direct-vm:ceers");
            }
        } catch (Exception ex) {
            LOG.error("Exception while reading \"ceers.properties.cfg\" file: " + ex.getMessage());
            if(ignoreErrors) {
                LOG.warn("CEERS IgnoreErrors set to true. Processing not aborted.");
            }
        }
    }

    public void process(Exchange exchange)
    throws Exception {
        Message message = exchange.getIn();

        LOG.debug("Endpoint = " + endpoint.toString());
        LOG.debug("message: " + message.toString());

        try {
            CeersEventManagerImpl em = convertToInternal(endpoint, exchange, message);
            template = exchange.getContext().createProducerTemplate();

            // synchronous call on a blocked queue
            template.setDefaultEndpointUri(producerUrl);

//            LOG.warn("\nAbout to send ceersmessage = " + em.toString() );

// For debugging
// String outString = "C:\\temp\\CeersEvents\\EM\\EventManager_" + em.getEventType().toString() + em.toString() + ".xml";
// outString = outString.replace("com.boeing.ai.common.components.ceers.CeersEventManagerImpl", "");
// OutputStream outputStream = new FileOutputStream(outString);
// CeersUtils.marshalCeersObject(em, outputStream);

            template.sendBody(em);
            template.stop();
        } catch (Exception e) {
            LOG.error("Exception while Producing CEERS Event data: " + e.getMessage());
            if(ignoreErrors) {
                LOG.warn("CEERS IgnoreErrors set to true. Processing not aborted.");
            } else {
                throw e;
            }
        }

//        LOG.debug(exchange.getIn().getBody().toString());
    }

    private CeersEventManagerImpl convertToInternal(CeersEndpoint endpoint, Exchange exchange, Message message)
    throws Exception {
        Context context = Context.getInstance();
        CeersEventManagerImpl em = new CeersEventManagerImpl();
        BaseEvent be;
        String eventType = "";
        String tmpString;

        // EventType. Get from URI parameter or Exchange Property. Default is AUDIT if missing.
        eventType = endpoint.getEventType();
        if (StringSupport.isBlank(eventType)) {
            eventType = exchange.getProperty("CeersEventType", String.class);
        }
        if (StringSupport.isBlank(eventType)) {
            eventType = "AUDIT";
        }
        eventType = eventType.toUpperCase();
        if (eventType.equals("STATE")) {
            em.setEventType(EventType.STATE);
            be = new StateEvent("NA");
        } else if (eventType.equals("NOTIFICATION")) {
            em.setEventType(EventType.NOTIFICATION);
            be = new NotificationEvent("NA");
        } else {
            em.setEventType(EventType.AUDIT);
            be = new AuditEvent("NA");
        }

// Common fields for all 3 Event types are on BaseEvent.
// Check for Exchange Properties for common values first
        be.setGlobalTransactionID(exchange.getProperty("CeersGlobalTxId", String.class));
        be.setEventGroupName(exchange.getProperty("CeersEventGroup", String.class));
        be.setApplicationName(exchange.getProperty("CeersApplicationName", String.class));
        be.setMessageName(exchange.getProperty("CeersMessageName", String.class));
        be.setServerName(exchange.getProperty("CeersServerName", String.class));
        be.setEnvironmentName(exchange.getProperty("CeersEnvironmentName", String.class));
        be.setComponentName(exchange.getProperty("CeersComponentName", String.class));
        tmpString = exchange.getProperty("CeersEventTimestamp", String.class);
        if (!StringSupport.isBlank(tmpString))
            be.setTimeStamp(tmpString);
        be.setMetaData(exchange.getProperty("CeersMetadata", String.class));
        be.setUserData(exchange.getProperty("CeersUserdata", String.class));
        be.setDataSensitivity(exchange.getProperty("CeersDataSensitivity", String.class));

        // Set missing common values if still not set
        // Note: EventID and Metadata are not URI parameters and set later if still missing.
        /** Example for maximum parameter Audit URI
            ceers://?eventType=audit
            &globalTxId=75bc9f2c-ece4-4d32-8958-55d17ad125e2
            &eventGroup=TEST_GROUP
            &applicationName=CEERS_TESTER
            &messageName=MAX_PARAMETERS
            &serverName=TESTSERVER
            &environmentName=UNITTEST
            &componentName=TESTCOMPONENT
            &eventTimestamp=2016-04-16T23:51:53.752-07:00
            &userdata=%27FirstName%27=%27Tim%27,%27LastName%27=%27Schramer%27,%27PluckValue%27=%27XPATH(//MyChild2/Value/text())%27
            &dataSensitivity=FAR12
            &transferType=RCV
            &referenceOriginalPayload=false
            &payloadLogAmount=BYTERANGE(0,20)
            &payloadMsgHeader=%27Header1%27=%27Value1%27,%27Header2%27=%27Value2%27
            &resubmitServiceName=FUSERESUBMITSERVICE
            &resubmitParameters=%27Transport%27=%27MQSC%27,%27QueueMgr%27=%27MQHUBT1QM%27,%27Queue%27=%27AI.DEV.Q01%27
            &allowResubmit=true
            &disableLogging=false
            &ignoreEventErrors=false
            &alternateLogFilePath=C:%5Ctemp%5CCeersEvents  // Option added to send Event to file instead of CEERS (Windows folder)
        */

        // Generate EventId and set it on the Exchange Property.
        be.setEventID(UUID.randomUUID().toString());
        exchange.setProperty("CeersEventId", be.getEventID());
        context.setProperty ("CeersEventId", be.getEventID());

        // Must have a Global Transaction ID.
        // Use URI Value, Exchange Property set above, Context value (legacy support), or new value.
        tmpString = endpoint.getGlobalTxId();
        if (!StringSupport.isBlank(tmpString)) {
            be.setGlobalTransactionID(tmpString);                            // Use URI value
        } else
        {
            tmpString = be.getGlobalTransactionID();                         // Check Exchange
            if (StringSupport.isBlank(tmpString)) {
                tmpString = (String)context.getProperty("ceers.globalTxId"); // Check Legacy
            }
            if (StringSupport.isBlank(tmpString)) {
                tmpString = UUID.randomUUID().toString();                    // New value
            }
            be.setGlobalTransactionID(tmpString);
        }
        context.setProperty("ceers.globalTxId", tmpString);                  // Legacy support

        // EventGroup
        tmpString = endpoint.getEventGroup();
        if (!StringSupport.isBlank(tmpString)) {
            be.setEventGroupName(tmpString);
        } else
        {
            tmpString = be.getEventGroupName();
            if (StringSupport.isBlank(tmpString)) {
                be.setEventGroupName("NotSpecified");
            }
        }

        // ApplicationName
        tmpString = endpoint.getApplicationName();
        if (!StringSupport.isBlank(tmpString)) {
            be.setApplicationName(tmpString);
        }

        // MessageName
        tmpString = endpoint.getMessageName();
        if (!StringSupport.isBlank(tmpString)) {
            be.setMessageName(tmpString);
        }

        // ServerName
        tmpString = endpoint.getServerName();
        if (!StringSupport.isBlank(tmpString)) {
            be.setServerName(tmpString);
        }

        // EnvironmentName - get from URI parameter, exchange property, properties file or system env.
        tmpString = endpoint.getEnvironmentName();              // On URI
        if (StringSupport.isBlank(tmpString)) {
            tmpString = be.getEnvironmentName();                // Saved earler from Exchange Property
        }
        if (StringSupport.isBlank(tmpString)) {
            tmpString = properties.getProperty("ceers.environmentname", "UNKNOWNDEV"); // CFG Property
        }
        if (StringSupport.isBlank(tmpString)) {
            tmpString = (String)context.getProperty("ceers.environmentname"); // Check ThreadLocalContext
        }
//        if (StringSupport.isBlank(tmpString)) {
//            tmpString = System.getenv("JBF_EnvName");           // From System Environment variable
//        }
        if (StringSupport.isBlank(tmpString)) {
            tmpString = "UNKNOWNDEV";                           // Unknown
        }
        be.setEnvironmentName(tmpString);

        // ComponentName
        tmpString = endpoint.getComponentName();                // Get from URI
        if (StringSupport.isBlank(tmpString)) {
            tmpString = be.getComponentName();                  // Get from Exchange Property
        }
        if (StringSupport.isBlank(tmpString)) {
            tmpString = exchange.getFromRouteId();              // Get from Exchange Route
        }
        if (StringSupport.isBlank(tmpString)) {
            tmpString = ClassInfo.getCallerCallerClassName();   // Get from Calling Class
        }
        if (StringSupport.isBlank(tmpString)) {
            tmpString = "UNKNOWNCOMPONENT";                     // Unknown
        }
        be.setComponentName(tmpString);

        // TimeStamp
        tmpString = endpoint.getEventTimestamp();
        if (!StringSupport.isBlank(tmpString)) {
            be.setTimeStamp(tmpString);
        }

        // Metadata - get from Exchange and Message only if not specified as an Exchange Property.
        tmpString = be.getMetaData();
        if (StringSupport.isBlank(tmpString)) {
            String metaData = CeersUtils.getExchangeMetadata("", exchange);
            be.setMetaData(metaData);
        }

        // UserData
        tmpString = endpoint.getUserdata();
        if (!StringSupport.isBlank(tmpString)) {
            be.setUserData(tmpString);
        }

        // DataSensitivity
        tmpString = endpoint.getDataSensitivity();
        if (!StringSupport.isBlank(tmpString)) {
            be.setDataSensitivity(tmpString);

        } else
        {
            tmpString = be.getDataSensitivity().toString();
            if (StringSupport.isBlank(tmpString)) {
                be.setDataSensitivity("RESTRICT");
            }
        }

        // IgnoreEventErrors - allows business messages to continue despite errors in CEERS processing.
        tmpString = endpoint.getIgnoreEventErrors();
        if (StringSupport.isBlank(tmpString)) {
            tmpString = "true";
        } else
        {
            tmpString = tmpString.trim().toLowerCase();
            if(tmpString.startsWith("f") || tmpString.startsWith("n")) {
                tmpString = "false";
            } else
            {
                tmpString = "true";
            }
        }

// WHILE DEBUGGING - don't ignore
// tmpString = "false";

        if (tmpString == "true") {
            be.setIgnoreEventErrors(true);
        } else {
            be.setIgnoreEventErrors(false);
        }
        ignoreErrors = be.getIgnoreEventErrors();

        // DisableAuditLogging
        tmpString = endpoint.getDisableLogging();
        if (StringSupport.isBlank(tmpString)) {
            tmpString = "false";
        } else
        {
            tmpString = tmpString.trim().toLowerCase();
            if(tmpString.startsWith("t") || tmpString.startsWith("y")) {
                tmpString = "true";
            } else
            {
                tmpString = "false";
            }
        }
        be.setDisableLogging(false);
        if (tmpString == "true")
            be.setDisableLogging(true);

        // Parameter to output to folder instead of CEERS.
        be.setAlternateLogFilePath(endpoint.getAlternateLogFilePath());

        // Setup specific values for each Event Type.
        switch (eventType) {
        case "AUDIT":
            AuditEvent ae = new AuditEvent("NA");
            if (be instanceof AuditEvent) {
                ae = (AuditEvent)be;
            }

            // Payload Parameters.
            // RefEventId from URI  ("ORIGINAL" or actual ID)
            ae.setPayloadRefEventID(endpoint.getRefEventId());

            // ReferenceOrginalPayload flag
            // Boolean, optional, default = "false", allowable values are "true" or "false".
            // "true" means to set the <ref-event-id> to the value of CeersOriginalEventID in the
            // message context (if exists), and don"t include any payload content in the event message.
            // "false" means that payload content should be included in this event message.
            tmpString = endpoint.getReferenceOriginalPayload();
            if (StringSupport.isBlank(tmpString)) {
                tmpString = "false";
            } else {
                tmpString = tmpString.trim().toLowerCase();
                if(tmpString.startsWith("t") || tmpString.startsWith("y")) {
                    tmpString = "true";
                } else {
                    tmpString = "false";
                }
            }
            // If above true, try and save value from URI or Exchange Property.
            if (tmpString == "true") {
// LOG.warn("OEVENT: Reference Original Payload is true");
                tmpString = endpoint.getOriginalEventId();
                if (StringSupport.isBlank(tmpString)) {
// LOG.warn("OEVENT: value not in URI");
                    tmpString = exchange.getProperty("CeersOriginalEventId", String.class);
                }
                if (StringSupport.isBlank(tmpString)) {
// LOG.warn("OEVENT: value not on Exchange");
                    tmpString = (String)context.getProperty("CeersOriginalEventId"); // Check context
                }
                if (StringSupport.isBlank(tmpString)) {
// LOG.warn("OEVENT: value not in context");
                    tmpString = properties.getProperty("CeersOriginalEventId", "");  // Unit test
                }
                if (!StringSupport.isBlank(tmpString))
                    ae.setOriginalEventID(tmpString);

// LOG.warn("OEVENT: value: " + ae.getOriginalEventID());
            }

            // PayloadLogAmount
            ae.setPayloadLogAmount(endpoint.getPayloadLogAmount());


            // PayloadMsgBuffer
            ae.setPayloadMsgBuffer(message.getBody(String.class));

            // PayloadMsgHeader
            ae.setPayloadMsgHeader(endpoint.getPayloadMsgHeader());

            // Resubmit Info.
            // Allow resubmit
            String allowResubmit = endpoint.getAllowResubmit();
            if (StringSupport.isBlank(allowResubmit)) {
                allowResubmit= "true";
            } else {
                allowResubmit = allowResubmit.trim().toLowerCase();
                if(allowResubmit.startsWith("f") || allowResubmit.startsWith("n")) {
                    allowResubmit= "false";
                } else {
                    allowResubmit= "true";
                }
            }
            // Try and set Resubmit values if AllowResubmit was missing or true.
            if (allowResubmit == "true") {

                // ResubmitEventID
                tmpString = endpoint.getResubmitEventId();
                if (!StringSupport.isBlank(tmpString)) {
                    ae.setResubmitEventID(tmpString);
                } else {
                    tmpString = exchange.getProperty("CeersResubmitEventId", String.class);
                    if (!StringSupport.isBlank(tmpString)) {
                        ae.setResubmitEventID(tmpString);
                    } else {
                        ae.setResubmitEventID("THIS");
                    }
                }

                // ResubmitServiceName - get from URI parameter or properties file.
                tmpString = endpoint.getResubmitServiceName();     // From URI
                if (StringSupport.isBlank(tmpString)) {
                    tmpString = properties.getProperty("ceers.resubmitservice", "UNKNOWNSERVICE");
                }
                if (StringSupport.isBlank(tmpString)) {
                    tmpString = "UNKNOWNSERVICE";                  // Still unknown
                }
                ae.setResubmitServiceName(tmpString);

                // ResubmitParameters
                ae.setResubmitParameters(endpoint.getResubmitParameters());
            }

            // TransferType. Get from URI parameter or Exchange Property. Default is LOG if missing.
            tmpString = endpoint.getTransferType();
            if (StringSupport.isBlank(tmpString)) {
                tmpString = exchange.getProperty("CeersTransferType", String.class);
            }
            if (StringSupport.isBlank(tmpString)) {
                tmpString = "LOG";
            }
            tmpString = tmpString.toUpperCase();
            ae.setTransferType(EventTransferType.Log);
            if (tmpString.equals("RCV")) {
                ae.setTransferType(EventTransferType.Rcv);
            } else if (tmpString.equals("SEND")) {
                ae.setTransferType(EventTransferType.Send);
            }

            em.setAuditEvent(ae);
            break;
        case "STATE":
            StateEvent se = new StateEvent("NA");
            if (be instanceof StateEvent) {
                se = (StateEvent)be;
            }

            // TransactionState. Default is INFO.
            se.setTransactionState(EventState.Info);
            tmpString = endpoint.getTransactionState();
            if (StringSupport.isBlank(tmpString))
                tmpString = "";
            else
                tmpString = tmpString.toUpperCase();
            if (tmpString.equals("STARTED")) {
                se.setTransactionState(EventState.Started);
            } else if (tmpString.equals("COMPLETED")) {
                se.setTransactionState(EventState.Completed);
            } else if (tmpString.equals("WAIT")) {
                se.setTransactionState(EventState.Wait);
            } else if (tmpString.equals("FAILED")) {
                se.setTransactionState(EventState.Failed);
            } else if (tmpString.equals("DEBUG")) {
                se.setTransactionState(EventState.Debug);
            }

            // AdditionalInfo
            tmpString = endpoint.getAdditionalInfo();
            if (StringSupport.isBlank(tmpString)) {
                se.setAdditionalInfo("No Additional Info Provided");
            } else {
                se.setAdditionalInfo(tmpString);
            }

            em.setStateEvent(se);
            break;
        case "NOTIFICATION":
            NotificationEvent ne = new NotificationEvent("NA");
            if (be instanceof NotificationEvent) {
                ne = (NotificationEvent)be;
            }

            // Payload Parameters.
            // RefEventId from URI  ("ORIGINAL" or actual ID)
            ne.setPayloadRefEventID(endpoint.getRefEventId());

            // ReferenceOrginalPayload flag
            // Boolean, optional, default = "false", allowable values are "true" or "false".
            // "true" means to set the <ref-event-id> to the value of CeersOriginalEventID in the
            // message context (if exists), and don"t include any payload content in the event message.
            // "false" means that payload content should be included in this event message.
            tmpString = endpoint.getReferenceOriginalPayload();
            if (StringSupport.isBlank(tmpString)) {
                tmpString = "false";
            } else {
                tmpString = tmpString.trim().toLowerCase();
                if(tmpString.startsWith("t") || tmpString.startsWith("y")) {
                    tmpString = "true";
                } else {
                    tmpString = "false";
                }
            }
            // If above true, try and save value from URI or Exchange Property.
            if (tmpString == "true") {
// LOG.warn("OEVENT: Reference Original Payload is true");
                tmpString = endpoint.getOriginalEventId();
                if (StringSupport.isBlank(tmpString)) {
// LOG.warn("OEVENT: value not in URI");
                    tmpString = exchange.getProperty("CeersOriginalEventId", String.class);
                }
                if (StringSupport.isBlank(tmpString)) {
// LOG.warn("OEVENT: value not on Exchange");
                    tmpString = (String)context.getProperty("CeersOriginalEventId"); // Check context
                }
                if (StringSupport.isBlank(tmpString)) {
// LOG.warn("OEVENT: value not in context");
                    tmpString = properties.getProperty("CeersOriginalEventId", "");  // Unit test
                }
                if (!StringSupport.isBlank(tmpString))
                    ne.setOriginalEventID(tmpString);

// LOG.warn("OEVENT: value: " + ne.getOriginalEventID());
            }

            // PayloadLogAmount
            ne.setPayloadLogAmount(endpoint.getPayloadLogAmount());

            // PayloadMsgBuffer
            ne.setPayloadMsgBuffer(message.getBody(String.class));

            // PayloadMsgHeader
            ne.setPayloadMsgHeader(endpoint.getPayloadMsgHeader());

            // Resubmit Info.
            // Allow resubmit
            allowResubmit = endpoint.getAllowResubmit();
            if (StringSupport.isBlank(allowResubmit)) {
                allowResubmit= "true";
            } else {
                allowResubmit = allowResubmit.trim().toLowerCase();
                if(allowResubmit.startsWith("f") || allowResubmit.startsWith("n")) {
                    allowResubmit= "false";
                } else {
                    allowResubmit= "true";
                }
            }
            // Try and set Resubmit values if AllowResubmit was missing or true.
            if (allowResubmit == "true") {

                // ResubmitEventID
                tmpString = endpoint.getResubmitEventId();
                if (!StringSupport.isBlank(tmpString)) {
                    ne.setResubmitEventID(tmpString);
                } else {
                    tmpString = exchange.getProperty("CeersResubmitEventId", String.class);
                    if (!StringSupport.isBlank(tmpString)) {
                        ne.setResubmitEventID(tmpString);
                    } else {
                        ne.setResubmitEventID("THIS");
                    }
                }

                // ResubmitServiceName - get from URI parameter or properties file.
                tmpString = endpoint.getResubmitServiceName();     // From URI
                if (StringSupport.isBlank(tmpString)) {
                    tmpString = properties.getProperty("ceers.resubmitservice", "UNKNOWNSERVICE");
                }
                if (StringSupport.isBlank(tmpString)) {
                    tmpString = "UNKNOWNSERVICE";                  // Still unknown
                }
                ne.setResubmitServiceName(tmpString);

                // ResubmitParameters
                ne.setResubmitParameters(endpoint.getResubmitParameters());
            }

            // Severity. Default is INFO.
            ne.setSeverity(EventSeverity.Info);
            tmpString = endpoint.getSeverity();
            if (StringSupport.isBlank(tmpString))
                tmpString = "";
            else
                tmpString = tmpString.toUpperCase();
            if (tmpString.equals("WARNING")) {
                ne.setSeverity(EventSeverity.Warning);
            } else if (tmpString.equals("ERROR")) {
                ne.setSeverity(EventSeverity.Error);
            } else if (tmpString.equals("SEVERE")) {
                ne.setSeverity(EventSeverity.Severe);
            }

            // ShortDescription
            tmpString = endpoint.getShortDescription();
            if (StringSupport.isBlank(tmpString)) {
                ne.setShortDescription("No Description Provided");
            } else {
                ne.setShortDescription(tmpString);
            }
            // DetailedMessage
            tmpString = endpoint.getDetailedMessage();
            if (!StringSupport.isBlank(tmpString)) {
                ne.setDetailedDescription(tmpString);
            }

            em.setNotificationEvent(ne);
            break;
        default:
            throw new Exception("Unable to recognize Event Type during CEERS URI processing");
        }

        LOG.debug("ConvertedToInternal" + em.toString());
        return em;
    }
}


