/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 04-21-2016
 * Authors      : Tim Schramer
 * File         : NotificationEvent.java - NotificationEvent Class exposed in CEERS API
 *                                         Converted from .NET API
 *-----------------------------------------------------------------------------
 * Revision History (Release 2.5.5)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *--------------|-------------------|------------------------------------------
 * 2.0.0/2.5.0  | Tim Schramer      | Added with version 2.5.0
 *              | 04-21-2016        |
 *--------------|-------------------|------------------------------------------
 * 2.5.0/2.5.5  | Tim Schramer      | Restructured to natively support Classes
 *              | 04-28-2016        | ported from .NET.
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.components.ceers.eventmanager;
/*---------------------------------------------------------------------------*/
import com.boeing.ai.common.components.ceers.CeersUtils;
import com.boeing.ai.common.components.ceers.eventmanager.BaseEvent;
import com.boeing.ai.common.components.ceers.eventmanager.EventSeverity;
import com.boeing.ai.common.components.ceers.eventmanager.PayloadType;

import javax.xml.bind.annotation.XmlElement;

import org.apache.camel.Exchange;
import org.apache.camel.Message;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/*---------------------------------------------------------------------------*/
public class NotificationEvent extends BaseEvent {
    private static final Logger LOG = LoggerFactory.getLogger(Thread.currentThread().getStackTrace()[0].getClassName());

    private EventSeverity _severity = EventSeverity.Severe;
    private String _shortDescription;
    private String _detailedDescription;
    private String _resubmitEventID;
    private String _resubmitServiceName;
    private String _resubmitParameters;
    private String _payloadRefEventID;
    private Object _payloadMsgBuffer;
    private PayloadType _payloadMsgType;
    private String _payloadLogAmount;
    private String _payloadMsgHeader;
    private String _originalEventID;

    // Initializer - invoke base initializer with the name.
    public NotificationEvent() throws Exception {
        super("NA");
        this.setSeverity(EventSeverity.Info);
        this.setShortDescription("");
        this.setDetailedDescription("");
        this.setResubmitEventID("");
        this.setResubmitServiceName("");
        this.setResubmitParameters("");
        this.setPayloadRefEventID("");
        this.setPayloadMsgBuffer(null);  // Also sets payloadMsgType
        this.setPayloadLogAmount("ALL");
        this.setPayloadMsgHeader("");
        this.setOriginalEventID("");
    }

    public NotificationEvent(String messageName) throws Exception {
        super(messageName);
        this.setSeverity(EventSeverity.Info);
        this.setShortDescription("");
        this.setDetailedDescription("");
        this.setResubmitEventID("");
        this.setResubmitServiceName("");
        this.setResubmitParameters("");
        this.setPayloadRefEventID("");
        this.setPayloadMsgBuffer(null);  // Also sets payloadMsgType
        this.setPayloadLogAmount("ALL");
        this.setPayloadMsgHeader("");
        this.setOriginalEventID("");
    }

    public EventSeverity getSeverity() throws Exception {
        return this._severity;
    }
    @XmlElement
    public void setSeverity(EventSeverity value) throws Exception {
        this._severity = value;
    }

    public String getShortDescription() throws Exception {
        return this._shortDescription;
    }
    @XmlElement
    public void setShortDescription(String value) throws Exception {
        this._shortDescription = value;
    }

    public String getDetailedDescription() throws Exception {
        return this._detailedDescription;
    }
    @XmlElement
    public void setDetailedDescription(String value) throws Exception {
        this._detailedDescription = value;
    }

    public String getResubmitEventID() throws Exception {
        return this._resubmitEventID;
    }
    @XmlElement
    public void setResubmitEventID(String value) throws Exception {
        this._resubmitEventID = value;
    }

    public String getResubmitServiceName() throws Exception {
        return this._resubmitServiceName;
    }
    @XmlElement
    public void setResubmitServiceName(String value) throws Exception {
        this._resubmitServiceName = value;
    }

    public String getResubmitParameters() throws Exception {
        return this._resubmitParameters;
    }
    @XmlElement
    public void setResubmitParameters(String value) throws Exception {
        this._resubmitParameters = value;
    }

    public String getResubmitParametersFieldValue(String name) throws Exception {
        return CeersUtils.getValueInPairString(this._resubmitParameters,name);
    }
    public void setResubmitParametersField(String name, String value) throws Exception {
        this._resubmitParameters = CeersUtils.setValueInPairString(this._resubmitParameters,name,value);
    }

    public Object getPayloadMsgBuffer() throws Exception {
        return this._payloadMsgBuffer;
    }
    public String getPayloadMsgBufferString() throws Exception {
        if(this._payloadMsgBuffer == null)
            return "";
        return this._payloadMsgBuffer.toString();
    }
    @XmlElement
    public void setPayloadMsgBuffer(Object messageObj) throws Exception {
        if (messageObj instanceof Exchange) {
            Exchange exchange = (Exchange)messageObj;
            messageObj = exchange.getIn();
        }
        if (messageObj instanceof Message) {
            Message message = (Message)messageObj;
            messageObj = message.getBody(String.class);
        }
        if (!(messageObj instanceof String)) {
            messageObj = null;
        }
        this._payloadMsgBuffer = messageObj;
        if (messageObj == null)
            this.setPayloadMsgType(PayloadType.None);
        else
            this.setPayloadMsgType(PayloadType.MessageExchange);
    }
    public void setPayloadMsgBuffer(byte[] message) throws Exception {
        this._payloadMsgBuffer = message;
        if (message == null)
            this.setPayloadMsgType(PayloadType.None);
        else
            this.setPayloadMsgType(PayloadType.ByteArray);
    }

    public String getPayloadRefEventID() throws Exception {
        return this._payloadRefEventID;
    }
    @XmlElement
    public void setPayloadRefEventID(String value) throws Exception {
        this._payloadRefEventID = value;
    }

    public PayloadType getPayloadMsgType() throws Exception {
        return this._payloadMsgType;
    }
    @XmlElement
    public void setPayloadMsgType(PayloadType value) throws Exception {
        this._payloadMsgType = value;
    }

    public String getPayloadLogAmount() throws Exception {
        return this._payloadLogAmount;
    }
    @XmlElement
    public void setPayloadLogAmount(String value) throws Exception {
        this._payloadLogAmount = value;
    }

    public String getPayloadMsgHeader() throws Exception {
        return this._payloadMsgHeader;
    }
    @XmlElement
    public void setPayloadMsgHeader(String value) throws Exception {
        this._payloadMsgHeader = value;
    }

    public String getPayloadMsgHeaderFieldValue(String name) throws Exception {
        return CeersUtils.getValueInPairString(this._payloadMsgHeader,name);
    }
    public void setPayloadMsgHeaderField(String name, String value) throws Exception {
        this._payloadMsgHeader = CeersUtils.setValueInPairString(this._payloadMsgHeader,name,value);
    }

    public String getOriginalEventID() throws Exception {
        return this._originalEventID;
    }
    @XmlElement
    public void setOriginalEventID(String value) throws Exception {
        this._originalEventID= value;
    }

    @Override
    public String displayEvent() throws Exception {
        return super.displayEvent() +
        "- NotificationEvent{" +
        ", Severity='" + getSeverity().toString() + '\'' +
        ", ShortDescription='" + getShortDescription() + '\'' +
        ", DetailedDescription='" + getDetailedDescription() + '\'' +
        ", ResubmitEventID='" + getResubmitEventID() + '\'' +
        ", ResubmitServiceName='" + getResubmitServiceName() + '\'' +
        ", ResubmitParameters='" + getResubmitParameters() + '\'' +
        ", PayloadMsgBuffer='" + getPayloadMsgBufferString() + '\'' +
        ", PayloadRefEventID='" + getPayloadRefEventID() + '\'' +
        ", PayloadMsgType='" + getPayloadMsgType().toString() + '\'' +
        ", PayloadLogAmount='" + getPayloadLogAmount() + '\'' +
        ", PayloadMsgHeader='" + getPayloadMsgHeader() + '\'' +
        ", OriginalEventID='" + getOriginalEventID() + '\'' +
        '}';
    }
}



