package com.boeing.a2a.ftl;

import org.w3c.dom.*;
import org.xml.sax.*;
import javax.xml.parsers.*;

//import com.boeing.a2a.util.DBUtil;
//import com.boeing.a2a.config.A2AConfiguration;

import java.util.*;
import java.io.*;


/**
 * This class provides a command line interface to the FtlProcessor.
 */
public class ftl
{
   private static int    numErrors = 0;
   private static String specFile = null;
   private static String configFileName = null;
   private static String inputFileName = null;
   private static String outputFileName = null;
   private static boolean inputFormatIsXml = false;
   private static boolean convertFromImsFormat = false;
   private static boolean convertToImsFormat = false;
   private static boolean multipart = false;
   private static boolean genDtd = false;
   private static String  encoding = null;


   public static void main (String args[])
   throws Exception
   {
      FtlProcessor processor = null;

      processOptions (args);
      if (numErrors == 0)
      {
        // if (configFileName != null)
          //  A2AConfiguration.loadConfiguration (configFileName, null, true);

         processor = new FtlProcessor (specFile);

            processor.compileSpec ();

         numErrors = processor.numErrors;
      }

      if (numErrors == 0)
      {
         OutputStream output = null;
         if (multipart)
            output = getNextOutputStream ();
         else
            output = getOutputStream ();

         if (genDtd)
         {
            processor.writeDtd (output);
         }
         else if (inputFormatIsXml)
         {
            InputStream  input = getInputStream ();
            if (convertToImsFormat)
               processor.doXmlToFlatTransform (input, output, true);
            else
               processor.doXmlToFlatTransform (input, output, encoding);
         }
         else
         {
            InputStream  input = getInputStream ();
            if (convertFromImsFormat)
            {
               processor.doIMSToXmlTransform (input, output);
            }
            else if (multipart)
            {
               processor.doFlatToXmlTransform (input, output, encoding);
               while (processor.numErrors == 0 && !processor.eofReached ())
               {
                  if (output != System.out)
                  {
                     output.close ();
                     output = getNextOutputStream ();
                  }
                  processor.convertNextPartOfFlatFileToXml (output);
               }
            }
            else
               processor.doFlatToXmlTransform (input, output, encoding);
         }
         if (output != System.out)
            output.close ();

         // Close the database connection pool, just in case any translation
         // called upon a converter that used the database.
         //DBUtil.closeConnectionPool ();
      }
   }

   private static InputStream getInputStream ()
   throws Exception
   {
      InputStream input = System.in;
      if (inputFileName != null)
      {
         input = new FileInputStream (inputFileName);
      }
      return input;
   }


   private static OutputStream getOutputStream ()
   throws Exception
   {
      OutputStream output = System.out;
      if (outputFileName != null)
      {
         output = new FileOutputStream (outputFileName);
      }
      return output;
   }


   private static int outputStreamCount = 0;
   private static OutputStream getNextOutputStream ()
   throws Exception
   {
      OutputStream output = System.out;
      if (outputFileName != null)
      {
         outputStreamCount += 1;
         String fileName = outputFileName + "." + outputStreamCount;
         output = new FileOutputStream (fileName);
      }
      return output;
   }


   private static void processOptions (String args [])
   throws Exception
   {
      int i = 0;
      while (i < args.length)
      {
         if (args [i].equals ("-spec"))
         {
            i += 1;
            if (i < args.length)
               specFile = args [i];
         }
         else if (args[i].equals ("-config"))
         {
            i += 1;
            if (i < args.length)
               configFileName = args [i];
         }
         else if (args [i].equals ("-dtd"))
         {
            genDtd = true;
         }
         else if (args [i].equals ("-xml"))
         {
            inputFormatIsXml = true;
         }
         else if (args [i].equals ("-flatims"))
         {
            inputFormatIsXml = false;
            convertFromImsFormat = true;
         }
         else if (args [i].equals ("-toims"))
         {
            inputFormatIsXml = true;
            convertToImsFormat = true;
         }
         else if (args [i].equals ("-multipart"))
         {
            multipart = true;
         }
         else if (args [i].equals ("-encoding"))
         {
            i += 1;
            if (i < args.length)
               encoding = args [i];
         }
         else if (args [i].equals ("-out"))
         {
            i += 1;
            if (i < args.length)
               outputFileName = args [i];
         }
         else if (!args[i].startsWith ("-"))
         {
            inputFileName = args [i];
         }
         else
         {
            usageError ();
            return;
         }
         i += 1;
      }
      if (specFile == null)
         usageError ();
   }


   public static void usageError ()
   {
      System.out.println (
        "Usage: ftl -spec <spec file name> " +
        " [-config <config file name>] [-dtd] [-xml]" +
        " [-encoding <character encoding>] [-multipart] [-flatims] [-toims]" +
        " [-out <output file name>] [file name]");

      numErrors += 1;
   }
}
