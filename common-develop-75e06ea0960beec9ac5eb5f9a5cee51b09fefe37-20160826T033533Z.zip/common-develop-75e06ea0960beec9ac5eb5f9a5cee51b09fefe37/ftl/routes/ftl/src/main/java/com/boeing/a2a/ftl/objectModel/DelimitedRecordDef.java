package com.boeing.a2a.ftl.objectModel;

import java.util.*;
import java.io.*;

import xgen.util.xml.XMLDocument;


/**
 * This class provides a Java representation of
 * the XML element <code>delimited-record</code>.
 */
public class DelimitedRecordDef extends RecordDef
implements Serializable
{
   /** supply serialVersionUID for interoperability with older versions*/
   private static final long serialVersionUID = 0000000000000000003L;

   /**
    * Unless overridden by the field contained within this record, this
    * specifies the delimiter to be used by all fields within this record.
    */
   public String  delimiter;
   public String  ov_delimiter;
   /**
     * If the record represents formatted contents of an Excel worksheet cell,
     * specifying this option will escape any embedded characters within the
     * fields the record contains. Two escaping styles are supported:  EXCEL or
     * UNIX formatting conventions.
     *
     * If UNIX is specified, if the field contains any embedded
     * field delimiter or EOL characters they will each be escaped by prefixing
     * a leading backspace character.
     *
     * If EXCEL is specified, embedded double quotes (") will be escaped with
     * another double quote and the whole field then surrounded with an
     * additional set of double quotes.  Embedded field delimiters or EOL
     * characters, will also be surrounded by double quotes. Any field that
     * contains a single quote will also be surrounded by double quotes.
     * As a result <em>1,400</em> would become <em>"1,400"</em> assuming that
     * the comma is the required field delimiter.
    */
   public String  escapingStyle;
   public String  ov_escapingStyle;
   /**
    * Indicates whether the record will output a header consisting of the
    * various field descriptions in the order that they are specified.
    */
   public String  writeHeader;
   public String  ov_writeHeader;
   /**
    * Indicates whether field values comprising this record should be trimmed
    * when written to a file.
    * The legal values for this attribute are <code>true</code> or
    * <code>false</code>. If this attribute is omitted then the
    * field will be trimmed.
    */
   public String  trim;
   public String  ov_trim;
   /**
    * Indicates whether the record will be written if the input XML document
    * does not specify the record.  The default behavior is to write the record
    * regardless of whether it is specified in the input XML document.
    */
   public String  writeWhenXmlMissing;
   public String  ov_writeWhenXmlMissing;


   public Object copy ()
   {
      DelimitedRecordDef result = new DelimitedRecordDef ();
      copyFields (this, result);
      return result;
   }


   protected void copyFields (DelimitedRecordDef src, DelimitedRecordDef dest)
   {
      super.copyFields (src, dest);
      dest.delimiter = src.delimiter;
      dest.ov_delimiter = src.ov_delimiter;
      dest.escapingStyle = src.escapingStyle;
      dest.ov_escapingStyle = src.ov_escapingStyle;
      dest.writeHeader = src.writeHeader;
      dest.ov_writeHeader = src.ov_writeHeader;
      dest.trim = src.trim;
      dest.ov_trim = src.ov_trim;
      dest.writeWhenXmlMissing = src.writeWhenXmlMissing;
      dest.ov_writeWhenXmlMissing = src.ov_writeWhenXmlMissing;
   }


   /**
    * Returns an XML Document representation of this instance of the
    * class <code>DelimitedRecordDef</code>.

    * @param original Specifies whether the original
    * or the resolved document should be represented.
    */
   public XMLDocument toXMLDocument (boolean original)
   throws IOException
   {
      XMLDocument result = new XMLDocument ("delimited-record");
      DelimitedRecordDef instance = null;
      if (original)
      {
         if (this.original == null) return null;
         instance = (DelimitedRecordDef) this.original;
      }
      else
      {
         instance = this;
      }
      addAttributes (result, instance, original);
      addElements (result, instance, original);
      return result;
   }


   /**
    * Adds attributes to the XMLDocument.
    *
    * @param doc Specifies which document to 
    * add the values to.
    * @param instance Specifies which instance to 
    * obtain the attribute values from.
    * @param original Specifies whether the original
    * or the resolved attributes should be represented.
    */
   protected void addAttributes (XMLDocument doc,
                                 DelimitedRecordDef instance,
                                 boolean original)
   throws IOException
   {
      super.addAttributes (doc, instance, original);

      if (original)
      {
         doc.addAttribute ("delimiter", instance.ov_delimiter);
         doc.addAttribute ("escaping-style", instance.ov_escapingStyle);
         doc.addAttribute ("write-header", instance.ov_writeHeader);
         doc.addAttribute ("trim", instance.ov_trim);
         doc.addAttribute ("write-when-xml-missing", instance.ov_writeWhenXmlMissing);
      }
      else
      {
         doc.addAttribute ("delimiter", instance.delimiter);
         doc.addAttribute ("escaping-style", instance.escapingStyle);
         doc.addAttribute ("write-header", instance.writeHeader);
         doc.addAttribute ("trim", instance.trim);
         doc.addAttribute ("write-when-xml-missing", instance.writeWhenXmlMissing);
      }
   }


   /**
    * Adds elements to the XMLDocument.
    *
    * @param doc Specifies which document to 
    * add the values to.
    * @param instance Specifies which instance to 
    * obtain the elements from.
    * @param original Specifies whether the original
    * or the resolved elements should be represented.
    */
   protected void addElements (XMLDocument doc,
                               DelimitedRecordDef instance,
                               boolean original)
   throws IOException
   {
      XMLDocument temp = null;

      super.addElements (doc, instance, original);

   }


   public boolean writeWhenXmlIsMissing = true;

   public boolean writeHeader ()
   {
      if ("true".equalsIgnoreCase(writeHeader))
         return true;
      else
         return false;
   }



}
