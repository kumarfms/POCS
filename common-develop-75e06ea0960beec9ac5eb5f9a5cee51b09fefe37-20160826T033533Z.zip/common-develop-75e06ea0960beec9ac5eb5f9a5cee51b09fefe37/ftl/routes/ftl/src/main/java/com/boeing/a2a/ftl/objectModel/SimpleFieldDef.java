package com.boeing.a2a.ftl.objectModel;

import java.util.*;
import java.io.*;

import xgen.util.xml.XMLDocument;


/**
 * This class provides a Java representation of
 * the XML element <code>field</code>.
 */
public class SimpleFieldDef extends FieldDef
implements Serializable
{
   /** supply serialVersionUID for interoperability with older versions*/
   private static final long serialVersionUID = 0000000000000000003L;

   /**
    * The length of the field in the flat file.
    */
   public String  length;
   public String  ov_length;
   /**
    * A format specification for the field of the form
    * <i>T</i>(<i>length</i>)[V99* ][<b>COMP | COMP-3</b>].
    * <i>T</i> indicates the type of the field as used in COBOL declarations.
    * It can be either A, X, 9, or S9. <i>length</i> is the number of
    * characters or digits the field contains. COMP indicates the field is a 
    * binary field.  COMP-3 indicates the field is a packed numeric field.
    * V99* indicates the field is scaled by the number of nines times 10.  For,
    * example, V99 would indicate that the field is scaled by 100.
    * Either a format attribute or the length attribute  must be specified,
    * but not both.
    */
   public String  format;
   public String  ov_format;
   /**
    * Indicates how a value of this field should be aligned in a flat file.
    * The legal values for this attribute are <code>left</code>,
    * <code>right</code>, or <code>default</code>.
    * If this attribute is omitted, then left alignment
    * will be used, unless a format of <code>9</code> is specified.
    */
   public String  align;
   public String  ov_align;
   /**
    * Indicates the value to use to pad a value that is shorter than
    * its field length, when converting to a flat file.
    * If this attribute is omitted, then the a pad value of <code>' '</code>
    * will be used, unless a format of <code>9</code> is specified, in
    * which case a pad value of <code>'0'</code> will be used.
    */
   public String  pad;
   public String  ov_pad;
   /**
    * Indicates whether values of this field should be trimmed when
    * written to a XML file.
    * The legal values for this attribute are <code>true</code> or
    * <code>false</code>. If this attribute is omitted then the
    * field will be trimmed.
    * <p>
    * If the field is trimmed and field alignment is left,then blanks on the
    * right will be trimmed. If the field alignment is right, then blanks
    * on the left will be trimmed.
    */
   public String  trim;
   public String  ov_trim;
   /**
   * The value of the attribute <code>converter</code>.
   */
   public String  converter;
   public String  ov_converter;
   /**
   * The value of the attribute <code>flat-type</code>.
   */
   public String  flatType;
   public String  ov_flatType;
   /**
   * The value of the attribute <code>xml-type</code>.
   */
   public String  xmlType;
   public String  ov_xmlType;
   /**
   * The value of the attribute <code>value</code>.
   */
   public String  value;
   public String  ov_value;


   public Object copy ()
   {
      SimpleFieldDef result = new SimpleFieldDef ();
      copyFields (this, result);
      return result;
   }


   protected void copyFields (SimpleFieldDef src, SimpleFieldDef dest)
   {
      super.copyFields (src, dest);
      dest.length = src.length;
      dest.ov_length = src.ov_length;
      dest.format = src.format;
      dest.ov_format = src.ov_format;
      dest.align = src.align;
      dest.ov_align = src.ov_align;
      dest.pad = src.pad;
      dest.ov_pad = src.ov_pad;
      dest.trim = src.trim;
      dest.ov_trim = src.ov_trim;
      dest.converter = src.converter;
      dest.ov_converter = src.ov_converter;
      dest.flatType = src.flatType;
      dest.ov_flatType = src.ov_flatType;
      dest.xmlType = src.xmlType;
      dest.ov_xmlType = src.ov_xmlType;
      dest.value = src.value;
      dest.ov_value = src.ov_value;
   }


   /**
    * Returns an XML Document representation of this instance of the
    * class <code>SimpleFieldDef</code>.

    * @param original Specifies whether the original
    * or the resolved document should be represented.
    */
   public XMLDocument toXMLDocument (boolean original)
   throws IOException
   {
      XMLDocument result = new XMLDocument ("field");
      SimpleFieldDef instance = null;
      if (original)
      {
         if (this.original == null) return null;
         instance = (SimpleFieldDef) this.original;
      }
      else
      {
         instance = this;
      }
      addAttributes (result, instance, original);
      addElements (result, instance, original);
      return result;
   }


   /**
    * Adds attributes to the XMLDocument.
    *
    * @param doc Specifies which document to 
    * add the values to.
    * @param instance Specifies which instance to 
    * obtain the attribute values from.
    * @param original Specifies whether the original
    * or the resolved attributes should be represented.
    */
   protected void addAttributes (XMLDocument doc,
                                 SimpleFieldDef instance,
                                 boolean original)
   throws IOException
   {
      super.addAttributes (doc, instance, original);

      if (original)
      {
         doc.addAttribute ("length", instance.ov_length);
         doc.addAttribute ("format", instance.ov_format);
         doc.addAttribute ("align", instance.ov_align);
         doc.addAttribute ("pad", instance.ov_pad);
         doc.addAttribute ("trim", instance.ov_trim);
         doc.addAttribute ("converter", instance.ov_converter);
         doc.addAttribute ("flat-type", instance.ov_flatType);
         doc.addAttribute ("xml-type", instance.ov_xmlType);
         doc.addAttribute ("value", instance.ov_value);
      }
      else
      {
         doc.addAttribute ("length", instance.length);
         doc.addAttribute ("format", instance.format);
         doc.addAttribute ("align", instance.align);
         doc.addAttribute ("pad", instance.pad);
         doc.addAttribute ("trim", instance.trim);
         doc.addAttribute ("converter", instance.converter);
         doc.addAttribute ("flat-type", instance.flatType);
         doc.addAttribute ("xml-type", instance.xmlType);
         doc.addAttribute ("value", instance.value);
      }
   }


   /**
    * Adds elements to the XMLDocument.
    *
    * @param doc Specifies which document to 
    * add the values to.
    * @param instance Specifies which instance to 
    * obtain the elements from.
    * @param original Specifies whether the original
    * or the resolved elements should be represented.
    */
   protected void addElements (XMLDocument doc,
                               SimpleFieldDef instance,
                               boolean original)
   throws IOException
   {
      XMLDocument temp = null;

      super.addElements (doc, instance, original);

   }


   public boolean binary        = false;
   public boolean packedDecimal = false;
   public boolean signed        = false;
   public int     scale         = 0;



}
