package com.boeing.a2a.util.xml;

import org.xml.sax.*;
import java.io.*;
import java.util.*;


/**
 * Resolves all DTD entity references to a file which is specified when
 * the resolver object is constructed. All references to entities whose system
 * Id ends with the string ".dtd" are resolved to this file, ignoring
 * the system ID specified in the DOCTYPE declaration. If the system Id
 * does not end in ".dtd", then default resolver in the parser will
 * be used.
 */
public class ValidatingParserEntityResolver implements EntityResolver
{
   /**
    * The name of the file DTD entity references should resolve to.
    */
   private String dtdFileName = null;



   /**
    * Constructs an entity resolver that resolves all DTD entity requests
    * to the specified actual file name.
    */
   public ValidatingParserEntityResolver (String dtdFileName)
   {
      this.dtdFileName = dtdFileName;
   }


   /**
    * Resolves the specified external entity to the DTD file named when this
    * object was constructed, if the specified system ID ends with the
    * string ".dtd". Otherwise, this method returns null causing the parser
    * to use its default entity resolution.
    */
   public InputSource resolveEntity (String publicId, String systemId)
   throws SAXException
   {
      InputSource result = null;

      if (systemId.endsWith (".dtd"))
      {
         try 
         {
            InputStream input = new FileInputStream (dtdFileName);
            result = new InputSource (input);
         }
         catch (Exception e)
         {
            throw new SAXException (
               "Error resolving entity reference for: " + dtdFileName, e);
         }
      }
      return result;
   }
}
