package com.boeing.a2a.ftl.objectModel;

import java.util.*;
import java.io.*;
import xgen.util.xml.XMLDocument;
import com.boeing.a2a.util.xml.XMLUtils;

/**
 * This class writes an XML representation of the XML
 * binding classes in this package to an output writer.
 */
public class XMLWriter
{
   /**
    * The writer used to write the output.
    */
   public Writer out = null;
   /**
    * The margin used to indent the next line
    * that is written.
    */
   public int margin = 0;
   private int lineLength = 0;


   /**
    * Creates a new XMLWriter,
    * without a specified writer.
    * The field <code>writer</code> should be set
    * before any write methods are called.
    */
   public XMLWriter ()
   {
   }


   /**
    * Creates a new XMLWriter,
    * with the specified writer.
    * @param out The writer to send the output to.
    */
   public XMLWriter (Writer out)
   {
      this.out = out;
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>FtlSpec</code>.
    * @param f The object to be written.
    */
   public void write (FtlSpec f) throws IOException
   {
      if (f == null)
         f = new FtlSpec ();

      write ("<ftl");
      margin += 3;
      writeAttribute ("name", f.name);
      writeln (">");
      for (Iterator i = f.fields.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         write ((FieldDef) item);
      }
      margin -= 3;
      writeln ("</ftl>");
   }


   /**
    * Returns an XML Document representation of an instance of the
    * class <code>FtlSpec</code>.
    * @param f The object to be converted to an XML document.
    */
   public XMLDocument toXMLDocument (FtlSpec f) throws IOException
   {
      XMLDocument result = new XMLDocument ("ftl");
      XMLDocument temp = null;

      if (f == null)
         f = new FtlSpec ();

      result.addAttribute ("name", f.name);
      for (Iterator i = f.fields.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         result.addChild (toXMLDocument ((FieldDef) item));
      }
      return result;
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>FieldDef</code>.
    * @param f The object to be written.
    */
   public void write (FieldDef f) throws IOException
   {
      if (f == null)
         f = new VariantRecordDef ();

      if (f instanceof VariantRecordDef)
         write ((VariantRecordDef) f);
      else if (f instanceof RecordDef)
         write ((RecordDef) f);
      else if (f instanceof DelimitedFieldDef)
         write ((DelimitedFieldDef) f);
      else if (f instanceof DelimitedRecordDef)
         write ((DelimitedRecordDef) f);
      else if (f instanceof SimpleFieldDef)
         write ((SimpleFieldDef) f);
      else if (f instanceof FillerFieldDef)
         write ((FillerFieldDef) f);
      else if (f instanceof EndOfLineFieldDef)
         write ((EndOfLineFieldDef) f);
      else if (f instanceof DateTimeFieldDef)
         write ((DateTimeFieldDef) f);
   }


   /**
    * Returns an XML Document representation of an instance of the
    * class <code>FieldDef</code>.
    * @param f The object to be converted.
    */
   public XMLDocument toXMLDocument (FieldDef f) throws IOException
   {
      if (f == null)
         f = new VariantRecordDef ();

      if (f instanceof VariantRecordDef)
         return toXMLDocument ((VariantRecordDef) f);
      else if (f instanceof RecordDef)
         return toXMLDocument ((RecordDef) f);
      else if (f instanceof DelimitedFieldDef)
         return toXMLDocument ((DelimitedFieldDef) f);
      else if (f instanceof DelimitedRecordDef)
         return toXMLDocument ((DelimitedRecordDef) f);
      else if (f instanceof SimpleFieldDef)
         return toXMLDocument ((SimpleFieldDef) f);
      else if (f instanceof FillerFieldDef)
         return toXMLDocument ((FillerFieldDef) f);
      else if (f instanceof EndOfLineFieldDef)
         return toXMLDocument ((EndOfLineFieldDef) f);
      else if (f instanceof DateTimeFieldDef)
         return toXMLDocument ((DateTimeFieldDef) f);
      else
         return null;
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>VariantRecordDef</code>.
    * @param v The object to be written.
    */
   public void write (VariantRecordDef v) throws IOException
   {
      if (v == null)
         v = new VariantRecordDef ();

      write ("<variant");
      margin += 3;
      writeAttribute ("name", v.name);
      writeAttribute ("repeat", v.repeat);
      writeln (">");
      if ((v.commonFields != null) && (v.commonFields.size () >0))
      {
         writeln ("<common-fields>");
         margin += 3;
         for (Iterator i = v.commonFields.iterator (); i.hasNext ();)
         {
            Object item = i.next ();
            write ((FieldDef) item);
         }
         margin -= 3;
         writeln ("</common-fields>");
      }
      for (Iterator i = v.variants.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         write ((RecordDef) item);
      }
      margin -= 3;
      writeln ("</variant>");
   }


   /**
    * Returns an XML Document representation of an instance of the
    * class <code>VariantRecordDef</code>.
    * @param v The object to be converted to an XML document.
    */
   public XMLDocument toXMLDocument (VariantRecordDef v) throws IOException
   {
      XMLDocument result = new XMLDocument ("variant");
      XMLDocument temp = null;

      if (v == null)
         v = new VariantRecordDef ();

      result.addAttribute ("name", v.name);
      result.addAttribute ("repeat", v.repeat);
      if ((v.commonFields != null) && (v.commonFields.size () >0))
      {
         temp = new XMLDocument ("common-fields");
         result.addChild (temp);
         for (Iterator i = v.commonFields.iterator (); i.hasNext ();)
         {
            Object item = i.next ();
            temp.addChild (toXMLDocument ((FieldDef) item));
         }
      }
      for (Iterator i = v.variants.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         result.addChild (toXMLDocument ((RecordDef) item));
      }
      return result;
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>RecordDef</code>.
    * @param r The object to be written.
    */
   public void write (RecordDef r) throws IOException
   {
      if (r == null)
         r = new RecordDef ();

      if (r instanceof DelimitedRecordDef)
         write ((DelimitedRecordDef) r);
      else
      {
         write ("<record");
         margin += 3;
         writeAttribute ("name", r.name);
         writeAttribute ("repeat", r.repeat);
         writeAttribute ("when", r.when);
         writeAttribute ("omit-xml-tag", r.omitXmlTag);
         writeln (">");
         for (Iterator i = r.fields.iterator (); i.hasNext ();)
         {
            Object item = i.next ();
            write ((FieldDef) item);
         }
         margin -= 3;
         writeln ("</record>");
      }
   }


   /**
    * Returns an XML Document representation of an instance of the
    * class <code>RecordDef</code>.
    * @param r The object to be converted.
    */
   public XMLDocument toXMLDocument (RecordDef r) throws IOException
   {
      if (r == null)
         r = new RecordDef ();

      if (r instanceof DelimitedRecordDef)
         return toXMLDocument ((DelimitedRecordDef) r);
      else
      {
         XMLDocument result = new XMLDocument ("record");
         XMLDocument temp = null;
         result.addAttribute ("name", r.name);
         result.addAttribute ("repeat", r.repeat);
         result.addAttribute ("when", r.when);
         for (Iterator i = r.fields.iterator (); i.hasNext ();)
         {
            Object item = i.next ();
            result.addChild (toXMLDocument ((FieldDef) item));
         }
         result.addAttribute ("omit-xml-tag", r.omitXmlTag);
         return result;
      }
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>DelimitedFieldDef</code>.
    * @param d The object to be written.
    */
   public void write (DelimitedFieldDef d) throws IOException
   {
      if (d == null)
         d = new DelimitedFieldDef ();

      write ("<delimited-field");
      margin += 3;
      writeAttribute ("name", d.name);
      writeAttribute ("repeat", d.repeat);
      writeAttribute ("description", d.description);
      writeAttribute ("delimiter", d.delimiter);
      writeAttribute ("value", d.value);
      writeAttribute ("omit-xml-tag", d.omitXmlTag);
      writeAttribute ("trim", d.trim);
      writeAttribute ("escaping-style", d.escapingStyle);
      writeln (" />");
      margin -= 3;
   }


   /**
    * Returns an XML Document representation of an instance of the
    * class <code>DelimitedFieldDef</code>.
    * @param d The object to be converted to an XML document.
    */
   public XMLDocument toXMLDocument (DelimitedFieldDef d) throws IOException
   {
      XMLDocument result = new XMLDocument ("delimited-field");
      XMLDocument temp = null;

      if (d == null)
         d = new DelimitedFieldDef ();

      result.addAttribute ("name", d.name);
      result.addAttribute ("repeat", d.repeat);
      result.addAttribute ("description", d.description);
      result.addAttribute ("delimiter", d.delimiter);
      result.addAttribute ("value", d.value);
      result.addAttribute ("omit-xml-tag", d.omitXmlTag);
      result.addAttribute ("trim", d.trim);
      result.addAttribute ("escaping-style", d.escapingStyle);
      return result;
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>DelimitedRecordDef</code>.
    * @param d The object to be written.
    */
   public void write (DelimitedRecordDef d) throws IOException
   {
      if (d == null)
         d = new DelimitedRecordDef ();

      write ("<delimited-record");
      margin += 3;
      writeAttribute ("name", d.name);
      writeAttribute ("repeat", d.repeat);
      writeAttribute ("when", d.when);
      writeAttribute ("omit-xml-tag", d.omitXmlTag);
      writeAttribute ("delimiter", d.delimiter);
      writeAttribute ("escaping-style", d.escapingStyle);
      writeAttribute ("write-header", d.writeHeader);
      writeAttribute ("trim", d.trim);
      writeAttribute ("write-when-xml-missing", d.writeWhenXmlMissing);
      writeln (">");
      for (Iterator i = d.fields.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         write ((FieldDef) item);
      }
      margin -= 3;
      writeln ("</delimited-record>");
   }


   /**
    * Returns an XML Document representation of an instance of the
    * class <code>DelimitedRecordDef</code>.
    * @param d The object to be converted to an XML document.
    */
   public XMLDocument toXMLDocument (DelimitedRecordDef d) throws IOException
   {
      XMLDocument result = new XMLDocument ("delimited-record");
      XMLDocument temp = null;

      if (d == null)
         d = new DelimitedRecordDef ();

      result.addAttribute ("name", d.name);
      result.addAttribute ("repeat", d.repeat);
      result.addAttribute ("when", d.when);
      for (Iterator i = d.fields.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         result.addChild (toXMLDocument ((FieldDef) item));
      }
      result.addAttribute ("omit-xml-tag", d.omitXmlTag);
      result.addAttribute ("delimiter", d.delimiter);
      result.addAttribute ("escaping-style", d.escapingStyle);
      result.addAttribute ("write-header", d.writeHeader);
      result.addAttribute ("trim", d.trim);
      result.addAttribute ("write-when-xml-missing", d.writeWhenXmlMissing);
      return result;
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>SimpleFieldDef</code>.
    * @param s The object to be written.
    */
   public void write (SimpleFieldDef s) throws IOException
   {
      if (s == null)
         s = new SimpleFieldDef ();

      write ("<field");
      margin += 3;
      writeAttribute ("name", s.name);
      writeAttribute ("repeat", s.repeat);
      writeAttribute ("length", s.length);
      writeAttribute ("format", s.format);
      writeAttribute ("align", s.align);
      writeAttribute ("pad", s.pad);
      writeAttribute ("trim", s.trim);
      writeAttribute ("converter", s.converter);
      writeAttribute ("flat-type", s.flatType);
      writeAttribute ("xml-type", s.xmlType);
      writeAttribute ("value", s.value);
      writeln (" />");
      margin -= 3;
   }


   /**
    * Returns an XML Document representation of an instance of the
    * class <code>SimpleFieldDef</code>.
    * @param s The object to be converted to an XML document.
    */
   public XMLDocument toXMLDocument (SimpleFieldDef s) throws IOException
   {
      XMLDocument result = new XMLDocument ("field");
      XMLDocument temp = null;

      if (s == null)
         s = new SimpleFieldDef ();

      result.addAttribute ("name", s.name);
      result.addAttribute ("repeat", s.repeat);
      result.addAttribute ("length", s.length);
      result.addAttribute ("format", s.format);
      result.addAttribute ("align", s.align);
      result.addAttribute ("pad", s.pad);
      result.addAttribute ("trim", s.trim);
      result.addAttribute ("converter", s.converter);
      result.addAttribute ("flat-type", s.flatType);
      result.addAttribute ("xml-type", s.xmlType);
      result.addAttribute ("value", s.value);
      return result;
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>FillerFieldDef</code>.
    * @param f The object to be written.
    */
   public void write (FillerFieldDef f) throws IOException
   {
      if (f == null)
         f = new FillerFieldDef ();

      write ("<filler");
      margin += 3;
      writeAttribute ("name", f.name);
      writeAttribute ("repeat", f.repeat);
      writeAttribute ("length", f.length);
      writeAttribute ("value", f.value);
      writeln (" />");
      margin -= 3;
   }


   /**
    * Returns an XML Document representation of an instance of the
    * class <code>FillerFieldDef</code>.
    * @param f The object to be converted to an XML document.
    */
   public XMLDocument toXMLDocument (FillerFieldDef f) throws IOException
   {
      XMLDocument result = new XMLDocument ("filler");
      XMLDocument temp = null;

      if (f == null)
         f = new FillerFieldDef ();

      result.addAttribute ("name", f.name);
      result.addAttribute ("repeat", f.repeat);
      result.addAttribute ("length", f.length);
      result.addAttribute ("value", f.value);
      return result;
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>EndOfLineFieldDef</code>.
    * @param e The object to be written.
    */
   public void write (EndOfLineFieldDef e) throws IOException
   {
      if (e == null)
         e = new EndOfLineFieldDef ();

      write ("<eol");
      margin += 3;
      writeAttribute ("name", e.name);
      writeAttribute ("repeat", e.repeat);
      writeln (" />");
      margin -= 3;
   }


   /**
    * Returns an XML Document representation of an instance of the
    * class <code>EndOfLineFieldDef</code>.
    * @param e The object to be converted to an XML document.
    */
   public XMLDocument toXMLDocument (EndOfLineFieldDef e) throws IOException
   {
      XMLDocument result = new XMLDocument ("eol");
      XMLDocument temp = null;

      if (e == null)
         e = new EndOfLineFieldDef ();

      result.addAttribute ("name", e.name);
      result.addAttribute ("repeat", e.repeat);
      return result;
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>DateTimeFieldDef</code>.
    * @param d The object to be written.
    */
   public void write (DateTimeFieldDef d) throws IOException
   {
      if (d == null)
         d = new DateTimeFieldDef ();

      write ("<datetime");
      margin += 3;
      writeAttribute ("name", d.name);
      writeAttribute ("repeat", d.repeat);
      writeln (" />");
      margin -= 3;
   }


   /**
    * Returns an XML Document representation of an instance of the
    * class <code>DateTimeFieldDef</code>.
    * @param d The object to be converted to an XML document.
    */
   public XMLDocument toXMLDocument (DateTimeFieldDef d) throws IOException
   {
      XMLDocument result = new XMLDocument ("datetime");
      XMLDocument temp = null;

      if (d == null)
         d = new DateTimeFieldDef ();

      result.addAttribute ("name", d.name);
      result.addAttribute ("repeat", d.repeat);
      return result;
   }


   private void writeAttribute (String name, Object value)
   throws IOException
   {
      if (value != null)
      {
         writeln ();
         write (" " + name + "=");
         write ("\"" + XMLDocument.xmlEscape (value.toString ()) + "\"");
      }
   }


   private void writeElement (String name, Object value)
   throws IOException
   {
      writeln ();
      if (value != null)
      {
         write ("<" + name + ">");
         write (XMLDocument.xmlEscape (value.toString ()));
         write ("</" + name + ">");
      }
      else
      {
         write ("<" + name + "/>");
      }
   }


   private void startLine () throws IOException
   {
      for (int i = 0; i < margin; i ++)
         out.write (' ');
      lineLength = margin;
   }


   private void write (char ch) throws IOException
   {
      if (lineLength == 0)
         startLine ();

      out.write (ch);
      lineLength += 1;

      if (ch == '\n')
         lineLength = 0;
   }


   private void write (String s) throws IOException
   {
      for (int i = 0; i < s.length (); i++)
         write (s.charAt (i));
   }


   private void writeln (String s) throws IOException
   {
      write (s);
      write ("\n");
   }


   private void writeln () throws IOException
   {
      write ("\n");
   }
}
