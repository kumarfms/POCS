package com.boeing.a2a.ftl;

/**
 *  An FTL converter performs data conversions during FTL transformations.
 */
public class FtlNullConverter implements FtlConverter
{
   /**
    * Converts a value to itself regardless of the specified source and
    * target types.
    * @param  value  the value to be converted.
    * @param  sourceType  the logical type of the value to be converted.
    * @param  targetType  the logical type the value should be converted to.
    * @return the original value.
    */
   public String convert (String value, String sourceType, String targetType)
   {
      return value;
   }
}
