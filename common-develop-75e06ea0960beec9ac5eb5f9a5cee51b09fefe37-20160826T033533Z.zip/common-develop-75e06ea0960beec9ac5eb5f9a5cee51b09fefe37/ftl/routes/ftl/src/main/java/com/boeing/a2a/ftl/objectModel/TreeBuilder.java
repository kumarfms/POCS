package com.boeing.a2a.ftl.objectModel;

import java.util.*;
import java.io.*;
import javax.swing.tree.DefaultMutableTreeNode;
import com.boeing.a2a.util.xml.XMLUtils;

public class TreeBuilder
{


   public void buildTree (DefaultMutableTreeNode top, FtlSpec f)
   {
      if (f == null) return;

      DefaultMutableTreeNode treeNode =
        new DefaultMutableTreeNode(f);
      top.add(treeNode);
      treeNode.setAllowsChildren (true);
      for (Iterator i = f.fields.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         buildTree (treeNode, (FieldDef) item);
      }
   }


   public void buildTree (DefaultMutableTreeNode top, FieldDef f)
   {
      if (f == null) return;

      if (f instanceof VariantRecordDef)
         buildTree (top, (VariantRecordDef) f);
      else if (f instanceof RecordDef)
         buildTree (top, (RecordDef) f);
      else if (f instanceof SimpleFieldDef)
         buildTree (top, (SimpleFieldDef) f);
      else if (f instanceof FillerFieldDef)
         buildTree (top, (FillerFieldDef) f);
      else if (f instanceof EndOfLineFieldDef)
         buildTree (top, (EndOfLineFieldDef) f);
      else if (f instanceof DateTimeFieldDef)
         buildTree (top, (DateTimeFieldDef) f);
   }


   public void buildTree (DefaultMutableTreeNode top, VariantRecordDef v)
   {
      if (v == null) return;

      DefaultMutableTreeNode treeNode =
        new DefaultMutableTreeNode(v);
      top.add(treeNode);
      treeNode.setAllowsChildren (true);
      for (Iterator i = v.commonFields.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         buildTree (treeNode, (FieldDef) item);
      }
      for (Iterator i = v.variants.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         buildTree (treeNode, (RecordDef) item);
      }
   }


   public void buildTree (DefaultMutableTreeNode top, RecordDef r)
   {
      if (r == null) return;

      DefaultMutableTreeNode treeNode =
        new DefaultMutableTreeNode(r);
      top.add(treeNode);
      treeNode.setAllowsChildren (true);
      for (Iterator i = r.fields.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         buildTree (treeNode, (FieldDef) item);
      }
   }


   public void buildTree (DefaultMutableTreeNode top, SimpleFieldDef s)
   {
      if (s == null) return;

      DefaultMutableTreeNode treeNode =
        new DefaultMutableTreeNode(s);
      top.add(treeNode);
      treeNode.setAllowsChildren (false);
   }


   public void buildTree (DefaultMutableTreeNode top, FillerFieldDef f)
   {
      if (f == null) return;

      DefaultMutableTreeNode treeNode =
        new DefaultMutableTreeNode(f);
      top.add(treeNode);
      treeNode.setAllowsChildren (false);
   }


   public void buildTree (DefaultMutableTreeNode top, EndOfLineFieldDef e)
   {
      if (e == null) return;

      DefaultMutableTreeNode treeNode =
        new DefaultMutableTreeNode(e);
      top.add(treeNode);
      treeNode.setAllowsChildren (false);
   }


   public void buildTree (DefaultMutableTreeNode top, DateTimeFieldDef d)
   {
      if (d == null) return;

      DefaultMutableTreeNode treeNode =
        new DefaultMutableTreeNode(d);
      top.add(treeNode);
      treeNode.setAllowsChildren (false);
   }
}
