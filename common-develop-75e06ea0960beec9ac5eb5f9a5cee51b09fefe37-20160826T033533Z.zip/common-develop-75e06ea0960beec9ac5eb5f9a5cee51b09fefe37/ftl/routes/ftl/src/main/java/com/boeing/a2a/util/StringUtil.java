package com.boeing.a2a.util;
import java.lang.Math;
/** Test @modelguid {37430256-42E2-4B78-B274-031BC84C710C} */
public final class StringUtil {
   
   /**
    * Left justify a String.
    * If theString is greater than theLength then truncate theString to theLength.
    * If theString is less than theLength then pad the right most characters with thePadCharacter to theLength.
    *
    * @return java.lang.String
    * @param theString java.lang.String
    * @param theLength int
    * @param thePadCharacter java.lang.String
    * @modelguid {5A9A6051-6860-40C0-B834-BBC0CF9778FC}
    */
   public static String left(String theString, int theLength, char thePadCharacter) {
      String returnString;
      if (theLength < theString.length())
         returnString = theString.substring(0,theLength);
      else {
         returnString = theString;
         for (int j = returnString.length(); j < theLength; j++)
            returnString = returnString + thePadCharacter;
      }
      return returnString;
   }
   /**
    * Right justify a String.
    * If theString is greater than theLength then truncate theString to theLength.
    * If theString is less than theLength then pad the left most characters with thePadCharacter to theLength.
    *
    * @return java.lang.String
    * @param theString java.lang.String
    * @param theLength int
    * @param thePadCharacter java.lang.String
    * @modelguid {54CD0B92-59D4-4556-844F-657B0E54A8F1}
    */
   public static String right(String theString, int theLength, char thePadCharacter) {
      String returnString;
      if (theLength < theString.length())
         returnString = theString.substring(0,theLength);
      else {
         returnString = theString;
         for (int j = returnString.length(); j < theLength; j++)
            returnString = thePadCharacter + returnString;
      }
      return returnString;
   }


    /**
     ** The leadingCharacters method will the return the leading characters of a string up to the point 
     ** where a number is found e.g. "AW4999" will return "AW". It's typical use would be to return 
     ** the Customer part of the MES MODEL string which has the Customer and Effectivity values in a 
     ** single tag
     **
     ** @param inValue
     **       The string to be parsed
     **
     ** @return the leading characters
     */
    public static String leadingCharacters(String inValue) {
        String returnValue = "";

        int breakPoint = 0;

        for (int i = 0; i < inValue.length(); i++) {
            if (Character.isDigit(inValue.charAt(i))) {
                breakPoint = i;
                break;
            }
        }

        returnValue = inValue.substring(0, breakPoint);
	return(returnValue);
    }
    

    /**
     ** The trailingNumbers method will the return the trailing characters of a string starting at 
     ** the point where a number is found e.g. "AW4999" will return "4999". It's typical use would
     ** be to return the Effectivity part of the MES MODEL string which has the Customer and Effectivity
     ** values in a single tag
     **
     ** @param inValue
     **       The string to be parsed
     **
     ** @return the trailing numbers
     */
    public static String trailingNumbers(String inValue) {
        String returnValue = "";

        int breakPoint = 0;

        for (int i = 0; i < inValue.length(); i++) {
            if (Character.isDigit(inValue.charAt(i))) {
                breakPoint = i;
                break;
            }
        }

        returnValue = inValue.substring(breakPoint);
	return(returnValue);
    }
    

/* This function returns a string with leading trailing characters or both
 * removed based the option you specify.
 *
 * The following is the valid syntax:
 *                 STRIP(buffer,string,option,char)
 *
 * The following are valid options:
 *                 'B', 'L', or 'T' where
 *                 'B' = removes both leading and trailing
 *                       characters from string.
 *                 'L' = removes leading characters from string.
 *                 'T' = removes trailing character from string.
 * @modelguid {7826ADDA-9140-414B-977E-052A1D38AEB1}
 */
   public static String strip(String str, char type, char character) {
      int i;
      String n = str;
      
      if (str == null) return("");
      
      /* Strip Leading */
      if (type == 'L' || type == 'l' || type == 'B' || type == 'b') {
         for (i = 0;  i < n.length() && n.charAt(i) == character; i++);
         n = n.substring(i);
      }
      
      if (type == 'T' || type == 't' || type == 'B' || type == 'b') {
         for (i = n.length()-1; i > 0 && n.charAt(i) == character; i--);
         String t = n.substring(0,i+1);
         n = t;
      }
      
      return n;
   }

   public static String word(String theString, int nth)
   {
      return delaminatedWord(theString, nth, ' ');
   }

   /**
    * This method returns the nth word of theString.
    * Return null if there were not enough words.
    *
    * @return java.lang.String
    * @param theString java.lang.String
    * @param nth int
    */
   public static String delaminatedWord(String theString, int nth, char delaminationCharacter) {
      boolean previousIgnoredChar = true;
      boolean done  = false;
      int wordCount = 0;
      char c;
      int endPos = 0;
      int startPos = 0;
      int i;
      boolean foundDoubleQuote	= false;
      
      // find the start position of the nth word
      while (wordCount != nth && endPos < theString.length()) {
         c = theString.charAt(endPos);
         if (c != delaminationCharacter && c != '\t') {
            wordCount++;
            startPos = endPos;
            if (c == '"') {
               startPos++;
               for (foundDoubleQuote = false, endPos++; endPos < theString.length() && !foundDoubleQuote; endPos++) {
                  c = theString.charAt(endPos);
                  if (c == '"')
                     foundDoubleQuote = true;
               }
               if (wordCount == nth)
                  endPos--;
            } else {
               for (endPos++ ;endPos < theString.length() && theString.charAt(endPos) != delaminationCharacter
               && theString.charAt(endPos) != '\t'; endPos++);
            }
         }
         else {
            for (endPos++ ;endPos < theString.length() && (   theString.charAt(endPos) == delaminationCharacter
            || theString.charAt(endPos) == '\t'); endPos++);
         }
      }
      
      if (wordCount == nth)
         return theString.substring(startPos,endPos);
      else
         return null;
   }
   
   /**
    * Normalize spaces means to strip of leading and trailing spaces and remove multiple spaces between words.
    *
    * @return java.lang.String
    * @param theString java.lang.String
    * @modelguid {D72C8B82-9DA1-4211-A6E1-1DE9D1B9C471}
    */
   public static String normalizeSpace(
   String str       // the string to normalize spaces
   ) {
      boolean			firstBlank = true;
      String			strippedString;
      StringBuffer 	stringBuffer = new StringBuffer();
      
      // if the string is null return an empty string
      if (str == null) return("");
      
      // strip the string of "B"oth leading and training spaces
      strippedString = strip(str,'B',' ');
      
      for (int i = 0;  i < strippedString.length(); i++) {
         if (strippedString.charAt(i) != ' ') {
            stringBuffer.append(strippedString.charAt(i));
            firstBlank = true;
         } else {
            if (firstBlank) {
               stringBuffer.append(strippedString.charAt(i));
               firstBlank = false;
            }
         }
      }
      
      return stringBuffer.toString();
   }
   
   /**
    * Normalize spaces means to strip of leading and trailing spaces and remove multiple spaces between words.
    *
    * @return java.lang.String
    * @param theString java.lang.String
    * @modelguid {DFDD211A-D1EB-41B2-9995-3CF4742A0A6C}
    */
   public static String replace(
   String sourceStr,       // the string to replace
   String searchStr,
   String replaceStr
   ) {
      int				index = 0;
      int				foundIndex = 0;
      StringBuffer 	stringBuffer = new StringBuffer();
      while (foundIndex != -1) {
         foundIndex = sourceStr.indexOf(searchStr,index);
         if (foundIndex != -1) {
            stringBuffer.append(sourceStr.substring(index,foundIndex));
            stringBuffer.append(replaceStr);
            index = foundIndex + searchStr.length();
         } else
            stringBuffer.append(sourceStr.substring(index,sourceStr.length()));
         
      }
      
      return stringBuffer.toString();
   }
   
   /**
    * This method returns an string array based on an arg string representation
    * Example  stringArgs("[-query][select * from dual][-db_user_id][hms]")
    * returns String[] args = new String[4] where:
    *   arg[0] = "-query"
    *   arg[1] = "select * from dual"
    *   arg[2] = "-db_user_id"
    *   arg[3] = "hms"
    *
    * Throws Exception if none or mismatched open, close chars.
    *
    * @modelguid {B92B7FD1-B904-47F4-AAC6-9DF9D8DA0D23}
    */
   public static String[] stringArgs(String theString, char open, char close)
   throws Exception {
      int			closeCount	= 0;
      int			openCount	= 0;
      int			pos			= 0;
      String[]	args = null;
      
      for (int i = 0; i < theString.length(); i++) {
         if      (theString.charAt(i) == open )
            openCount++;
         else if (theString.charAt(i) == close)
            closeCount++;
         if (openCount != closeCount && openCount != closeCount+1)
            throw new Exception("Error in stringArgs, Mismatched "+open+" to "+close+".");
      }
      if (openCount != closeCount || openCount == 0)
         throw new Exception("Error in stringArgs, Mismatched "+open+" to "+close+".");
      
      // count for open then closed
      args = new String[openCount];
      for (int i = 0; i < openCount; i++) {
         args[i] = theString.substring(theString.indexOf(open,pos)+1,theString.indexOf(close,pos));
         pos = theString.indexOf(close,pos) + 1;
      }
      
      return args;
   }
   
   /**
    * This method returns the nth word of theString.
    * Return null if there were on enough words.
    *
    * @return java.lang.String
    * @param theString java.lang.String
    * @param nth int
    * @modelguid {E9C8D4BD-4249-4A0E-8ACF-40D92A3D8D6E}
    */
   public static int words(String theString) {
      int     i;                    /* string index                     */
      int     len=0;                /* length of from string            */
      int     w=0;                  /* word counter                     */
      boolean blank=true;           /* toggel from blank to non-blank   */
      
      /* get the length of the string */
      len = theString.length();
      
      /* Index thru the string and count the number of changes from */
      /* blank to non-blank characters.                             */
      for (i=0; i < len; i++) {
         if (blank) {
            if (theString.charAt(i) != ' ' && theString.charAt(i) != '\t') {
               blank = false;
               w++;
               if (theString.charAt(i) == '"')
                  for (i++; i < len && theString.charAt(i) != '"'; i++);
            }
         }
         else {
            if (theString.charAt(i) == ' ' && theString.charAt(i) != '\t')
               blank = true;
         }
      }
      return(w);
   }
   
	/** @modelguid {63BB4D7C-1CCF-421E-B8B7-F48C045B5D56} */
   public static String capitalize(String theString) {
      String returnString = "";
      String tString;
      if( theString.length() > 0 ) {
         theString = theString.toLowerCase();
         tString = theString.substring(0,1).toUpperCase();
         returnString = tString + theString.substring(1);
      }
      return returnString;
   }
   
	/** @modelguid {86947971-5871-42E4-94CD-B551EBBE9E90} */
   public static String vFormat(String theString, int before, int numDecimals) {
      String returnString = "";
      if ( theString != "" && theString != null && theString != "NaN" ) {
         Float sFloat = Float.valueOf(theString);
         float mFloat = sFloat.floatValue() * (float)StrictMath.pow(10,numDecimals);
         returnString = Float.toString(mFloat);
         int dIdx = returnString.indexOf(".");
         returnString = returnString.substring(0,dIdx);
      }
      returnString = right(returnString, before+numDecimals, '0');
      return returnString;
   }
   /*
    * This method returns a string resembles the format number(5,4) example "12.123", "12345", "0.1234"
    */
    public static String oFormat (String theString, int numSize, int numDecimals) {
        String returnString = "";
        String uptoDecimal = "";
        String afterDecimal = "";
        if (theString != "" && theString != null) {
            int up2dec = theString.indexOf (".");
            if (up2dec != -1) {
                uptoDecimal = theString.substring (0,up2dec);
                if (up2dec+numDecimals+1 < theString.length ())
                    afterDecimal = theString.substring (up2dec+1, up2dec + numDecimals+1);
                else
                    afterDecimal = theString.substring (up2dec+1);
                
                returnString = uptoDecimal + "." + afterDecimal;
                
                if ( uptoDecimal.length () == numSize )
                    returnString = returnString.substring (0, numSize );
                if ( uptoDecimal.length ()+1 == numSize )
                    returnString = returnString.substring (0, numSize -1);
                if (returnString.length () > numSize)
                    returnString = returnString.substring (0, numSize );
            } else {
                if ( theString.length () < numSize )
                    returnString = theString.substring (0, theString.length ());
                else
                    returnString = theString.substring (0, numSize);                    
            }
        }
        return returnString;
    }
	/** @modelguid {B5E358B2-9F22-4671-A96D-55CD17938C66} */
      public static int positionOfDecimal(String theString, String token) {
         int dIdx = theString.indexOf(token);
         if ( dIdx == -1 ) 
            dIdx = 0;
         else
            dIdx = theString.length() - dIdx - 1;
      return dIdx;
   }
 
   /*
    * This method repeats a string pattern a specified number of times.
    * @modelguid {A508E821-83F3-4DD0-88B3-F06ED6E6D380}
    */
   public static String repeat(String stringToRepeat, int numberOfTimes)
   throws IllegalArgumentException {
      if (numberOfTimes <= 0) {
         String errMsg = "Number of times to repeat a string should be " +
         "greater than or equal to 1.";
         throw new IllegalArgumentException(errMsg);
      }
      
      StringBuffer buffer = new StringBuffer();
      for (int i=1; i <= numberOfTimes; i++)
         buffer.append(stringToRepeat);
      
      return buffer.toString();
   }
   
 /* Given a string and a desired number of bytes this method 
  * creates a string of concatinated CHR functions for each desired bytes
  * Example: 
  * theString of "2006195" is hex "1E9CB3" if byteSize of 4 is specified the hex
  * would be padded as "001E9CB3" producing CHR(00)||CHR(30)||CHR(156)||CHR(179)
*/
    public static String stringToOracleConcatChars(String theString, String byteSize)
   {
   	
      StringBuffer returnString = new StringBuffer();
      int bytes = Integer.parseInt(byteSize);
      String hexString = Integer.toHexString(Integer.parseInt(theString));

      // put leading zeores to the desired number of bytes
      while (hexString.length() < bytes*2)
      {
      	hexString = "0"+hexString;
      }

      // loop for each two hex characters and append the CHR function with the interger value of the hex 
      String concatString = "";
      for (int i = 0; i < hexString.length(); i=i+2)
      {
         returnString.append(concatString+"CHR("+Integer.decode("0x"+hexString.substring(i,i+2))+")");
         if (i == 0)
      	   concatString = "||";
      }
      return returnString.toString();
   }


    public static String calc(String firstString, String secondString, String operation)
   {
      java.lang.Double firstDouble  = java.lang.Double.valueOf(firstString);
      java.lang.Double secondDouble = java.lang.Double.valueOf(secondString);

      if      (operation.equals("+"))
         return ((new java.lang.Double(firstDouble+secondDouble)).toString());
      else if (operation.equals("-"))
         return ((new java.lang.Double(firstDouble-secondDouble)).toString());
      else if (operation.equals("*"))
         return ((new java.lang.Double(firstDouble*secondDouble)).toString());
      else if (operation.equals("/"))
         return ((new java.lang.Double(firstDouble/secondDouble)).toString());
      else if (operation.equals("%"))
         return ((new java.lang.Double(firstDouble%secondDouble)).toString());
      else
         return "null";
   }
      
	/** @modelguid {01339B54-F53F-41EC-840D-446AD57CABF4} */
/*
   public static void main(String[] args) {
      String mesCode;
      String mprCode;
      
      try {
         System.out.println( vFormat(null,6,3));
         System.out.println( vFormat("0.",6,3));
         System.out.println( vFormat("",6,3));
         System.out.println( vFormat(".0",6,3));
         
         System.out.println( vFormat("0",6,3));
         System.out.println( vFormat("10.0",5,3));
         System.out.println( vFormat("1.00",2,3));
         System.out.println( vFormat(".100",2,3));
         System.out.println( vFormat("0.100",2,3));
         System.out.println( vFormat("0.10",2,3));
         System.out.println( vFormat("0.01",2,3));
      }
      catch(Exception e) {
         System.out.println(e);
         e.printStackTrace(System.out);
      }
   }
*/
}

