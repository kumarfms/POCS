package com.boeing.a2a.util.logging;


public interface LoggerInterface
{
   public void debug (String s);
   public void debug (String s, Throwable t);
   public void info (String s);
   public void info (String s, Throwable t);
   public void warn (String s);
   public void warn (String s, Throwable t);
   public void error (String s);
   public void error (String s, Throwable t);
}
