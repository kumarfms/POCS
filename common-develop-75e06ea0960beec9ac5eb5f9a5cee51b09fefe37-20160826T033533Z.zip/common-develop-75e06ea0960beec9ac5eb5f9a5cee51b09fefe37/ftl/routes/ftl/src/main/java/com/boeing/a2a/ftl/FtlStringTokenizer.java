package com.boeing.a2a.ftl;

public class FtlStringTokenizer
{
   public final static int EOS = 0;
   public final static int SPECIAL_CHAR = 1;
   public final static int OTHER = 2;

   public int          tokenType = 0;
   public StringBuffer text = new StringBuffer ();

   private String s;
   private int    pos = 0;
   private int    ch;
   private String stoppingTokens = null;
   private boolean ignoreWhiteSpace = false;

   public FtlStringTokenizer (String s, String delimiters)
   {
      this.s = s;
      stoppingTokens = delimiters;
      getCh ();
      getToken ();
   }


   public void ignoreWhiteSpace ()
   {
      ignoreWhiteSpace = true;
      stoppingTokens += " ";
   }
   
   
   private void getCh ()
   {
      if (pos < s.length ())
         ch = s.charAt (pos++);
      else
         ch = -1;
   }


   public void getToken ()
   {
      text.setLength (0);
      
      if (ignoreWhiteSpace)
      {
         while (ch == ' ')
            getCh();
      }
      
      if (ch == -1)
      {
         tokenType = EOS;
      }
      else if (stoppingTokens.indexOf (ch) != -1)
      {
         text.append ((char) ch);
         getCh ();
         tokenType = SPECIAL_CHAR;
      }
      else
      {
         while (ch != -1 && stoppingTokens.indexOf (ch) == -1)
         {
            text.append ((char)ch);
            getCh ();
         }
         tokenType = OTHER;
      }
   }
}
