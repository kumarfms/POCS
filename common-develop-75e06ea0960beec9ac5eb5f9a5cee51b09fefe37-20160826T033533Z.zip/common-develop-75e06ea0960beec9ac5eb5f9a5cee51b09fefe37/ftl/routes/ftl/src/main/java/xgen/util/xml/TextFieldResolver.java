package xgen.util.xml;

public class TextFieldResolver
{
   public String resolve (String suppliedValue)
   {
      return suppliedValue;
   }


   public String resolve (String suppliedValue, String defaultValue)
   {
      if (suppliedValue != null)
      {
         return resolve (suppliedValue);
      }
      else
      {
         return resolve (defaultValue);
      }
   }
}
