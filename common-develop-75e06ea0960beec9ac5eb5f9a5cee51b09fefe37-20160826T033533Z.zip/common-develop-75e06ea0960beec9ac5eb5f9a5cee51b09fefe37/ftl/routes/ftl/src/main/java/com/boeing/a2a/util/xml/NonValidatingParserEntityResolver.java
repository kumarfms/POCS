package com.boeing.a2a.util.xml;

import org.xml.sax.*;
import java.io.*;
import java.util.*;


/**
 * Resolves all DTD entity references to an empty byte stream.
 * All references to entities whose system Id ends with the string ".dtd"
 * are resolved to an empty byte stream, because a non-validating compiler
 * does not need access to the DTD infomation. This enables clients
 * to do non-validating parsing regardless of the DOCTYPE declaration.
 */
public class NonValidatingParserEntityResolver implements EntityResolver
{
   /**
    * Resolves the specified external entity to an empty byte stream,
    * if the specified system ID ends with the string ".dtd". Otherwise,
    * this method returns null causing the parser to use its default
    * entity resolution.
    */
   public InputSource resolveEntity (String publicId, String systemId)
   {
      InputSource result = null;

      if (systemId.endsWith (".dtd"))
      {
         byte[] byteArray = new byte [0];
         ByteArrayInputStream input = new ByteArrayInputStream (byteArray);
         result = new InputSource (input);
      }
      return result;
   }
}
