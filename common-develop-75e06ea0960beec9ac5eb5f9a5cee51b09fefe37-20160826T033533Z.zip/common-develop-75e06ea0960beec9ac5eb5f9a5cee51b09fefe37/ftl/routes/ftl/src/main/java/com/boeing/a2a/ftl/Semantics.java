package com.boeing.a2a.ftl;

import java.util.*;
import com.boeing.a2a.ftl.objectModel.*;

import org.xml.sax.Locator;

/**
 * This class performs semantic analysis of an FTL transformation
 * specification.
 * model. The FTL specification object model is normally created by
 * first parsing a user-provided XML document. This class checks such
 * a model for inconsistencies and updates the model with additional
 * attributes to make it easier for other program components to use.
*/
public class Semantics
{
   public  FtlSpec  document;
   public  int      numErrors = 0;

   /**
    * Constructs an instance of this class that will analyze and complete
    * the attribute definitions of the specification object model
    * referred to by the parameter document. This parameter should
    * point to the root node of the tree representing the transformation
    * specification.
    */
   public Semantics (Object document)
   {
      this.document = (FtlSpec) document;
   }


   /**
    * Performs semantic analysis on the object model it is associated
    * with (by the constructor) and returns the number of errors
    * found.
    */
   public int analyze () throws Exception
   {
      checkFieldList (null, document.fields);
      return numErrors;
   }


   private void checkFieldList (FieldDef parentRecord, List fields)
   throws Exception
   {
      DelimitedRecordDef dr = new DelimitedRecordDef ();
      FieldDef prevSibling = null;

      if (parentRecord instanceof DelimitedRecordDef)
      {
         dr = (DelimitedRecordDef) parentRecord;
      }

      for (Iterator i = fields.iterator (); i.hasNext ();)
      {
         FieldDef f = (FieldDef) i.next ();
         
         f.parentRecord = parentRecord;
         f.prevSibling = prevSibling;
         checkField (f);
         prevSibling = f;

         if (dr.writeHeader ())
         {
            if (!(f instanceof DelimitedFieldDef) &&
                !(f instanceof EndOfLineFieldDef))
            {
             error (f.locator,
               "When writing a delimited record header, all fields defined " +
               "within the delimited record must be of the delimited field " +
               "type.");
            }
         }
      }
   }


   private void checkField (FieldDef f)
   throws Exception
   {
      resolveRepetitionCount (f);
      
      if (f instanceof RecordDef)
      {
         if (f instanceof DelimitedRecordDef)
            checkDelimitedRecordDef ((DelimitedRecordDef) f);
         else
            checkRecordDef ((RecordDef) f);
      }
      else if (f instanceof VariantRecordDef)
         checkVariantRecordDef ((VariantRecordDef) f);
      else if (f instanceof SimpleFieldDef)
         checkSimpleFieldDef ((SimpleFieldDef) f);
      else if (f instanceof FillerFieldDef)
         checkFillerFieldDef ((FillerFieldDef) f);
      else if (f instanceof DelimitedFieldDef)
         checkDelimitedFieldDef ((DelimitedFieldDef) f);
   }


   private void checkRecordDef (RecordDef recordDef)
   throws Exception
   {
      checkFieldList (recordDef, recordDef.fields);
      if (recordDef.when != null)
         checkWhenAttribute (recordDef);
   }


   private void checkWhenAttribute (RecordDef recordDef)
   throws Exception
   {
      String [] tokens = recordDef.when.split ("=");

      if (tokens.length > 1)
      {
         recordDef.whenVariable = tokens [0];
         int vLength = tokens [0].length ();
         recordDef.whenValue = recordDef.when.substring (vLength + 1);
      }
      else
      {
         error (recordDef.locator,
            "The when selector '" + recordDef.when + "' does not conform to " +
            "the following syntax: field-name=value.");
      }
   }


   private void checkVariantRecordDef (VariantRecordDef v)
   throws Exception
   {
      checkFieldList (v, v.commonFields);
      checkFieldList (v, v.variants);
   }


   private void checkSimpleFieldDef (SimpleFieldDef f)
   throws Exception
   {
      if (f.value != null)
         f.defaultValue = f.value;

      if (f.length != null)
      {
         f.fieldLength = toInt (f.locator, f.length,
            "The value of the length attribute must be an integer.");
      }
      else if (f.format != null)
      {
         checkFieldFormatDef (f);
      }
      else
      {
         error (f.locator,
            "Either a field length or a format must be specified.");
      }
      if (f.align != null)
      {
         if (f.align.equalsIgnoreCase ("left"))
            f.fieldAlignment = "left";
         else if (f.align.equalsIgnoreCase ("right"))
            f.fieldAlignment = "right";
         else if (f.align.equalsIgnoreCase ("default"))
            f.fieldAlignment = f.fieldAlignment;
         else
         {
            error (f.locator,
               "The value of the attribute 'align' must be either " +
               "'left', 'right', or 'default'.");
         }
      }
      if (f.pad != null && f.pad.length () > 0)
      {
         f.padChar = f.pad.charAt (0);
      }
      if (f.trim != null)
      {
         if (f.trim.equalsIgnoreCase ("true"))
            f.fieldTrim = true;
         else if (f.trim.equalsIgnoreCase ("false"))
            f.fieldTrim = false;
         else
         {
            error (f.locator,
               "The value of the attribute 'trim' must be either " +
               "'true' or 'false'.");
         }
      }
      if (f.converter != null)
      {
         if (f.flatType == null)
         {
            error (f.locator,
               "The logical type of the field in the flat file" +
               " must be specified (flat-type) in order to use a converter.");
         }
         if (f.xmlType == null)
         {
            error (f.locator,
               "The logical type of the field in the XML file" +
               " must be specified (xml-type) in order to use a converter.");
         }
      }
   }


   private void checkFieldFormatDef (SimpleFieldDef f)
   throws Exception
   {
      boolean valid = true;
      String formatCode = null;
      String length = null;
      boolean binary = false;
      boolean packedDecimal = false;
      int scale = 0;
      FtlStringTokenizer t = new FtlStringTokenizer (f.format, "()V");
      t.ignoreWhiteSpace ();

      formatCode = t.text.toString ();
      t.getToken ();

      valid = t.text.toString ().equals ("(");
      if (valid)
      {
         t.getToken ();
         length = t.text.toString ();
         t.getToken ();
         valid = t.text.toString ().equals (")");
         t.getToken ();
      }
      if (valid)
      {
         if (t.text.toString ().equalsIgnoreCase ("V"))
         {
            t.getToken();
            String scaleFactor = t.text.toString();
            valid = scaleFactor.matches("99*");
            scale = scaleFactor.length();
            f.scale = scale;
            t.getToken ();
         }
      }
      if (valid)
      {
         if (t.text.toString ().equalsIgnoreCase ("COMP-3"))
         {
            packedDecimal = true;
            t.getToken ();
         }
         else if (t.text.toString ().equalsIgnoreCase ("COMP"))
         {
            binary = true;
            t.getToken ();
         }
      }
      if (valid)
         valid = t.tokenType == t.EOS;

      if (valid)
      {
         if (formatCode.equalsIgnoreCase ("X"))
         {
            f.fieldAlignment = "left";
         }
         else if (formatCode.equalsIgnoreCase ("A"))
         {
            f.fieldAlignment = "left";
         }
         else if (formatCode.equals ("Z"))
         {
             f.fieldAlignment = "right";
             f.trimLeadingZeroes = true;
             f.binary = binary;
             f.packedDecimal = packedDecimal;
         }
         else if (formatCode.equals ("9"))
         {
            f.fieldAlignment = "right";
            f.padChar = '0';
            f.binary        = binary;
            f.packedDecimal = packedDecimal;
         }
         else if (formatCode.equalsIgnoreCase ("S9"))
         {
            f.fieldAlignment = "right";
            f.padChar = '0';
            f.binary        = binary;
            f.packedDecimal = packedDecimal;
            f.signed = true;
         }
         else
            valid = false;
      }
      if (!valid)
      {
         error (f.locator,
            "The format '" + f.format + "' does not conform to " +
            "the following syntax:\n" +
            "    format-code(length)[V99* ][COMP | COMP-3]\n" +
            "where format-code is either 'A', 'X', '9', or S9," +
            " and length is an integer.");
      }
      if (valid)
      {
         f.fieldLength = toInt (f.locator, length,
            "The field format '" + f.format + "' contains an invalid length.");
         f.fieldLength += scale;
      }
   }


   private void checkFillerFieldDef (FillerFieldDef f)
   throws Exception
   {
      if (f.value != null)
         f.defaultValue = f.value;

      f.fieldLength = toInt (f.locator, f.length,
            "The value of the length attribute must be an integer.");
   }


   private void checkDelimitedRecordDef (DelimitedRecordDef r)
   throws Exception
   {
      FieldDef parentRecord = r.parentRecord;
      
      if (parentRecord != null)
      {
         if (parentRecord instanceof DelimitedRecordDef)
         {
            DelimitedRecordDef pr = (DelimitedRecordDef) parentRecord;
            if (r.delimiter == null)
            {
               r.delimiter = pr.delimiter;
            }
            if (r.trim == null)
            {
               r.trim = pr.trim;
               r.fieldTrim = pr.fieldTrim;
            }
            if (r.writeWhenXmlMissing == null)
            { 
               r.writeWhenXmlMissing = pr.writeWhenXmlMissing;
               r.writeWhenXmlIsMissing = pr.writeWhenXmlIsMissing; 
            }
            if (r.escapingStyle == null)
            {
               r.escapingStyle = pr.escapingStyle;
            }
         }
      }
      else
      {
         if (r.delimiter == null)
         {
            r.delimiter = "";
         }
         if (r.trim != null)
         {
            if ("true".equalsIgnoreCase(r.trim))
               r.fieldTrim = true; 
            else if ("false".equalsIgnoreCase(r.trim))
               r.fieldTrim = false;
            else
            {
               error (r.locator,
                  "The value of the attribute 'trim' must be either " +
                  "'true' or 'false'.");            
            }            
         }
         if (r.writeWhenXmlMissing != null)
         {
            if ("true".equalsIgnoreCase(r.writeWhenXmlMissing))
               r.writeWhenXmlIsMissing = true; 
            else if ("false".equalsIgnoreCase(r.writeWhenXmlMissing))
               r.writeWhenXmlIsMissing = false;
            else
            {
               error (r.locator,
                  "The value of the attribute 'writeWhenXmlMissing' must be either " +
                  "'true' or 'false'.");            
            }
         }
      }
      checkFieldList (r, r.fields);
      if (r.when != null)
         checkWhenAttribute (r);
   }

   private void checkDelimitedFieldDef (DelimitedFieldDef f)
   throws Exception
   {
      if (f.value != null)
      {
         f.defaultValue = f.value;
      }
      
      FieldDef parentRecord = f.parentRecord;
      
      if (parentRecord != null)
      {
         if (parentRecord instanceof DelimitedRecordDef)
         {
            DelimitedRecordDef pr = (DelimitedRecordDef) parentRecord;
            if (f.delimiter == null)
            {
               f.delimiter = pr.delimiter;
            }
            if (f.trim == null)
            {
               f.trim = pr.trim;
               f.fieldTrim = pr.fieldTrim;
            }
            if (f.escapingStyle == null)
            {
               f.escapingStyle = pr.escapingStyle;
            }
         }
      }
      else
      {
         if (f.delimiter == null)
         {
            f.delimiter = "";
         }
         if (f.trim != null)
         {
            if ("true".equalsIgnoreCase(f.trim))
               f.fieldTrim = true; 
            else if ("false".equalsIgnoreCase(f.trim))
               f.fieldTrim = false;
            else
            {
               error (f.locator,
                  "The value of the attribute 'trim' must be either " +
                  "'true' or 'false'.");            
            }            
         }
      }
   }
   
   private void resolveRepetitionCount (FieldDef f)
   throws Exception
   {
      if (f.repeat == null)
         f.repeatCount = 1;
      else if (f.repeat.equals ("*"))
         f.repeatCount = 2000000000;
      else
      { 
         FieldDef repeatField = findPrevField (f.repeat, f);

         if (repeatField != null)
         {
            f.repeatField = repeatField;
         }
         else
         {
            f.repeatCount = toInt (f.locator, f.repeat, 1,
               "The value of the repeat attribute must be an integer, " +
               "the name of previous field, or a '*'.");
         }
      }
   }


   /**
    * Finds a field with a given name that was declared before a
    * specified field.
    *
    * First all fields prior to the specified field in the same record
    * are searched. If the target field is not found in this search,
    * then the search is continued in the specified fields enclosing parent
    * record, where each field declared before the parent record is
    * searched for the target. This search continues until either the target
    * field is found or the top of the record structure is reached.
    */
   private FieldDef findPrevField (String name, FieldDef f)
   throws Exception
   {
      FieldDef ps = f.prevSibling;
      while (ps != null)
      {
         if (name.equals (ps.name)) return ps;
         ps = ps.prevSibling;
      }
      if (f.parentRecord != null)
         return findPrevField (name, f.parentRecord);

      return null;
   }


   private int toInt (Locator loc,
                      String value,
                      int defaultValue,
                      String errorMsg)
   throws Exception
   {
      if (value == null)
         return defaultValue;
      else
        return toInt (loc, value, errorMsg);
   }


   private int toInt (Locator loc, String value, String errorMsg)
   throws Exception
   {
      int ivalue = 0;
      try
      {
         ivalue = Integer.parseInt (value);
      }
      catch (Exception e)
      {
         error (loc, errorMsg);
      }
      return ivalue;
   }


   /**
    * Records an error message.
    */
   private void error (Locator loc, String msg)
   {
      if (loc != null)
         System.err.println ("Line: " + loc.getLineNumber () +
            " Error: " + msg);
      else
         System.err.println ("Error: " + msg);

      numErrors += 1;
   }
}
