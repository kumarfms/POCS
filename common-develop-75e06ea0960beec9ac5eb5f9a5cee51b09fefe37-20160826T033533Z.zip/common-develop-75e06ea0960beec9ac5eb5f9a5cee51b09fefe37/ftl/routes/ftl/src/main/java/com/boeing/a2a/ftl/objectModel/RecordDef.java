package com.boeing.a2a.ftl.objectModel;

import java.util.*;
import java.io.*;

import xgen.util.xml.XMLDocument;


/**
 * This class provides a Java representation of
 * the XML element <code>record</code>.
 */
public class RecordDef extends FieldDef
implements Serializable
{
   /** supply serialVersionUID for interoperability with older versions*/
   private static final long serialVersionUID = 0000000000000000003L;

   /**
   * The value of the attribute <code>when</code>.
   */
   public String  when;
   public String  ov_when;
   /**
   * A list of <code>FieldDefs</code>, which correspond
   * to the XML elements <code>field-def</code>.
   */
   public List  fields = new LinkedList ();
   /**
    * Indicates whether this field should be output when transforming from
    * flat to xml.  Default value is false.
    */
   public String  omitXmlTag = "false";
   public String  ov_omitXmlTag;


   public Object copy ()
   {
      RecordDef result = new RecordDef ();
      copyFields (this, result);
      return result;
   }


   protected void copyFields (RecordDef src, RecordDef dest)
   {
      super.copyFields (src, dest);
      dest.when = src.when;
      dest.ov_when = src.ov_when;
      dest.fields = src.fields;
      dest.omitXmlTag = src.omitXmlTag;
      dest.ov_omitXmlTag = src.ov_omitXmlTag;
   }


   /**
    * Returns an XML Document representation of this instance of the
    * class <code>RecordDef</code>.

    * @param original Specifies whether the original
    * or the resolved document should be represented.
    */
   public XMLDocument toXMLDocument (boolean original)
   throws IOException
   {
      XMLDocument result = new XMLDocument ("record");
      RecordDef instance = null;
      if (original)
      {
         if (this.original == null) return null;
         instance = (RecordDef) this.original;
      }
      else
      {
         instance = this;
      }
      addAttributes (result, instance, original);
      addElements (result, instance, original);
      return result;
   }


   /**
    * Adds attributes to the XMLDocument.
    *
    * @param doc Specifies which document to 
    * add the values to.
    * @param instance Specifies which instance to 
    * obtain the attribute values from.
    * @param original Specifies whether the original
    * or the resolved attributes should be represented.
    */
   protected void addAttributes (XMLDocument doc,
                                 RecordDef instance,
                                 boolean original)
   throws IOException
   {
      super.addAttributes (doc, instance, original);

      if (original)
      {
         doc.addAttribute ("when", instance.ov_when);
         doc.addAttribute ("omit-xml-tag", instance.ov_omitXmlTag);
      }
      else
      {
         doc.addAttribute ("when", instance.when);
         doc.addAttribute ("omit-xml-tag", instance.omitXmlTag);
      }
   }


   /**
    * Adds elements to the XMLDocument.
    *
    * @param doc Specifies which document to 
    * add the values to.
    * @param instance Specifies which instance to 
    * obtain the elements from.
    * @param original Specifies whether the original
    * or the resolved elements should be represented.
    */
   protected void addElements (XMLDocument doc,
                               RecordDef instance,
                               boolean original)
   throws IOException
   {
      XMLDocument temp = null;

      super.addElements (doc, instance, original);


      for (Iterator i = instance.fields.iterator (); i.hasNext ();)
      {
         FieldDef item = (FieldDef) i.next ();
         doc.addChild (item.toXMLDocument (original));
      }
   }


   public String whenVariable;
   public String whenValue;

   public boolean omitXmlTag ()
   {
      if ("true".equals(omitXmlTag))
         return true;
      else
         return false;
   }



}
