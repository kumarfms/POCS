package com.boeing.a2a.util.xml;

import java.io.InputStream;
import java.io.OutputStream;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.apache.xerces.util.XMLChar;
import org.w3c.dom.*;
import com.boeing.a2a.util.*;

/**
 * Library of various utility methods useful for handling XML.
 */

public class XMLUtils
{
   /**
    * Escape characters that have special meaning to
    * HTML and XML.
    */
   public static String xmlEscape (String s)
   {
      if (s == null)
         return null;
      
      int length          = s.length ();
      StringBuffer retval = new StringBuffer (length + 100);
      
      // (the default StringBuffer is very short;
      //  we don't have to get this exactly right, because
      //  it will expand if necessary)
      
      for (int i = 0; i < length; i++)
      {
         char c = s.charAt (i);
         switch (c)
         {
            case '<':
               retval.append ("&lt;");
               break;
            case '>':
               retval.append ("&gt;");
               break;
            case '&':
               retval.append ("&amp;");
               break;
            case '\"':
               retval.append ("&quot;");
               break;
            case '\'':
               retval.append ("&#39;");
               break;
            default:
               if (XMLChar.isValid (c))
               {
                  retval.append (c);
               }
               break;
         }
      }
      return retval.toString ();
   }


   /**
    * Test whether a given node is an element node.
    */
   public static boolean isElement (Node node)
   {
      if (node == null)
         return false;

      return node instanceof Element;
   }


   /**
    * Test whether a given node is an element node with the specified name.
    */
   public static boolean isElement (Node node, String name)
   {
      if (node == null)
         return false;

      if (!(node instanceof Element))
         return false;

      return name.equals (node.getLocalName ());
   }


   /**
    * Returns the character data associated with a specified element node.
    */
   public static String getContents (Node node)
   {
      String result = null;
      node.normalize ();
      Node child = node.getFirstChild ();
      while (child != null)
      {
         if (child instanceof CharacterData)
         {
            if (result == null)
               result = ((CharacterData) child).getData ();
            else
               result += ((CharacterData) child).getData ();
         }
         else if (child instanceof EntityReference)
            result += getContents (child);

         child = child.getNextSibling ();
      }
      return result;
   }


   /**
    * Returns trimmed character data associated with a specified element node.
    * Unlike getContents, if there is no character data associated with the
    * node it returns the null string instead of the value <code>null</code>.
    */
   public static String getTrimmedContents (Node node)
   {
      String result = getContents (node);

      if (result == null)
         result = "";
      else
         result = result.trim ();

      return result;
   }




   public static Node getFirstChildElement (Node node)
   {
      Node child = node.getFirstChild();
      if (!isElement (child))
      {
         return getNextSiblingElement (child);
      }
      return child;
   }


   public static Node getNextSiblingElement (Node node)
   {
      Node sibling = node.getNextSibling();

      while (!isElement (sibling) && sibling != null)
      {
         sibling = sibling.getNextSibling ();
      }
      return sibling;
   }



  // simplified helper method -- may not be final version!
  public static boolean getBooleanContents(Node node) {
    String contentsStr = getContents(node);
    return getBooleanFromString(contentsStr);
  }

  protected static boolean getBooleanFromString(String contentsStr) {
    if (contentsStr != null && (contentsStr.equals("true") || contentsStr.equals("yes") ||
        contentsStr.equals("1")))
          return true;

    return false;
  }

  public static String getAttribute(String attribute, NamedNodeMap atts) {
    Node attNode = atts.getNamedItem(attribute);
    if (attNode == null)
      return null;
    return (attNode.getNodeValue());
  }

  public static String extractElementContents (String xmlMessage, String element)
   throws Exception
   {
      String startTag = "<"  + element + ">";
      String   endTag = "</" + element + ">" ;
      int startPos = xmlMessage.indexOf(startTag);
      startPos += startTag.length();
      int endPos = xmlMessage.indexOf (endTag);
      String elementContents = xmlMessage.substring (startPos, endPos);
      return elementContents;
   }
   
   public static String replaceElementContents(String xmlMessage, 
                                               String element, 
                                               String newValue)
   throws Exception 
   {
      String startTag = "<"  + element + ">";
      String   endTag = "</" + element + ">" ;
      String oldValue = extractElementContents (xmlMessage, element);
      String toBeReplaced = startTag + oldValue + endTag;
      String replacement = startTag + newValue + endTag;
      return xmlMessage.replaceAll (toBeReplaced, replacement);
   }

   public static String changeToValidOracleInsertString(String theString)
   throws Exception 
   {
      return com.boeing.a2a.util.StringUtil.replace(theString,"'","''");
   }
   
   public static Document xmlToDocument (InputStream xmlInputStream)
   throws Exception
   {
      DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
      dbf.setNamespaceAware (true);
      DocumentBuilder db = dbf.newDocumentBuilder();
      return db.parse (xmlInputStream);      
   }
   
   public static Node xmlToNode (InputStream xmlInputStream)
   throws Exception
   {
      Document doc = xmlToDocument (xmlInputStream);
      return (Node) doc.getDocumentElement ();    
   }
   
   public static void addNodeToDocument (Document parentDoc, Node parentDocNode, Node childNodeToAdd, boolean deepCopy)
   throws Exception
   {
      Node myChildNodeToAdd = parentDoc.importNode (childNodeToAdd, deepCopy);
      parentDocNode.appendChild (myChildNodeToAdd);
   }
   
   public static void nodeToXml (Node node, OutputStream out)
   throws Exception
   {
      TransformerFactory tf = TransformerFactory.newInstance();
      TransformerErrorListener errorListener = new TransformerErrorListener ();
      tf.setErrorListener (errorListener);
      Transformer t = tf.newTransformer();
      t.setErrorListener (errorListener);
      t.setOutputProperty(OutputKeys.METHOD, "xml");
      t.setOutputProperty(OutputKeys.INDENT, "yes");
      t.transform (new DOMSource(node), new StreamResult(out));
   }
}
