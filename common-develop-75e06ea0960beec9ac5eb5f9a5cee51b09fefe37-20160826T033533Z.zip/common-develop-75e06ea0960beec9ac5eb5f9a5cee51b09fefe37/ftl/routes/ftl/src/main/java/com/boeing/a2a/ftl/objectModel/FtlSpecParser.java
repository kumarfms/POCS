package com.boeing.a2a.ftl.objectModel;

import java.io.*;
import java.util.*;
import javax.xml.parsers.*;
import org.xml.sax.*;
import org.xml.sax.helpers.*;
import org.w3c.dom.*;
import com.boeing.a2a.util.xml.XMLUtils;

import xgen.util.xml.TextFieldResolver;


/**
 * This class parses an XML document and creates
 * a Java object structure that represents the contents
 * of the XML document.
 * <p>
 * The parse methods return the top level object
 * which represents the entire document.
 */
public class FtlSpecParser extends DefaultHandler
{

   /**
    * Creates a new parser.
    */
   public FtlSpecParser ()
   {
   }


   private List    elementContents = new Vector (2);
   private Stack   stack = new Stack ();
   private Locator locator;
   private int     numErrors = 0;
   private List    errors = new LinkedList ();
   private boolean validating = false;

   private Iterator contentIterator;
   private String   elementTag;
   private Object   elementNode;
   private TextFieldResolver resolver = new TextFieldResolver ();


   /**
    * Sets the text field resolver to use to compute
    * the final values of text fields. The default text
    * field resolver returns the input documents original
    * text for attributes and elements holding primitive
    * types (e.g., strings, integers, and doubles).
    * Another text field resolver may be supplied, which
    * performs substition for substrings found in a text
    * field. The substituted values are then put into the
    * bound Java classes.
    * @param resolver The resolver to user.
    */
   public void setTextFieldResolver (TextFieldResolver resolver)
   {
      this.resolver = resolver;
   }


   /**
    * Parses an XML document located in a file.
    * <p>
    * If the parse fails because the XML document
    * is not valid,
    * then the value <code>null</code> is
    * returned.
    * If the document is valid, but it does not contain
    * constructs that can be bound to the
    * classes in this package, then
    * then the value <code>null</code> is
    * returned.
    * @param fileName The name of the file.
    * @param validating Indicates whether to use
    *        a validating parser.
    * @return An object representing the XML document,
    * if successful; otherwise <code>null</code>.
    */
   public Object parse (String  fileName,
                        boolean validating)
   throws Exception
   {
      SAXParserFactory factory = SAXParserFactory.newInstance ();
      factory.setNamespaceAware (true);
      this.validating = validating;
      factory.setValidating (validating);
      SAXParser parser;
      parser = factory.newSAXParser();
      parser.parse (fileName, this);
      return getDocument ();
   }


   /**
    * Parses an XML document located in an input stream.
    * <p>
    * If the parse fails because the XML document
    * is not valid,
    * then the value <code>null</code> is
    * returned.
    * If the document is valid, but it does not contain
    * constructs that can be bound to the
    * classes in this package, then
    * then the value <code>null</code> is
    * returned.
    * @param is The input stream.
    * @param validating Indicates whether to use
    *        a validating parser.
    * @return An object representing the XML document,
    * if successful; otherwise <code>null</code>.
    */
   public Object parse (InputStream  is,
                        boolean validating)
   throws Exception
   {
      SAXParserFactory factory = SAXParserFactory.newInstance ();
      factory.setNamespaceAware (true);
      this.validating = validating;
      factory.setValidating (validating);
      SAXParser parser;
      parser = factory.newSAXParser();
      parser.parse (is, this);
      return getDocument ();
   }


   /**
    * Parses an XML document located in an input source.
    * <p>
    * If the parse fails because the XML document
    * is not valid,
    * then the value <code>null</code> is
    * returned.
    * If the document is valid, but it does not contain
    * constructs that can be bound to the
    * classes in this package, then
    * then the value <code>null</code> is
    * returned.
    * @param is The input source.
    * @param validating Indicates whether to use
    *        a validating parser.
    * @return An object representing the XML document,
    * if successful; otherwise <code>null</code>.
    */
   public Object parse (InputSource  is,
                        boolean validating)
   throws Exception
   {
      SAXParserFactory factory = SAXParserFactory.newInstance ();
      factory.setNamespaceAware (true);
      this.validating = validating;
      factory.setValidating (validating);
      SAXParser parser;
      parser = factory.newSAXParser();
      parser.parse (is, this);
      return getDocument ();
   }


   /**
    * Returns the number of error found while
    * parsing the XML docuement.
    * @return The number of error found.
    */
   public int getNumErrors ()
   {
      return numErrors;
   }


   /**
    * Returns a string description of each error found
    * while parsing of the XML docuement.
    * @return A list of <code>String</code>s.
    */
   public List getErrors ()
   {
      return errors;
   }


   /**
    * Returns an object which is Java representation
    * of the parsed XML document.
    * <p>
    * If the parse fails because the XML document
    * is not valid,
    * then the value <code>null</code> is
    * returned.
    * If the document is valid, but it does not contain
    * constructs that can be bound to the
    * classes in this package, then
    * then the value <code>null</code> is
    * returned.
    * @return An object representing the XML document,
    * if successful; otherwise <code>null</code>.
    */
   public Object getDocument ()
   {
      return elementContents.get (1);
   }


   private void getNextElement ()
   {
      if (contentIterator.hasNext ())
      {
         elementTag  = (String) contentIterator.next ();
         elementNode = contentIterator.next ();
      }
      else
      {
         elementTag = null;
      }
   }


   private String getAttribute (Attributes atts, String qName)
   {
      return atts.getValue (qName);
   }


   private Integer getIntegerAttribute (Attributes atts, String qName)
   {
      String text = atts.getValue (qName);
      Integer value = null;
      if (text != null)
      {
         try
         {
            value = Integer.valueOf (text);
         }
         catch (NumberFormatException e)
         {
            int line = locator.getLineNumber ();
            String message =
              "The value of the attribute \"" + qName
              + "\" must be a valid integer";
            writeError (line, "Error", message);
         }
      }
      return value;
   }


   private Long getLongAttribute (Attributes atts, String qName)
   {
      String text = atts.getValue (qName);
      Long value = null;
      if (text != null)
      {
         try
         {
            value = Long.valueOf (text);
         }
         catch (NumberFormatException e)
         {
            int line = locator.getLineNumber ();
            String message =
              "The value of the attribute \"" + qName
              + "\" must be a valid long integer";
            writeError (line, "Error", message);
         }
      }
      return value;
   }


   private Double getDoubleAttribute (Attributes atts, String qName)
   {
      String text = atts.getValue (qName);
      Double value = null;
      if (text != null)
      {
         try
         {
            value = Double.valueOf (text);
         }
         catch (NumberFormatException e)
         {
            int line = locator.getLineNumber ();
            String message =
              "The value of the attribute \"" + qName
              + "\" must be a valid floating point number";
            writeError (line, "Error", message);
         }
      }
      return value;
   }


   public void setDocumentLocator(Locator locator)
   {
      this.locator = locator;
   }


   public InputSource resolveEntity (String publicId,
                                     String systemId )
   throws SAXException
   {
      String dtdName = "ftl.dtd";
      InputStream dtd = null;

      if (!validating && systemId.endsWith (".dtd"))
      {
         byte[] emptyArray = new byte [0];
         dtd = new ByteArrayInputStream (emptyArray);
         return new InputSource (dtd);
      }
      if (!systemId.endsWith (".dtd"))
      {
         return null;
      }
      ClassLoader cl = this.getClass ().getClassLoader ();
      dtd = cl.getResourceAsStream (dtdName);
      if (dtd == null)
      {
         throw new SAXException ("Unable to load DTD");
      }
      return new InputSource (dtd);
   }


   public void writeError (int line, String type, String message)
   {
      String msg = "Line: " + line + " " + type + ": " + message;
      errors.add (msg);
      numErrors += 1;
   }


   public void warning (SAXParseException exception)
   throws SAXException
   {
      int line = exception.getLineNumber ();
      writeError (line, "Warning", exception.getMessage ());
   }


   public void error (SAXParseException exception)
   throws SAXException
   {
      int line = exception.getLineNumber ();
      writeError (line, "Error", exception.getMessage ());
   }


   public void fatalError (SAXParseException exception)
   throws SAXException
   {
      int line = exception.getLineNumber ();
      writeError (line, "Fatal error", exception.getMessage ());
   }


   public void startElement(
         java.lang.String namespaceURI,
         java.lang.String localName,
         java.lang.String qName,
         Attributes atts)
   throws SAXException
   {
      stack.push (elementContents);
      elementContents = new LinkedList ();
      stack.push (new AttributesImpl (atts));
      stack.push (new LocatorImpl (locator));
   }


   public void endElement(
         java.lang.String namespaceURI,
         java.lang.String localName,
         java.lang.String qName)
   throws SAXException
   {
      Locator    loc  = (Locator) stack.pop ();
      Attributes atts = (Attributes) stack.pop ();
      Object     node;

      node = constructNode (localName, atts, elementContents, loc);
      elementContents = (List) stack.pop ();
      elementContents.add (localName);
      elementContents.add (node);
   }


   public void characters(
         char[] ch,
         int start,
         int length)
   throws SAXException
   {
      Object node = new String (ch, start, length);
      elementContents.add ("#CDATA");
      elementContents.add (node);
   }


   private Object getSubnode (Object node, Class c)
   {
      if (!(node instanceof List)) return null;

      Iterator i = ((List) node).iterator ();
      while (i.hasNext ())
      {
         String elementTag = (String) i.next ();
         Object subnode = i.next ();
         if (c.isInstance (subnode))
            return subnode;
      }
      return null;
   }


   private void appendToList (List l, Object elementNode, String tag)
   {
      Iterator i = ((List) elementNode).iterator ();
      while (i.hasNext ())
      {
         String elementTag = (String) i.next ();
         Object node       = i.next ();
         if (tag.equals (elementTag))
            l.add (node);
      }
   }


   private void appendToList (List l, Object elementNode, Class c)
   {
      Iterator i = ((List) elementNode).iterator ();
      while (i.hasNext ())
      {
         String elementTag = (String) i.next ();
         Object node       = i.next ();
         if (c.isInstance (node))
            l.add (node);
      }
   }


   private String getText (List content)
   {
      StringBuffer result = new StringBuffer ();

      Iterator i = content.iterator ();
      while (i.hasNext ())
      {
         String elementTag = (String) i.next ();
         Object node       = i.next ();
         if (node instanceof String)
            result.append ((String) node);
      }
      return result.toString ();
   }


   private Integer getInteger (List content)
   {
      String text = getText (content);
      return getInteger (text);
   }


   private Integer getInteger (String text)
   {
      if (text == null) return null;

      try
      {
         return Integer.valueOf (text);
      }
      catch (NumberFormatException e)
      {
         int line = locator.getLineNumber ();
         String message = "The value \"" + text +"\" is not a valid integer";
         writeError (line, "Error", message);
      }
      return null;
   }


   private Long getLong (List content)
   {
      String text = getText (content);
      return getLong (text);
   }


   private Long getLong (String text)
   {
      if (text == null) return null;

      try
      {
         return Long.valueOf (text);
      }
      catch (NumberFormatException e)
      {
         int line = locator.getLineNumber ();
         String message = "The value \"" + text +"\" is not a valid long integer";
         writeError (line, "Error", message);
      }
      return null;
   }


   private Double getDouble (List content)
   {
      String text = getText (content);
      return getDouble (text);
   }


   private Double getDouble (String text)
   {
      if (text == null) return null;

      try
      {
         return Double.valueOf (text);
      }
      catch (NumberFormatException e)
      {
         int line = locator.getLineNumber ();
         String message = "The value \"" + text +"\" is not a valid floating point number";
         writeError (line, "Error", message);
      }
      return null;
   }


   private Object constructNode (
           String     tag,
           Attributes atts,
           List       content,
           Locator    locator )
   {
      if ("ftl".equals (tag))
         return constructFtlSpecNode (atts, content, locator);

      else if ("variant".equals (tag))
         return constructVariantRecordDefNode (atts, content, locator);

      else if ("record".equals (tag))
         return constructRecordDefNode (atts, content, locator);

      else if ("delimited-field".equals (tag))
         return constructDelimitedFieldDefNode (atts, content, locator);

      else if ("delimited-record".equals (tag))
         return constructDelimitedRecordDefNode (atts, content, locator);

      else if ("field".equals (tag))
         return constructSimpleFieldDefNode (atts, content, locator);

      else if ("filler".equals (tag))
         return constructFillerFieldDefNode (atts, content, locator);

      else if ("eol".equals (tag))
         return constructEndOfLineFieldDefNode (atts, content, locator);

      else if ("datetime".equals (tag))
         return constructDateTimeFieldDefNode (atts, content, locator);

      return content;
   }


   private FtlSpec constructFtlSpecNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      FtlSpec  result = new FtlSpec ();

      result.locator = locator;
      result.ov_name = getAttribute (atts, "name");
      result.name = resolver.resolve (result.ov_name);
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         while ("variant".equals (elementTag)
          || "record".equals (elementTag)
          || "delimited-field".equals (elementTag)
          || "delimited-record".equals (elementTag)
          || "field".equals (elementTag)
          || "filler".equals (elementTag)
          || "eol".equals (elementTag)
          || "datetime".equals (elementTag))
         {
            result.fields.add (elementNode);
            getNextElement ();
         }
         if (elementTag != null)
            getNextElement ();
      }
      result.original = (FtlSpec) result.copy ();
      return result;
   }


   private VariantRecordDef constructVariantRecordDefNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      VariantRecordDef  result = new VariantRecordDef ();

      result.locator = locator;
      result.ov_name = getAttribute (atts, "name");
      result.name = resolver.resolve (result.ov_name);
      result.ov_repeat = getAttribute (atts, "repeat");
      result.repeat = resolver.resolve (result.ov_repeat);
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         if ("common-fields".equals (elementTag))
         {
            appendToList (result.commonFields, elementNode, FieldDef.class);
            getNextElement ();
         }
         while ("record".equals (elementTag)
          || "delimited-record".equals (elementTag))
         {
            result.variants.add (elementNode);
            getNextElement ();
         }
         if (elementTag != null)
            getNextElement ();
      }
      result.original = (VariantRecordDef) result.copy ();
      return result;
   }


   private RecordDef constructRecordDefNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      RecordDef  result = new RecordDef ();

      result.locator = locator;
      result.ov_name = getAttribute (atts, "name");
      result.name = resolver.resolve (result.ov_name);
      result.ov_repeat = getAttribute (atts, "repeat");
      result.repeat = resolver.resolve (result.ov_repeat);
      result.ov_when = getAttribute (atts, "when");
      result.when = resolver.resolve (result.ov_when);
      result.ov_omitXmlTag = getAttribute (atts, "omit-xml-tag");
      result.omitXmlTag = resolver.resolve (result.ov_omitXmlTag);
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         while ("variant".equals (elementTag)
          || "record".equals (elementTag)
          || "delimited-field".equals (elementTag)
          || "delimited-record".equals (elementTag)
          || "field".equals (elementTag)
          || "filler".equals (elementTag)
          || "eol".equals (elementTag)
          || "datetime".equals (elementTag))
         {
            result.fields.add (elementNode);
            getNextElement ();
         }
         if (elementTag != null)
            getNextElement ();
      }
      result.original = (RecordDef) result.copy ();
      return result;
   }


   private DelimitedFieldDef constructDelimitedFieldDefNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      DelimitedFieldDef  result = new DelimitedFieldDef ();

      result.locator = locator;
      result.ov_name = getAttribute (atts, "name");
      result.name = resolver.resolve (result.ov_name);
      result.ov_repeat = getAttribute (atts, "repeat");
      result.repeat = resolver.resolve (result.ov_repeat);
      result.ov_description = getAttribute (atts, "description");
      result.description = resolver.resolve (result.ov_description);
      result.ov_delimiter = getAttribute (atts, "delimiter");
      result.delimiter = resolver.resolve (result.ov_delimiter);
      result.ov_value = getAttribute (atts, "value");
      result.value = resolver.resolve (result.ov_value);
      result.ov_omitXmlTag = getAttribute (atts, "omit-xml-tag");
      result.omitXmlTag = resolver.resolve (result.ov_omitXmlTag);
      result.ov_trim = getAttribute (atts, "trim");
      result.trim = resolver.resolve (result.ov_trim);
      result.ov_escapingStyle = getAttribute (atts, "escaping-style");
      result.escapingStyle = resolver.resolve (result.ov_escapingStyle);
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         if (elementTag != null)
            getNextElement ();
      }
      result.original = (DelimitedFieldDef) result.copy ();
      return result;
   }


   private DelimitedRecordDef constructDelimitedRecordDefNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      DelimitedRecordDef  result = new DelimitedRecordDef ();

      result.locator = locator;
      result.ov_name = getAttribute (atts, "name");
      result.name = resolver.resolve (result.ov_name);
      result.ov_repeat = getAttribute (atts, "repeat");
      result.repeat = resolver.resolve (result.ov_repeat);
      result.ov_when = getAttribute (atts, "when");
      result.when = resolver.resolve (result.ov_when);
      result.ov_omitXmlTag = getAttribute (atts, "omit-xml-tag");
      result.omitXmlTag = resolver.resolve (result.ov_omitXmlTag);
      result.ov_delimiter = getAttribute (atts, "delimiter");
      result.delimiter = resolver.resolve (result.ov_delimiter);
      result.ov_escapingStyle = getAttribute (atts, "escaping-style");
      result.escapingStyle = resolver.resolve (result.ov_escapingStyle);
      result.ov_writeHeader = getAttribute (atts, "write-header");
      result.writeHeader = resolver.resolve (result.ov_writeHeader);
      result.ov_trim = getAttribute (atts, "trim");
      result.trim = resolver.resolve (result.ov_trim);
      result.ov_writeWhenXmlMissing = getAttribute (atts, "write-when-xml-missing");
      result.writeWhenXmlMissing = resolver.resolve (result.ov_writeWhenXmlMissing);
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         while ("variant".equals (elementTag)
          || "record".equals (elementTag)
          || "delimited-field".equals (elementTag)
          || "delimited-record".equals (elementTag)
          || "field".equals (elementTag)
          || "filler".equals (elementTag)
          || "eol".equals (elementTag)
          || "datetime".equals (elementTag))
         {
            result.fields.add (elementNode);
            getNextElement ();
         }
         if (elementTag != null)
            getNextElement ();
      }
      result.original = (DelimitedRecordDef) result.copy ();
      return result;
   }


   private SimpleFieldDef constructSimpleFieldDefNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      SimpleFieldDef  result = new SimpleFieldDef ();

      result.locator = locator;
      result.ov_name = getAttribute (atts, "name");
      result.name = resolver.resolve (result.ov_name);
      result.ov_repeat = getAttribute (atts, "repeat");
      result.repeat = resolver.resolve (result.ov_repeat);
      result.ov_length = getAttribute (atts, "length");
      result.length = resolver.resolve (result.ov_length);
      result.ov_format = getAttribute (atts, "format");
      result.format = resolver.resolve (result.ov_format);
      result.ov_align = getAttribute (atts, "align");
      result.align = resolver.resolve (result.ov_align);
      result.ov_pad = getAttribute (atts, "pad");
      result.pad = resolver.resolve (result.ov_pad);
      result.ov_trim = getAttribute (atts, "trim");
      result.trim = resolver.resolve (result.ov_trim);
      result.ov_converter = getAttribute (atts, "converter");
      result.converter = resolver.resolve (result.ov_converter);
      result.ov_flatType = getAttribute (atts, "flat-type");
      result.flatType = resolver.resolve (result.ov_flatType);
      result.ov_xmlType = getAttribute (atts, "xml-type");
      result.xmlType = resolver.resolve (result.ov_xmlType);
      result.ov_value = getAttribute (atts, "value");
      result.value = resolver.resolve (result.ov_value);
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         if (elementTag != null)
            getNextElement ();
      }
      result.original = (SimpleFieldDef) result.copy ();
      return result;
   }


   private FillerFieldDef constructFillerFieldDefNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      FillerFieldDef  result = new FillerFieldDef ();

      result.locator = locator;
      result.ov_name = getAttribute (atts, "name");
      result.name = resolver.resolve (result.ov_name);
      result.ov_repeat = getAttribute (atts, "repeat");
      result.repeat = resolver.resolve (result.ov_repeat);
      result.ov_length = getAttribute (atts, "length");
      result.length = resolver.resolve (result.ov_length);
      result.ov_value = getAttribute (atts, "value");
      result.value = resolver.resolve (result.ov_value);
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         if (elementTag != null)
            getNextElement ();
      }
      result.original = (FillerFieldDef) result.copy ();
      return result;
   }


   private EndOfLineFieldDef constructEndOfLineFieldDefNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      EndOfLineFieldDef  result = new EndOfLineFieldDef ();

      result.locator = locator;
      result.ov_name = getAttribute (atts, "name");
      result.name = resolver.resolve (result.ov_name);
      result.ov_repeat = getAttribute (atts, "repeat");
      result.repeat = resolver.resolve (result.ov_repeat);
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         if (elementTag != null)
            getNextElement ();
      }
      result.original = (EndOfLineFieldDef) result.copy ();
      return result;
   }


   private DateTimeFieldDef constructDateTimeFieldDefNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      DateTimeFieldDef  result = new DateTimeFieldDef ();

      result.locator = locator;
      result.ov_name = getAttribute (atts, "name");
      result.name = resolver.resolve (result.ov_name);
      result.ov_repeat = getAttribute (atts, "repeat");
      result.repeat = resolver.resolve (result.ov_repeat);
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         if (elementTag != null)
            getNextElement ();
      }
      result.original = (DateTimeFieldDef) result.copy ();
      return result;
   }
}
