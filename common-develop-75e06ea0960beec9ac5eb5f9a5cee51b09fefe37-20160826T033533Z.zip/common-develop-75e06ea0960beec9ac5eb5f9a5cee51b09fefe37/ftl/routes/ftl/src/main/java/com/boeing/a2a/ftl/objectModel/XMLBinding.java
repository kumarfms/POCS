package com.boeing.a2a.ftl.objectModel;

import java.util.*;
import java.io.*;

public interface XMLBinding
{
   public List getAttributeNames ();
   public Object getAttribute (String name);
   public void writeXML (XMLWriter writer)
     throws IOException;
}
