package com.boeing.a2a.ftl;

import org.w3c.dom.*;
import org.xml.sax.*;
import javax.xml.parsers.*;

import java.util.*;
import java.io.*;

import com.boeing.a2a.util.DateUtil;
import com.boeing.a2a.ftl.objectModel.*;
import com.boeing.a2a.util.xml.XMLUtils;

/**
 * A FTL processor can translate a flat file to an XML document or an XML
 * document to a flat file, based on a FTL transformation specification.
 */
public class FtlProcessor {
	String ftlSpecName;
	FtlSpec spec;
	public int numErrors = 0;
	public int numWarnings = 0;

	private int margin = 0;
	private HashMap converterTable = new HashMap(31);
	private InputStream in = null;
	private OutputStream out = null;
	private Writer writer = null;

	public FtlProcessor(String ftlSpecName) {
		this.ftlSpecName = ftlSpecName;
	}

	public void writeDtd(OutputStream out) throws Exception {
		HashMap tagTable = new HashMap();
		this.out = out;

		if (spec == null)
			compileSpec();

		writeln(out, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
		writeElementDeclsForFieldList(spec.name, spec.fields, tagTable);
	}

	private void writeElementDeclsForFieldList(String elementName, List fields,
			HashMap tagTable) throws Exception {
		if (tagTable.get(elementName) != null)
			return;
		tagTable.put(elementName, "defined");

		write(out, "\n<!ELEMENT ");
		write(out, elementName);
		write(out, " (");
		int count = 0;
		for (Iterator i = fields.iterator(); i.hasNext();) {
			FieldDef f = (FieldDef) i.next();
			if (f instanceof RecordDef || f instanceof VariantRecordDef
					|| f instanceof SimpleFieldDef
					|| f instanceof DateTimeFieldDef) {
				count += 1;
				if (count > 1)
					write(out, ", ");

				if (f instanceof DateTimeFieldDef)
					write(out, "DATETIME");
				else if (f instanceof VariantRecordDef) {
					VariantRecordDef vdef = (VariantRecordDef) f;
					write(out, "(");
					for (Iterator j = vdef.variants.iterator(); j.hasNext();) {
						RecordDef vr = (RecordDef) j.next();
						write(out, vr.name);
						if (j.hasNext())
							write(out, " | ");
					}
					write(out, ")");
				} else
					write(out, f.name);

				if (f.repeatCount > 1)
					write(out, "*");
				else
					write(out, "?");
			}
		}
		write(out, ")");
		writeln(out, ">");

		for (Iterator i = fields.iterator(); i.hasNext();) {
			FieldDef f = (FieldDef) i.next();

			if (f instanceof RecordDef) {
				writeElementDeclsForFieldList(f.name, ((RecordDef) f).fields,
						tagTable);
			} else if (f instanceof VariantRecordDef) {
				VariantRecordDef vdef = (VariantRecordDef) f;

				for (Iterator j = vdef.variants.iterator(); j.hasNext();) {
					RecordDef vr = (RecordDef) j.next();
					List vfields = new LinkedList();
					vfields.addAll(vdef.commonFields);
					vfields.addAll(vr.fields);
					writeElementDeclsForFieldList(vr.name, vfields, tagTable);
				}
			} else if (f instanceof SimpleFieldDef) {
				if (tagTable.get(f.name) == null) {
					tagTable.put(f.name, "defined");
					write(out, "\n<!ELEMENT ");
					write(out, f.name);
					writeln(out, " (#PCDATA)>");
				}
			} else if (f instanceof DateTimeFieldDef) {
				if (tagTable.get("DATETIME") == null) {
					tagTable.put("DATETIME", "defined");
					writeln(out,
							"<!ELEMENT DATETIME (YEAR, MONTH,"
									+ " DAY, HOUR, MINUTE, SECOND, SUBSECOND, TIMEZONE)>");
					writeln(out, "<!ELEMENT YEAR (#PCDATA)>");
					writeln(out, "<!ELEMENT MONTH (#PCDATA)>");
					writeln(out, "<!ELEMENT DAY (#PCDATA)>");
					writeln(out, "<!ELEMENT HOUR (#PCDATA)>");
					writeln(out, "<!ELEMENT MINUTE (#PCDATA)>");
					writeln(out, "<!ELEMENT SECOND (#PCDATA)>");
					writeln(out, "<!ELEMENT SUBSECOND (#PCDATA)>");
					writeln(out, "<!ELEMENT TIMEZONE (#PCDATA)>");
				}
			}
		}
	}

	public void doFlatToXmlTransform(InputStream in, OutputStream out)
			throws Exception {
		doFlatToXmlTransform(in, out, null);
	}

	public void doFlatToXmlTransform(InputStream in, OutputStream out,
			String inputEncoding) throws Exception {
		if (spec == null)
			compileSpec();

		convertFlatFileToXml(in, out, inputEncoding);
	}

	public void doIMSToXmlTransform(InputStream in, OutputStream out)
			throws Exception {
		if (spec == null)
			compileSpec();

		// Read and discard the first 4 bytes from the input stream, this is the
		// IMS header.

		int b;
		b = in.read();
		b = in.read();
		b = in.read();
		b = in.read();

		convertFlatFileToXml(in, out, "Cp500");
	}

	public void doEBCDICToXmlTransform(InputStream in, OutputStream out)
			throws Exception {
		if (spec == null)
			compileSpec();

		// Set up to read the rest of the stream as characters translating
		// from EBCDIC (Cp500) to Unicode.
		Reader reader = new InputStreamReader(in, "Cp500");

		ByteArrayOutputStream imsData = new ByteArrayOutputStream();
		Writer writer = new OutputStreamWriter(imsData, "UTF-8");

		int ch = reader.read();
		while (ch != -1) {
			writer.write(ch);
			ch = reader.read();
		}
		writer.flush();

		// Get the EBCDIC bytes into an input stream.
		byte[] bytes = imsData.toByteArray();
		ByteArrayInputStream translatedIn = new ByteArrayInputStream(bytes);

		convertFlatFileToXml(translatedIn, out, null);
	}

	public void doXmlToFlatTransform(InputStream in, OutputStream out,
			boolean genImsFormat) throws Exception {
		if (spec == null)
			compileSpec();

		if (genImsFormat)
			convertXmlToFlatFile(in, out, "Cp500", true);
		else
			convertXmlToFlatFile(in, out, "UTF-8", false);
	}

	public void doXmlToFlatTransform(InputStream in, OutputStream out,
			String outputEncoding) throws Exception {
		if (spec == null)
			compileSpec();

		if (outputEncoding == null)
			outputEncoding = "UTF-8";

		convertXmlToFlatFile(in, out, outputEncoding, false);
	}

	public void compileSpec() throws Exception {
		FtlSpecParser parser = new FtlSpecParser();

		InputStream is = getClass().getClassLoader().getResourceAsStream(
				ftlSpecName);
		File f = new File(ftlSpecName);
		if (f.exists()) {
			is = new FileInputStream(f);
		}
		if (is == null) {
			throw new Exception("FTL specifictaion " + ftlSpecName
					+ " not found");
		}
		try {
			spec = (FtlSpec) parser.parse(is, true);
		} catch (Exception e) {
		}

		numErrors = parser.getNumErrors();
		List errors = parser.getErrors();
		for (Iterator i = errors.iterator(); i.hasNext();) {
			String message = (String) i.next();
			System.out.println(message);
		}

		if (numErrors == 0) {
			Semantics sem = new Semantics(spec);
			numErrors = sem.analyze();
		}

		if (numErrors != 0) {
			throw new Exception("Translation aborted: Invalid specification");
		}
	}

	private ByteArrayOutputStream fieldByteValue = new ByteArrayOutputStream();
	private StringBuffer fieldStringValue = new StringBuffer();
	private int nextByte;
	private String inputTextEncoding = null;

	public boolean eofReached() {
		return nextByte == -1;
	}

	private void getNextByte() throws Exception {
		if (nextByte != -1)
			nextByte = in.read();
	}

	private void getFieldStringValue(int length, boolean fixSpecialChars)
			throws Exception {
		fieldStringValue.setLength(0);
		if (inputTextEncoding == null) {
			for (int i = 0; i < length; i++) {
				if (nextByte == -1 || nextByte == '\n' || nextByte == '\r') {
					break;
				}
				fieldStringValue.append((char) nextByte);
				getNextByte();
			}
		} else {
			getFieldByteValue(length);
			byte[] byteValue = fieldByteValue.toByteArray();
			String s = new String(byteValue, inputTextEncoding);
			fieldStringValue.append(s);
		}
		if (fixSpecialChars)
			editSpecialChars();
	}

	private void editSpecialChars() {
		String s = fieldStringValue.toString();
		fieldStringValue.setLength(0);

		for (int i = 0; i < s.length(); i++) {
			char ch = s.charAt(i);
			if (ch == 0) {
				fieldStringValue.append(' ');
			} else {
				fieldStringValue.append(ch);
			}
		}
	}

	private void getFieldByteValue(int length) throws Exception {
		fieldByteValue.reset();

		for (int i = 0; i < length; i++) {
			if (nextByte == -1) {
				break;
			}
			fieldByteValue.write(nextByte);
			getNextByte();
		}
	}

	private void skipPastEndOfLine() throws Exception {
		while (nextByte != -1 && nextByte != '\n')
			getNextByte();

		if (nextByte == '\n')
			getNextByte();
	}

	private void convertFlatFileToXml(InputStream in, OutputStream out,
			String inputEncoding) throws Exception {
		inputTextEncoding = inputEncoding;
		this.in = new BufferedInputStream(in);
		this.out = out;
		getNextByte();
		writeln(out, "<" + spec.name + ">");
		margin = 3;
		convertFieldListToXml(spec.fields, "", null);
		writeln(out, "</" + spec.name + ">");
	}

	public void convertNextPartOfFlatFileToXml(OutputStream out)
			throws Exception {
		this.out = out;
		writeln(out, "<" + spec.name + ">");
		margin = 3;
		convertFieldListToXml(spec.fields, "", null);
		writeln(out, "</" + spec.name + ">");
	}

	private void convertFieldListToXml(List fields, String baseName,
			HashMap valueTable) throws Exception {
		for (Iterator i = fields.iterator(); i.hasNext();) {
			FieldDef f = (FieldDef) i.next();
			convertRepeatedFieldToXml(f, baseName, valueTable);
			if (nextByte == -1)
				break;
		}
	}

	private void convertRepeatedFieldToXml(FieldDef f, String baseName,
			HashMap valueTable) throws Exception {
		for (int r = 1; r <= f.repeatCount; r++) {
			if (nextByte == -1)
				break;

			if (f instanceof RecordDef) {
				RecordDef recordDef = (RecordDef) f;
				if (!recordDef.omitXmlTag()) {
					writeMargin(out);
					writeln(out, "<" + f.name + ">");
					margin += 3;
				}
				convertFieldListToXml(recordDef.fields,
						baseName + f.name + ".", valueTable);
				if (!recordDef.omitXmlTag()) {
					margin -= 3;
					writeMargin(out);
					writeln(out, "</" + f.name + ">");
				}
			} else if (f instanceof VariantRecordDef) {
				VariantRecordDef vr = (VariantRecordDef) f;

				margin += 3;
				int oldNextByte = nextByte;
				OutputStream oldOut = out;
				out = new ByteArrayOutputStream();
				HashMap newValueTable = new HashMap();
				in.mark(1024);
				convertFieldListToXml(vr.commonFields, "", newValueTable);
				margin -= 3;

				RecordDef variant;
				try {
					variant = selectVariant(vr.variants, newValueTable);
				} catch (Exception e) {
					nextByte = oldNextByte;
					in.reset();
					out = oldOut;
					return;
				}

				if (!variant.omitXmlTag()) {
					writeMargin(out);
					writeln(out, "<" + variant.name + ">");
					margin += 3;
					((ByteArrayOutputStream) out).writeTo(oldOut);
					out = oldOut;
				}
				convertFieldListToXml(variant.fields, baseName + f.name + ".",
						valueTable);
				if (!variant.omitXmlTag()) {
					margin -= 3;
					writeMargin(out);
					writeln(out, "</" + variant.name + ">");
				}
			} else if (f instanceof DelimitedFieldDef) {
				convertDelimitedFieldToXml((DelimitedFieldDef) f, baseName,
						valueTable);
			} else if (f instanceof SimpleFieldDef) {
				convertSimpleFieldToXml((SimpleFieldDef) f, baseName,
						valueTable);
			} else if (f instanceof FillerFieldDef) {
				getFieldStringValue(f.fieldLength, false);
			} else if (f instanceof EndOfLineFieldDef) {
				skipPastEndOfLine();
			} else if (f instanceof DateTimeFieldDef) {
				Date d = new Date();
				genDateTimeElement(d);
			}
		}
	}

	private RecordDef selectVariant(List variants, HashMap values)
			throws Exception {
		for (Iterator i = variants.iterator(); i.hasNext();) {
			RecordDef variant = (RecordDef) i.next();
			// System.out.println ("variant = " + variant.name);
			// System.out.println ("whenVariable = " + variant.whenVariable);
			// System.out.println ("whenValue = " + variant.whenValue);
			if (variant.whenVariable == null)
				return variant;
			String value = (String) values.get(variant.whenVariable);
			if (variant.whenValue.equals(value)) {
				return variant;
			}
		}
		throw new Exception("Matching variant record not found.");
	}

	private void genDateTimeElement(Date d) throws Exception {
		Calendar calendar = new GregorianCalendar();

		calendar.setTime(d);
		int year = calendar.get(calendar.YEAR);
		int month = calendar.get(Calendar.MONTH) + 1;
		int day = calendar.get(Calendar.DAY_OF_MONTH);
		int hour = calendar.get(Calendar.HOUR_OF_DAY);
		int minute = calendar.get(Calendar.MINUTE);
		int second = calendar.get(Calendar.SECOND);
		int subsecond = calendar.get(Calendar.MILLISECOND);
		int timezone = calendar.get(Calendar.ZONE_OFFSET) / 1000 / 36;

		writeMargin(out);
		writeln(out, "<DATETIME>");

		margin += 3;
		writeMargin(out);
		writeln(out, "<YEAR>" + year + "</YEAR>");

		writeMargin(out);
		writeln(out, "<MONTH>" + month + "</MONTH>");

		writeMargin(out);
		writeln(out, "<DAY>" + day + "</DAY>");

		writeMargin(out);
		writeln(out, "<HOUR>" + hour + "</HOUR>");

		writeMargin(out);
		writeln(out, "<MINUTE>" + minute + "</MINUTE>");

		writeMargin(out);
		writeln(out, "<SECOND>" + second + "</SECOND>");

		writeMargin(out);
		writeln(out, "<SUBSECOND>" + subsecond + "</SUBSECOND>");

		writeMargin(out);
		writeln(out, "<TIMEZONE>" + DateUtil.pad(timezone, 5) + "</TIMEZONE>");

		margin -= 3;
		writeMargin(out);
		writeln(out, "</DATETIME>");
	}

	private void convertSimpleFieldToXml(SimpleFieldDef f, String baseName,
			HashMap valueTable) throws Exception {
		String value = getSimpleFieldValue(f);

		if (valueTable != null)
			valueTable.put(baseName + f.name, value);

		writeMargin(out);
		if (f.converter == null)
			write(out, "<" + f.name + ">");
		else {
			write(out,
					"<" + f.name + " " + f.flatType + "=\""
							+ XMLUtils.xmlEscape(value) + "\">");
			FtlConverter converter = getConverter(f.converter);
			value = converter.convert(value, f.flatType, f.xmlType);
		}
		value = XMLUtils.xmlEscape(value);

		if (f.fieldTrim) {
			if ("left".equals(f.fieldAlignment))
				value = trimRight(value);
			else
				value = trimLeft(value);
		}
		write(out, value);
		write(out, "</" + f.name + ">");
		writeln(out);
	}

	private void convertDelimitedFieldToXml(DelimitedFieldDef f,
			String baseName, HashMap valueTable) throws Exception {
		String value = getDelimitedFieldValue(f);

		if (valueTable != null)
			valueTable.put(baseName + f.name, value);

		if (f.omitXmlTag())
			return;

		writeMargin(out);

		write(out, "<" + f.name + ">");

		value = XMLUtils.xmlEscape(value);

		if (f.fieldTrim) {
			if ("left".equals(f.fieldAlignment))
				value = trimRight(value);
			else
				value = trimLeft(value);
		}
		write(out, value);
		write(out, "</" + f.name + ">");
		writeln(out);
	}

	private String getDelimitedFieldValue(DelimitedFieldDef f) throws Exception {
		fieldStringValue.setLength(0);
		boolean found = false;
		while (nextByte != -1 && nextByte != '\n' && nextByte != '\r') {
			fieldStringValue.append((char) nextByte);
			String test = fieldStringValue.toString();
			if (test.contains(f.delimiter)) {
				getNextByte();
				found = true;
				break;
			}
			getNextByte();
		}
		if (found) {
			int dLength = f.delimiter.length();
			int fLength = fieldStringValue.length();
			int index = fLength - dLength;
			while (index < fLength) {
				fieldStringValue.deleteCharAt(index);
				index++;
			}
		}
		// System.out.println ("fieldName = " + f.name);
		// System.out.println ("fieldStringValue = " + fieldStringValue.toString
		// ());
		return fieldStringValue.toString();
	}

	private String getSimpleFieldValue(SimpleFieldDef f) throws Exception {
		String value;

		if (f.packedDecimal) {
			int numDigits = f.fieldLength;
			int byteLength = (numDigits + 2) / 2;

			getFieldByteValue(byteLength);
			byte[] byteValue = fieldByteValue.toByteArray();
			long numericValue = 0;
			int b, d, s;
			for (int i = 0; i < byteValue.length - 1; i++) {
				b = byteValue[i] & 255;
				d = b >> 4;
				numericValue = numericValue * 10 + d;
				d = b & 15;
				numericValue = numericValue * 10 + d;
			}
			b = byteValue[byteValue.length - 1] & 255;
			d = b >> 4;
			numericValue = numericValue * 10 + d;
			s = b & 15;
			if (s == 13)
				numericValue = -numericValue;
			value = numericValue + "";
		} else {
			boolean fixSpecialChars = f.format.startsWith("a")
					|| f.format.startsWith("A");
			getFieldStringValue(f.fieldLength, fixSpecialChars);
			value = fieldStringValue.toString();
		}
		if (f.scale != 0) {
			while (value.length() < f.scale)
				value = "0" + value;

			int length = value.length();
			int splitLocation = length - f.scale;
			String suffix = value.substring(splitLocation);
			String prefix = value.substring(0, splitLocation);
			value = prefix + "." + suffix;
		}
		return value;
	}

	private String trimRight(String value) {
		if (value == null)
			return "";

		int length = value.length();

		while (length > 0) {
			char ch = value.charAt(length - 1);
			if (ch != ' ')
				break;
			length -= 1;
		}
		return value.substring(0, length);
	}

	private String trimLeft(String value) {
		if (value == null)
			return "";

		int length = value.length();
		int pos = 0;

		while (pos > length) {
			char ch = value.charAt(pos);
			if (ch != ' ')
				break;
			pos += 1;
		}
		return value.substring(pos, length);
	}

	private FtlConverter getConverter(String name) throws Exception {
		FtlConverter converter = (FtlConverter) converterTable.get(name);
		if (converter == null) {
			Class converterClass = Class.forName(name);
			converter = (FtlConverter) converterClass.newInstance();
			converterTable.put(name, converter);
		}
		return converter;
	}

	private void convertXmlToFlatFile(InputStream in, OutputStream out,
			String characterEncoding, boolean genImsVsFormat) throws Exception {
		this.in = in;
		this.out = out;

		XmlNode document = parseXmlInputStream(in);
		if (genImsVsFormat) {
			ByteArrayOutputStream msgData = new ByteArrayOutputStream();
			writer = new OutputStreamWriter(msgData, characterEncoding);
			this.out = msgData;
			genFlatFile(document);
			writer.flush();
			this.out = out;
			int length = msgData.size() + 4;
			out.write(length / 256);
			out.write(length % 256);
			out.write(0);
			out.write(0);
			msgData.writeTo(out);
		} else {
			writer = new OutputStreamWriter(out, characterEncoding);
			genFlatFile(document);
			writer.flush();
		}
	}

	private XmlNode parseXmlInputStream(InputStream in) throws Exception {
		SAXParserFactory factory = SAXParserFactory.newInstance();
		factory.setNamespaceAware(true);
		factory.setValidating(false);

		SAXParser parser = factory.newSAXParser();
		FtlXmlParser handler = new FtlXmlParser();
		parser.parse(new InputSource(in), handler);

		return handler.getDocument();
	}

	private void genFlatFile(XmlNode document) throws Exception {
		FieldDef firstField = (FieldDef) spec.fields.get(0);
		if (firstField instanceof DelimitedRecordDef) {
			DelimitedRecordDef firstRec = (DelimitedRecordDef) firstField;
			writeDelimitedHeader(firstRec);
		}
		writeFieldList(spec.fields, document);
	}

	private void writeDelimitedHeader(DelimitedRecordDef r) throws Exception {
		if (!(r.writeHeader()))
			return;
		boolean headerFinished = false;
		for (Iterator i = r.fields.iterator(); i.hasNext();) {
			FieldDef f = (FieldDef) i.next();

			if (f instanceof DelimitedFieldDef) {
				DelimitedFieldDef df = (DelimitedFieldDef) f;
				writeDelimitedHeaderField(df);
				headerFinished = true;
			}
		}
		if (headerFinished) {
			writer.write("\n");
		}
	}

	private void writeFieldList(List fields, XmlNode document) throws Exception {
		List associatedElements = new Vector(100);
		for (Iterator i = fields.iterator(); i.hasNext();) {
			FieldDef f = (FieldDef) i.next();

			associatedElements.clear();
			if (f instanceof SimpleFieldDef || f instanceof RecordDef
					|| f instanceof DelimitedFieldDef
					|| f instanceof DelimitedRecordDef) {
				getElements(document, f.name, associatedElements);
				writeRepeatedField(f, associatedElements);
			} else if (f instanceof VariantRecordDef) {
				if (document != null)
					associatedElements.addAll(document.contents);
				writeRepeatedVariantRec((VariantRecordDef) f,
						associatedElements);
			} else {
				writeRepeatedField(f, associatedElements);
			}
		}
	}

	private void writeRepeatedVariantRec(VariantRecordDef vr,
			List associatedElements) throws Exception {
		Iterator vi = associatedElements.iterator();
		for (int r = 1; r <= vr.repeatCount; r++) {
			XmlNode node = getNextMatchingNode(vi, vr);
			if (node != null) {
				writeField(vr, node);
			} else {
				if ("*".equals(vr.repeat))
					break;
				writeField(vr, null);
			}
		}
	}

	private XmlNode getNextMatchingNode(Iterator nodes, VariantRecordDef vr) {
		while (nodes.hasNext()) {
			Object o = nodes.next();
			if (o instanceof XmlNode) {
				XmlNode node = (XmlNode) o;
				for (Iterator i = vr.variants.iterator(); i.hasNext();) {
					RecordDef r = (RecordDef) i.next();
					if (r.name.equals(node.name))
						return node;
				}
			}
		}
		return null;
	}

	private void writeRepeatedField(FieldDef f, List associatedElements)
			throws Exception {
		Iterator vi = associatedElements.iterator();
		for (int r = 1; r <= f.repeatCount; r++) {
			if (vi.hasNext()) {
				XmlNode node = (XmlNode) vi.next();
				writeField(f, node);
			} else {
				if ("*".equals(f.repeat))
					break;
				writeField(f, null);
			}
		}
	}

	private void writeField(FieldDef f, XmlNode associatedElement)
			throws Exception {
		if (f instanceof RecordDef) {
			if (f instanceof DelimitedRecordDef) {
				DelimitedRecordDef r = (DelimitedRecordDef) f;
				writeDelimitedRecord(r, associatedElement);
			} else {
				RecordDef r = (RecordDef) f;
				writeFieldList(r.fields, associatedElement);
			}
		} else if (f instanceof SimpleFieldDef) {
			writeSimpleField((SimpleFieldDef) f, associatedElement);
		} else if (f instanceof DelimitedFieldDef) {
			writeDelimitedField((DelimitedFieldDef) f, associatedElement);
		} else if (f instanceof FillerFieldDef) {
			write(writer, f.defaultValue, f.fieldLength, false, ' ');
		} else
			write(writer, f.defaultValue);
	}

	private void writeDelimitedRecord(DelimitedRecordDef r,
			XmlNode associatedElement) throws Exception {
		if (!r.writeWhenXmlIsMissing && associatedElement == null)
			return;
		writeFieldList(r.fields, associatedElement);
	}

	private void writeSimpleField(SimpleFieldDef f, XmlNode associatedElement)
			throws Exception {
		String fieldValue = null;
		if (associatedElement != null) {
			fieldValue = associatedElement.getText();
		}
		if (fieldValue == null) {
			fieldValue = f.defaultValue;
		}
		if (f.converter != null) {
			FtlConverter converter = getConverter(f.converter);
			fieldValue = converter.convert(fieldValue, f.xmlType, f.flatType);
		}
		if (f.packedDecimal) {
			writeComp3Field(f, fieldValue);
		} else if (f.binary) {
			writeBinaryField(f, fieldValue);
		} else if (f.scale != 0 || f.signed || f.trimLeadingZeroes) {
			writeNumericField(f, fieldValue);
		} else {
			write(writer, fieldValue, f.fieldLength,
					"right".equals(f.fieldAlignment), f.padChar);
		}
	}

	private void writeDelimitedField(DelimitedFieldDef f,
			XmlNode associatedElement) throws Exception {
		String fieldValue = null;
		if (associatedElement != null) {
			fieldValue = associatedElement.getText();
		}
		if (fieldValue == null) {
			fieldValue = f.defaultValue;
		}
		if (fieldValue == null) {
			fieldValue = "";
		}
		if (f.fieldTrim) {
			fieldValue = fieldValue.trim();
		}
		if (f.escapingStyle != null) {
			fieldValue = escapeFieldValue(f, fieldValue);
		}

		writer.write(fieldValue);
		writer.write(f.delimiter);
	}

	private void writeDelimitedHeaderField(DelimitedFieldDef f)
			throws Exception {
		String fieldValue = f.description;
		if (fieldValue == null) {
			fieldValue = "";
		}
		if (f.fieldTrim) {
			fieldValue = fieldValue.trim();
		}
		if (f.escapingStyle != null) {
			fieldValue = escapeFieldValue(f, fieldValue);
		}

		writer.write(fieldValue);
		writer.write(f.delimiter);
	}

	private String escapeFieldValue(DelimitedFieldDef f, String fieldValue) {
		if (f.escapingStyle == null)
			return fieldValue;

		if ("EXCEL".equals(f.escapingStyle)) {
			StringBuffer buffer = new StringBuffer();
			if (fieldValue.contains("\"")) {
				buffer.append("\"");
				buffer.append(fieldValue.replaceAll("\"", "\\\"\\\""));
				buffer.append("\"");
				fieldValue = buffer.toString().trim();
			}
			if (fieldValue.contains(f.delimiter) || fieldValue.contains("'")
					|| fieldValue.contains("\n")) {
				buffer.append("\"");
				buffer.append(fieldValue);
				buffer.append("\"");
				fieldValue = buffer.toString().trim();
			}
		} else if ("UNIX".equals(f.escapingStyle)) {
			if (fieldValue.contains(f.delimiter)) {
				fieldValue = fieldValue.replaceAll(f.delimiter,
						("\\\\" + f.delimiter));
			}
			if (fieldValue.contains("\n")) {
				fieldValue = fieldValue.replaceAll("\n", "\\\\\n");
			}
		}
		return fieldValue;
	}

	protected void writeNumericField(SimpleFieldDef f, String fieldValue)
			throws Exception {
		long value = getNumericValue(f, fieldValue);
		if (value >= 0) {
			write(writer, value + "", f.fieldLength,
					"right".equals(f.fieldAlignment), f.padChar);
		} else {
			value = 0 - value;
			write(writer, "-");
			write(writer, value + "", f.fieldLength - 1,
					"right".equals(f.fieldAlignment), f.padChar);
		}
	}

	private void writeBinaryField(SimpleFieldDef f, String fieldValue)
			throws Exception {
		writer.flush();
		long l = getNumericValue(f, fieldValue);
		int numberOfMinValues;
		long minValue;
		int j = 0;
		for (int i = f.fieldLength - 1; i > 0; i--, j++) {

			minValue = (long) java.lang.Math.pow(2, (8 * i));
			numberOfMinValues = (int) (l / minValue);
			out.write((int) numberOfMinValues);
			if (numberOfMinValues > 0)
				l = l - (numberOfMinValues * minValue);
		}
		out.write((int) l);
	}

	private void writeComp3Field(SimpleFieldDef f, String fieldValue)
			throws Exception {
		int numDigits = f.fieldLength;
		int byteLength = (numDigits + 2) / 2;
		byte[] b = new byte[byteLength];

		long value = getNumericValue(f, fieldValue);

		int sign = 15;
		if (f.signed) {
			sign = 12;
			if (value < 0) {
				value = 0 - value;
				sign = 13;
			}
		}

		int pos = b.length - 1;
		b[pos--] = (byte) (value % 10 * 16 + sign);
		value = value / 10;
		for (int i = pos; i >= 0; i--) {
			long d2 = value % 10;
			value /= 10;
			long d1 = value % 10;
			value /= 10;
			b[i] = (byte) (d1 * 16 + d2);
		}
		writer.flush();
		write(out, b);
	}

	private long getNumericValue(SimpleFieldDef f, String fieldValue) {
		long value = 0;
		if (fieldValue != null) {
			if (f.scale == 0) {
				value = Long.parseLong(fieldValue);
			} else {
				double d = new Double(fieldValue).doubleValue();
				for (int i = 0; i < f.scale; i++) {
					d = d * 10;
				}
				value = Math.round(d);
			}
		}
		return value;
	}

	/**
	 * Gets the elements with the specified tagName from the specified document
	 * and appends them to the end of the specified list.
	 */
	private void getElements(XmlNode document, String tagName, List list) {
		if (document == null) {
			return;
		}

		XmlNode node = document.getElement(tagName);
		while (node != null) {
			list.add(node);
			node = node.getNextSiblingWithSameName();
		}
	}

	private void write(Writer writer, String value, int width,
			boolean rightAlign, char padChar) throws Exception {
		if (value == null)
			value = "";

		int valueLength = value.length();

		if (rightAlign) {
			int start = 0;
			int pad = 0;

			if (valueLength > width)
				start = valueLength - width;
			else
				pad = width - valueLength;

			for (int i = 1; i <= pad; i++)
				writer.write(padChar);

			for (int i = start; i < valueLength; i++)
				writer.write(value.charAt(i));
		} else {
			for (int i = 0; i < width; i++) {
				if (i < valueLength)
					writer.write(value.charAt(i));
				else
					writer.write(padChar);
			}
		}
	}

	private void write(Writer writer, String value) throws Exception {
		if (value != null) {
			writer.write(value);
		}
	}

	private void write(OutputStream out, String value) throws Exception {
		if (value != null) {
			for (int i = 0; i < value.length(); i++)
				out.write(value.charAt(i));
		}
	}

	private void write(OutputStream out, byte[] value) throws Exception {
		if (value != null) {
			out.write(value);
		}
	}

	private void writeMargin(OutputStream out) throws Exception {
		for (int i = 0; i < margin; i++)
			out.write(' ');
	}

	private void writeln(OutputStream out) throws Exception {
		write(out, "\n");
	}

	private void writeln(OutputStream out, String value) throws Exception {
		write(out, value);
		write(out, "\n");
	}
}
