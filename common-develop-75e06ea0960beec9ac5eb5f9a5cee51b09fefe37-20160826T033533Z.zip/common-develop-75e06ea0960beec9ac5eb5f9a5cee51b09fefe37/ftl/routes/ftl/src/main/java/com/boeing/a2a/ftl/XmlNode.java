package com.boeing.a2a.ftl;

import org.xml.sax.*;

import java.util.*;

/**
 *  Represents an element in an XmlDocument. 
 */
public class XmlNode
{
   /**
    * Name of the element.
    */
   public String name;

   /**
    * The attributes of the element.
    */
   public Attributes atts;

   /**
    * The location of the element in document.
    */
   public Locator locator;

   /**
    * The child elements and text content of the element.
    */
   public List contents = new LinkedList ();

   /**
    * The parent element that contains this element.
    */
   public XmlNode parent;


   /**
    * Points to the next sibling that has the same name, if there is one;
    * otherwise is null;
    */
   private XmlNode   next;

   /**
    * Provides for efficient of the first child element with a specified name.
    */
   private HashMap   contentsIndex = null;


   /**
    * Constructs a basic XmlNode representing a element with no data
    * filled in.
    */
   public XmlNode ()
   {
   }

  
   /**
    * Constructs an XmlNode representing an element with a specified name,
    * attributes, and location in the original document.
    */
   public XmlNode (String name, Attributes atts, Locator loc)
   {
      this.name = name;
      this.atts = atts;
      this.locator = loc;
   }


   /**
    * Returns the text content of this element as single string. For example
    * if the element was defined as follows:
    * <pre>
    *    &lt;element>abc&lt;subelement/>def&lt;/element>
    * </pre>
    * this method would return the string "abcdef".
    */
   public String getText ()
   {
      String result = null;

      for (Iterator i = contents.iterator (); i.hasNext (); )
      {
         Object o = i.next ();
         if (o instanceof String)
         {
            if (result == null)
               result = (String) o;
            else
               result += (String) o;
         }
      }
      return result;
   }


   /**
    * Returns the next sibling element with the same name as this element.
    *
    * @return the next sibling node with the same name as this element,
    *         if it exists; otherwise null.
    */
   public XmlNode getNextSiblingWithSameName ()
   {
      return next;
   }


   /**
    * Returns the first subelement of this element with the specified name.
    * Each successive subelement with the same name can be found using
    * operation <code>getNextSiblingWithSameName</code> on the subelement.
    *
    * @param  name    name of the desired element.
    * @return the first child node with the specified name, if it exists;
    *         otherwise null.
    */
   public XmlNode getElement (String name)
   {
      if (contentsIndex == null)
         buildIndex ();
      return (XmlNode) contentsIndex.get (name);
   }


   /**
    * Builds the <code>contentsIndex</code> hash map for quick
    * lookup of child elements. Also, it links siblings with the
    * same name as it builds the index.
    */
   private void buildIndex ()
   {
      int hashMapSize = contents.size () / 7;

      if (hashMapSize == 0)
         hashMapSize = 1;

      contentsIndex = new HashMap (hashMapSize);

      for (Iterator i = contents.iterator (); i.hasNext (); )
      {
         Object o = i.next ();

         // The content object o may be either a String representing text
         // contained in this element or a node representing a subelement
         // contained in this element. We will ignore text.

         if (o instanceof XmlNode)
         {
            XmlNode n = (XmlNode) o;
            XmlNode firstChild = (XmlNode) contentsIndex.get (n.name);
            if (firstChild == null)
            {
               contentsIndex.put (n.name, n);
            }
            else
            {
               firstChild.addSiblingWithSameName (n);
            }
         }
      }
   }


   /**
    * Adds a sibling node to the end of the list of siblings with the
    * name. The list is pointed to by instance variable <code>next</code>.
    */
   private void addSiblingWithSameName (XmlNode sibling)
   {
      XmlNode p = this;
      while (p.next != null) p = p.next;
      p.next = sibling;
   }

   /**
    * Returns a string representation of this node.
    */
   public String toString ()
   {
      return name;
   }


   /**
    * Writes an XML represnetion of this node and its contents to
    * standard out.
    *
    * @param indent  specifies the number of spaces to indent the output.
    */
   public void print (int indent)
   {
      boolean newLineStarted = false;

      for (int i = 1; i <= indent; i++)
         System.out.print (" ");
      System.out.print ("<" + name);
      printAttributes ();
      System.out.print (">");
      for (Iterator i = contents.iterator (); i.hasNext ();)
      {
         Object n = i.next (); 
         if (n instanceof String)
            System.out.print (n);
         else
         {
            if (!newLineStarted) 
               System.out.println ();
            newLineStarted = true;
            XmlNode node = (XmlNode) n;
            node.print (indent+3);
         }
      }
      if (newLineStarted)
      {
         for (int i = 1; i <= indent; i++)
            System.out.print (" ");
      }
      System.out.println ("</" + name + ">");
   }


   /**
    * Write the attributes of this node to standard out.
    */
   private void printAttributes ()
   {
      for (int i = 0; i < atts.getLength (); i++)
      {
         System.out.print (" " + atts.getLocalName (i) + "='" +
            atts.getValue (i) + "'" );
      }
   }
}
