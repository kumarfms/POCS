package com.boeing.ai.common.ceers.utilities;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.boeing.ai.common.ceers.component.CeersEventSender;
import com.boeing.ai.common.ceers.exception.CeersException;
import com.boeing.ai.common.ceers.messages.AuditEvent;
import com.boeing.ai.common.ceers.messages.BaseEvent;
import com.boeing.ai.common.ceers.messages.CeersMessage;
import com.boeing.ai.common.ceers.messages.DataSensitivityType;
import com.boeing.ai.common.ceers.messages.EventSeverity;
import com.boeing.ai.common.ceers.messages.EventState;
import com.boeing.ai.common.ceers.messages.EventType;
import com.boeing.ai.common.ceers.messages.NotificationEvent;
import com.boeing.ai.common.ceers.messages.PayloadType;
import com.boeing.ai.common.ceers.messages.StateEvent;


public class CeersMessageBuilder {

	// Variables
	private final transient Logger LOG = LoggerFactory.getLogger(CeersMessage.class);

	// Audit Event Factory Methods
	public AuditEvent newAuditEvent(String messageName) throws Exception {
		CeersMessage ceersmessage = new CeersMessage();
		AuditEvent ae = new AuditEvent(messageName);
		ceersmessage.setAuditEvent(ae);
		ceersmessage.setStateEvent(null);
		ceersmessage.setNotificationEvent(null);
		ceersmessage.setEventType(EventType.AUDIT);

		LOG.debug("Initializing Audit Event");

		return ae;
	}

	public AuditEvent newAuditEvent(String messageName, Object message) throws Exception {
		AuditEvent ae = newAuditEvent(messageName);
		ae.setPayloadMsgBuffer(message);
		ae.setPayloadMsgType(PayloadType.MessageExchange);

		LOG.debug("Audit Event Initialized");

		return ae;
	}

	public AuditEvent newAuditEvent(String messageName, byte[] message) throws Exception {
		AuditEvent ae = newAuditEvent(messageName);
		ae.setPayloadMsgBuffer(message);
		ae.setPayloadMsgType(PayloadType.ByteArray);

		LOG.debug("Audit Event Initialized");

		return ae;
	}

	public AuditEvent newAuditEvent(String messageName, String eventGroup, DataSensitivityType dataSensitivity)
			throws Exception {
		AuditEvent ae = newAuditEvent(messageName);
		ae.setEventGroupName(eventGroup);
		ae.setDataSensitivity(dataSensitivity);

		LOG.debug("Audit Event Initialized");

		return ae;
	}

	public AuditEvent newAuditEvent(String messageName, String eventGroup, DataSensitivityType dataSensitivity,
			Object message) throws Exception {
		AuditEvent ae = newAuditEvent(messageName, eventGroup, dataSensitivity);
		ae.setPayloadMsgBuffer(message);
		ae.setPayloadMsgType(PayloadType.MessageExchange);

		LOG.debug("Audit Event Initialized");

		return ae;
	}

	public AuditEvent newAuditEvent(String messageName, String eventGroup, DataSensitivityType dataSensitivity,
			byte[] message) throws Exception {
		AuditEvent ae = newAuditEvent(messageName, eventGroup, dataSensitivity);
		ae.setPayloadMsgBuffer(message);
		ae.setPayloadMsgType(PayloadType.ByteArray);

		LOG.debug("Audit Event Initialized");

		return ae;
	}

	// State Event Factory Methods
	public StateEvent newStateEvent(String messageName) throws Exception {
		CeersMessage ceersmessage = new CeersMessage();
		StateEvent se = new StateEvent(messageName);
		ceersmessage.setAuditEvent(null);
		ceersmessage.setStateEvent(se);
		ceersmessage.setNotificationEvent(null);
		ceersmessage.setEventType(EventType.STATE);

		LOG.debug("Initializing State Event");

		return se;
	}

	public StateEvent newStateEvent(String messageName, EventState state, String additionalInfo) throws Exception {
		StateEvent se = newStateEvent(messageName);

		LOG.debug("Initializing State Event");

		se.setTransactionState(state);
		if (additionalInfo != null)
			se.setAdditionalInfo(additionalInfo);

		return se;
	}

	public StateEvent newStateEvent(String messageName, String eventGroup, DataSensitivityType dataSensitivity)
			throws Exception {
		StateEvent se = newStateEvent(messageName);
		se.setEventGroupName(eventGroup);
		se.setDataSensitivity(dataSensitivity);

		LOG.debug("Initializing State Event");

		return se;
	}

	public StateEvent newStateEvent(String messageName, String eventGroup, DataSensitivityType dataSensitivity,
			EventState state, String additionalInfo) throws Exception {
		StateEvent se = newStateEvent(messageName, eventGroup, dataSensitivity);

		LOG.debug("Initializing State Event");

		se.setTransactionState(state);
		if (additionalInfo != null)
			se.setAdditionalInfo(additionalInfo);

		return se;
	}

	// Notification Event Factory Methods
	public NotificationEvent newNotificationEvent(String messageName) throws Exception {
		CeersMessage ceersmessage = new CeersMessage();
		NotificationEvent ne = new NotificationEvent(messageName);
		ceersmessage.setAuditEvent(null);
		ceersmessage.setStateEvent(null);
		ceersmessage.setNotificationEvent(ne);
		ceersmessage.setEventType(EventType.NOTIFICATION);

		LOG.debug("Initializing NotificationEvent Event");

		ne.setPayloadMsgType(PayloadType.None);
		ne.setShortDescription("No Description Provided");

		return ne;
	}

	public NotificationEvent newNotificationEvent(String messageName, EventSeverity severity, String shortDesc,
			String longDesc) throws Exception {
		NotificationEvent ne = newNotificationEvent(messageName);

		LOG.debug("Initializing NotificationEvent Event");

		ne.setSeverity(severity);
		if (!StringUtils.isBlank(shortDesc))
			ne.setShortDescription(shortDesc);

		if (longDesc != null)
			ne.setDetailedDescription(longDesc);

		return ne;
	}

	public NotificationEvent newNotificationEvent(String messageName, EventSeverity severity, String shortDesc,
			Exception ex) throws Exception {
		NotificationEvent ne = newNotificationEvent(messageName);

		LOG.debug("Initializing NotificationEvent Event");

		ne.setSeverity(severity);
		if (!StringUtils.isBlank(shortDesc))
			ne.setShortDescription(shortDesc);

		if (ex != null)
			ne.setDetailedDescription(ex.getMessage() + "\n" + ExceptionUtils.getStackTrace(ex));

		return ne;
	}

	public NotificationEvent newNotificationEvent(String messageName, String eventGroup,
			DataSensitivityType dataSensitivity) throws Exception {
		NotificationEvent ne = newNotificationEvent(messageName);
		ne.setEventGroupName(eventGroup);
		ne.setDataSensitivity(dataSensitivity);

		LOG.debug("Initializing NotificationEvent Event");

		ne.setPayloadMsgType(PayloadType.None);
		ne.setShortDescription("No Description Provided");

		return ne;
	}

	public NotificationEvent newNotificationEvent(String messageName, String eventGroup,
			DataSensitivityType dataSensitivity, EventSeverity severity, String shortDesc, String longDesc)
			throws Exception {
		NotificationEvent ne = newNotificationEvent(messageName, eventGroup, dataSensitivity);

		LOG.debug("Initializing NotificationEvent Event");

		ne.setSeverity(severity);
		if (!StringUtils.isBlank(shortDesc))
			ne.setShortDescription(shortDesc);

		if (longDesc != null)
			ne.setDetailedDescription(longDesc);

		return ne;
	}

	public NotificationEvent newNotificationEvent(String messageName, String eventGroup,
			DataSensitivityType dataSensitivity, EventSeverity severity, String shortDesc, Exception ex)
			throws Exception {
		NotificationEvent ne = newNotificationEvent(messageName, eventGroup, dataSensitivity);

		LOG.debug("Initializing NotificationEvent Event");

		ne.setSeverity(severity);
		if (!StringUtils.isBlank(shortDesc))
			ne.setShortDescription(shortDesc);

		if (ex != null)
			ne.setDetailedDescription(ex.getMessage() + "\n" + ExceptionUtils.getStackTrace(ex));

		return ne;
	}

	public String sendEvent(BaseEvent theEvent) throws Exception {
		LOG.debug("About to send Audit Event");
		EventLoggingUtility eventLogUtil = null;
		Boolean ignoreErrors = false;
		String eventId = "";
		String tmpString = "";

		// Check property to override logging.
		if (theEvent.getDisableLogging() == false) {
			// Ceers field lets you ignore errors during processing so business
			// messages are not stopped by CEERS issues.
			if (theEvent.getIgnoreEventErrors()) {
				ignoreErrors = true;
			}
			try {
				// ComponentName - If blank, grab calling class before moving
				// further.
				tmpString = theEvent.getComponentName();
				if (StringUtils.isBlank(tmpString) || tmpString.contains("UNK")) // Clearout
																					// if
																					// set
																					// to
																					// unknown
																					// earlier
					tmpString = "";
				if (StringUtils.isBlank(tmpString)) {
					tmpString = CommonUtils.getCallerCallerClassName(); // Get
																		// from
																		// Calling
																		// Class
				}
				theEvent.setComponentName(tmpString);

				// Define EventLogging object.
				if (theEvent instanceof AuditEvent) {
					eventLogUtil = CeersUtils.setupAuditEvent((AuditEvent) theEvent);
				} else if (theEvent instanceof StateEvent) {
					eventLogUtil = CeersUtils.setupStateEvent((StateEvent) theEvent);
				} else if (theEvent instanceof NotificationEvent) {
					eventLogUtil = CeersUtils.setupNotificationEvent((NotificationEvent) theEvent);
				}

				// Output to a folder or send to queue
				if (eventLogUtil != null) {
					CeersEventSender.postEvent(theEvent);
				} else {
					throw new CeersException("Unable to generate EventLoggingUtility object");
				}
				eventId = eventLogUtil.getEventID();
			} catch (CeersException ce) {
				LOG.error(ce.getMessage());
				if (ignoreErrors) {
					LOG.warn("CEERS IgnoreErrors set to true. Processing not aborted.");
				} else {
					throw ce;
				}
			} catch (Exception e) {
				LOG.error("Exception while sending CEERS Event data: " + e.getMessage() + "\n"
						+ ExceptionUtils.getStackTrace(e));
				if (ignoreErrors) {
					LOG.warn("CEERS IgnoreErrors set to true. Processing not aborted.");
				} else {
					throw e;
				}
			}
		} else {
			LOG.info("Logging  Events intentionally disabled");
		}
		return eventId;
	}

	

}
