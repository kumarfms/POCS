/*
 * Copyright 2016 (C) The Boeing Company
 * 
 * Created On   : 05-01-2016
 * Authors      : Tim Schramer
 * File         : CeersWsTester.java - WebService implementation, which implements
 *                                     the web service interface and demonstrates
 *                                     sending the different CEERS Event types.
 *---------------------------------------------------------------------------------
 * Revision History (Release 1.0.0)
 *---------------------------------------------------------------------------------
 * VERSION        AUTHOR                  DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                    CR NO
 *--------------|-----------------------|------------------------------------------
 * -.-.-/1.0.0  | Tim Schramer          | New
 *              | 05-01-2016            | 
 *--------------|-----------------------|------------------------------------------
 */
/*-------------------------------------------------------------------------------*/
package com.boeing.ai.ceers_ws_tester;
import com.boeing.ai.common.ceers.messages.*;
import com.boeing.ai.common.ceers.utilities.CeersMessageBuilder;


import java.io.File;
import java.nio.file.Paths;
import java.util.UUID;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/*-------------------------------------------------------------------------------*/
// The WebService implementation, which implements the web service interface.
// The @WebService annotation marks this class an implementation for the endpoint interface.
@WebService(endpointInterface = "com.boeing.ai.ceers_ws_tester.CeersWsTester")
public class CeersWsTesterImpl implements CeersWsTester {
    private final transient Logger LOG = LoggerFactory.getLogger(CeersWsTesterImpl.class);

    // Return string to calling client
    public String generateEvents(String payload) throws Exception {

        CeersMessageBuilder em = new CeersMessageBuilder();  // Parent Class for Events
        AuditEvent ae = null;                                    // AuditEvent Class
        StateEvent se = null;                                    // State Event Class
        NotificationEvent ne = null;                             // Notification Event Class
        String globalTxId = UUID.randomUUID().toString();        // Global Transaction ID to group all Events.
        String output = "";
        String eventID = "";
        String eventOutputDir = "";                              // Optional Event output folder

        // Comment next line to send Events to CEERS instead of a local folder.
        eventOutputDir = Paths.get(RD(), "temp", "CeersEvents").toString();

        try {

            // Create Audit Event - See overloads in CeersEventManagerImpl for different ways
            // to create an Audit Event.
            ae = em.newAuditEvent("CeersWsTester_Audit_Msg");  // New Audit Event with MessageName
            ae.setGlobalTransactionID(globalTxId);             // Common Global Transaction ID.
            ae.setIgnoreEventErrors(false);                    // Do not ignore CEERS Audit Processing Errors
            ae.setApplicationName("CEERS_WS_TESTER");          // ApplicationName
            ae.setEventGroupName("CeersWsTester_Group");       // GroupName
            ae.setPayloadMsgBuffer(payload);                   // Payload (String, MessageBody or Exchange)
            ae.setTransferType(EventTransferType.Log);         // TransferType (Rcv, Log or Send)
            ae.setAlternateLogFilePath(eventOutputDir);        // Optional - Alternate logging directory

            // Send out the Audit Event
            eventID = em.sendEvent(ae);
            globalTxId = UUID.randomUUID().toString();
            // Setup WebService return string. Append output folder if it was set.
            output = " \nAudit Event ID: \"" + eventID + "\" sent";
            if(eventOutputDir.length() > 0)
                output = output + " to folder: \"" + eventOutputDir + "\"";

            // Create State Event - See overloads in CeersEventManagerImpl for different ways
            // to create a State Event.
            se = em.newStateEvent("CeersWsTester_State_Msg");  // New State Event with MessageName
            se.setGlobalTransactionID(globalTxId);             // Common Global Transaction ID.
            se.setIgnoreEventErrors(false);                    // Do not ignore CEERS State Processing Errors
            se.setApplicationName("CEERS_WS_TESTER");          // ApplicationName
            se.setEventGroupName("CeersWsTester_Group");       // GroupName
            se.setTransactionState(EventState.Completed);      // TransactionState (Started, Completed, Failed, Info, Wait or Debug}
            se.setAlternateLogFilePath(eventOutputDir);        // Optional - Alternate logging directory

            // Send out the State Event
            eventID = em.sendEvent(se);

            // Modify WebService return string. Append output folder if it was set.
            output = output +"\nState Event ID: \"" + eventID + "\" sent";
            if(eventOutputDir.length() > 0)
                output = output + " to folder: \"" + eventOutputDir + "\"";

            // Intentionally throw Exception to show how Notification Events can be used to report error info.
            throw new Exception("Test Exception for Notification Event");

        // For Exceptions send Notification Event with Exception info and Resubmit functionality.
        } catch (Exception ce) {

            // Create Notification Event - See overloads in CeersEventManagerImpl for different ways
            // to create a Notification Event. New Notification Event with MessageName, GroupName, DataSensitivity
            // Severity, ShortDescription and Exception object.
        	globalTxId = UUID.randomUUID().toString();
            ne = em.newNotificationEvent("CeersWsTester_Notification_Msg", "CeersWsTester_Group", DataSensitivityType.BOEING_PROPRIETARY, EventSeverity.Error, "CeersWsTester Exception handler", ce);
            ne.setGlobalTransactionID(globalTxId);      // Common Global Transaction ID.
            ne.setIgnoreEventErrors(false);             // Do not ignore CEERS Notification Processing Errors
            ne.setApplicationName("CEERS_WS_TESTER");   // ApplicationName
            ne.setPayloadMsgBuffer(payload);            // Payload (String, MessageBody or Exchange)
            ne.setPayloadLogAmount("ALL");              // Payload Amount (ALL, NONE, XPATH(expression) or BYTERANGE(range))  
            ne.setAlternateLogFilePath(eventOutputDir); // Optional - Alternate logging directory
           
            // Optional Resubmit Info. Payload must be XML or byte array.
            ne.setResubmitEventID("THIS");
            ne.setResubmitParametersField("Transport", "FILE");                            // FILE or MQSC for now.
            ne.setResubmitParametersField("FilePath", "\\\\ESB_BTS_FILE\\BizTalk\\CEERS"); // File folder/share to drop resubmit.
            ne.setResubmitParametersField("FileName", "CeersWsTester_%GUID%.xml");         // Filename for file drop.

            // Send out the Notification Event
            eventID = em.sendEvent(ne);

            // Modify WebService return string. Append output folder if it was set.
            output = output +"\nNotification ERROR Event ID: \"" + eventID + "\" sent";
            if(eventOutputDir.length() > 0)
                output = output + " to folder: \"" + eventOutputDir + "\"";
        }

        // Return information back to calling client.
        return output;
    }

    // Return Root Directory - for filepath code readability
    public static String RD() {
        File[] roots = File.listRoots();
        return roots[0].toString();
    }
}
