/*
 * Copyright 2016 (C) The Boeing Company
 * 
 * Created On   : 05-02-2016
 * Authors      : Tim Schramer
 * File         : LogInfoBean.java - A bean which is used in the route.
 *---------------------------------------------------------------------------------
 * Revision History (Release 1.0.0)
 *---------------------------------------------------------------------------------
 * VERSION        AUTHOR                  DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                    CR NO
 *--------------|-----------------------|------------------------------------------
 * -.-.-/1.0.0  | Tim Schramer          | New
 *              | 05-02-2016            | 
 *--------------|-----------------------|------------------------------------------
 */
/*-------------------------------------------------------------------------------*/
package com.boeing.ai.ceers_route_tester;
/*-------------------------------------------------------------------------------*/
import java.text.SimpleDateFormat;
import java.util.Date;
/*-------------------------------------------------------------------------------*/
public class LogInfoBean implements LogInfo {

    private String info = "";

    public String loginfo() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return info + "Audit Event at " + sdf.format(new Date());
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }
}
