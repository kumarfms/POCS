/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 12-09-2016
 * Authors      : Alex Kretchetov, David Campbell, Rohan Mars, Tim Schramer
 * File         : CeersComponentTest.java - Unit Tests for CEERS Component
 *-----------------------------------------------------------------------------
 * Revision History (Release 2.5.5)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *-----------------------------------------------------------------------------
 * -.-.-/1.0.0  | Alex Kretchetov   | Initial Create.
 *              | David Campbell    |
 *              | Rohan Mars        |
 *              | 12-09-2016        |
 *--------------|-------------------|------------------------------------------
 * 1.0.0/2.0.0  | Tim Schramer      | Major update and additions.
 *              | Rohan Mars        | Added missing CEERS API functionality
 *              | 04-13-2016        |
 *--------------|-------------------|------------------------------------------
 * 2.0.0/2.5.0  | Tim Schramer      | Heavily extended for additional
 *              | 04-21-2016        | component parameters.
 *--------------|-------------------|------------------------------------------
 * 2.5.0/2.5.5  | Tim Schramer      | Updated tests to support AlternateLogging
 *              | 04-28-2016        | Event output option.
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common;
import com.boeing.ai.common.components.ceers.endpoint.CeersComponent;
import com.boeing.ai.common.utilities.Web.HttpUtilSupport;

import com.boeing.web.xmlns.ai.ceers.v1.Event;

import java.io.File;
import java.io.StringReader;
import java.nio.file.Paths;

import java.util.Dictionary;
import java.util.Map;

import javax.transaction.TransactionManager;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.Exchange;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.test.blueprint.CamelBlueprintTestSupport;
import org.apache.camel.util.KeyValueHolder;
import org.apache.geronimo.transaction.manager.RecoverableTransactionManager;

import org.junit.Test;

import org.mockito.Mockito;

import static org.hamcrest.CoreMatchers.instanceOf;
import static org.hamcrest.Matchers.isEmptyOrNullString;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.nullValue;
/*---------------------------------------------------------------------------*/
public class CeersComponentTest extends CamelBlueprintTestSupport {
    public final String LOCAL_ALTERNATE_QUEUE = "direct:localAlternateQueue";
    public final String LOCAL_AUDIT_QUEUE = "direct:localAuditQueue";
    public final String MOCK_REMOTE_AUDIT_QUEUE = "mock:remoteAuditQueue";
    public final String LOCAL_STATE_QUEUE = "direct:localStateQueue";
    public final String MOCK_REMOTE_STATE_QUEUE = "mock:remoteStateQueue";
    public final String LOCAL_NOTIFICATION_QUEUE = "direct:localNotificationQueue";
    public final String MOCK_REMOTE_NOTIFICATION_QUEUE = "mock:remoteNotificationQueue";

    @Produce
    ProducerTemplate producer;

    @Override
    protected String getBlueprintDescriptor() {
        return "/OSGI-INF/blueprint/blueprint.xml";
    }

    @SuppressWarnings("rawtypes")
    @Override
    protected void addServicesOnStartup(Map<String, KeyValueHolder<Object,Dictionary>> services) {
        TransactionManager transactionManager = Mockito.mock(TransactionManager.class);
        services.put(TransactionManager.class.getCanonicalName(), asService(transactionManager, null));

        RecoverableTransactionManager recoverableTransactionManager = Mockito.mock(RecoverableTransactionManager.class);
        services.put(RecoverableTransactionManager.class.getCanonicalName(), asService(recoverableTransactionManager, null));
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Override
    protected String useOverridePropertiesWithConfigAdmin(Dictionary props) {
        props.put("ceers.amq.brokerUrl", "vm://localhost?broker.persistent=false");
        props.put("ceers.alternate.local.endpoint", LOCAL_ALTERNATE_QUEUE);
        props.put("ceers.alternate.local.xa.endpoint", LOCAL_ALTERNATE_QUEUE);
        props.put("ceers.audit.local.endpoint", LOCAL_AUDIT_QUEUE);
        props.put("ceers.audit.local.xa.endpoint", LOCAL_AUDIT_QUEUE);
        props.put("ceers.audit.remote.xa.endpoint", MOCK_REMOTE_AUDIT_QUEUE);
        props.put("ceers.state.local.endpoint", LOCAL_STATE_QUEUE);
        props.put("ceers.state.local.xa.endpoint", LOCAL_STATE_QUEUE);
        props.put("ceers.state.remote.xa.endpoint", MOCK_REMOTE_STATE_QUEUE);
        props.put("ceers.notification.local.endpoint", LOCAL_NOTIFICATION_QUEUE);
        props.put("ceers.notification.local.xa.endpoint", LOCAL_NOTIFICATION_QUEUE);
        props.put("ceers.notification.remote.xa.endpoint", MOCK_REMOTE_NOTIFICATION_QUEUE);
        props.put("ceers.environmentname", "JBF AI DEV");
        props.put("ceers.resubmitservice", "JBF");

        return "ceers.properties";
    }

    /** Message Body used in audit and notification maximum URI "producer.sendBody()" calls below.
    <MyRoot>
      <MyElement1>
        <MyChild1>
          <Value>TEST1</Value>
        </MyChild1>
        <MyChild2>
          <Value>TEST2</Value>
        </MyChild2>
      </MyElement1>
    </MyRoot>
    */
    private String messageBody = "<MyRoot><MyElement1><MyChild1><Value>TEST1</Value></MyChild1><MyChild2><Value>TEST2</Value></MyChild2></MyElement1></MyRoot>";

    // AlternateLogFilePath value for logging Events to file. - platform safe. Encoded for URI on the sendBody() call.
    // private String eventOutputDir = Paths.get(RD(), "temp", "CeersEvents").toString();
    private String eventOutputDir = Paths.get("target", "CeersEvents").toString();

    // Test Audit Event Component calls_____________________________________________________
    @Test
    public void ceersAuditMessage() throws Exception {
        Exchange exchange;
        String payload;
        Event event;

        // let's add the component manually for the test
        // it doesn't always seem to load it from the manifest description
        context.addComponent("ceers", new CeersComponent());

        MockEndpoint auditEndpoint = getMockEndpoint(MOCK_REMOTE_AUDIT_QUEUE);
        auditEndpoint.setExpectedCount(2);

        // Send with minimum URI values
        producer.sendBody("ceers://?eventType=audit&applicationName=CEERS_TESTER", null);
        // Send minimum again, but write Event XML to "alternateLogFilePath=eventOutputDir" instead of queue.
        producer.sendBody("ceers://?eventType=audit&applicationName=CEERS_TESTER&alternateLogFilePath=" + HttpUtilSupport.UrlEncode(eventOutputDir), null);
        // Send with maximum URI values. (see comments below for readable list)
        producer.sendBody("ceers://?eventType=audit&globalTxId=75bc9f2c-ece4-4d32-8958-55d17ad125e2&eventGroup=TEST_GROUP&applicationName=CEERS_TESTER&messageName=MAX_PARAMETERS&serverName=TESTSERVER&environmentName=UNITTEST&componentName=TESTCOMPONENT&eventTimestamp=2016-04-16T23:51:53.752-07:00&userdata=%27FirstName%27=%27Tim%27,%27LastName%27=%27Schramer%27,%27PluckValue%27=%27XPATH(//MyChild2/Value/text())%27&dataSensitivity=FAR12&transferType=RCV&referenceOriginalPayload=false&payloadLogAmount=BYTERANGE(0,20)&payloadMsgHeader=%27Header1%27=%27Value1%27,%27Header2%27=%27Value2%27&resubmitServiceName=FUSERESUBMITSERVICE&resubmitParameters=%27Transport%27=%27MQSC%27,%27QueueMgr%27=%27MQHUBT1QM%27,%27Queue%27=%27AI.DEV.Q01%27&allowResubmit=true", messageBody);
        // Send maximum again, but write Event XML to "alternateLogFilePath=eventOutputDir" instead of queue.
        producer.sendBody("ceers://?eventType=audit&globalTxId=75bc9f2c-ece4-4d32-8958-55d17ad125e2&eventGroup=TEST_GROUP&applicationName=CEERS_TESTER&messageName=MAX_PARAMETERS&serverName=TESTSERVER&environmentName=UNITTEST&componentName=TESTCOMPONENT&eventTimestamp=2016-04-16T23:51:53.752-07:00&userdata=%27FirstName%27=%27Tim%27,%27LastName%27=%27Schramer%27,%27PluckValue%27=%27XPATH(//MyChild2/Value/text())%27&dataSensitivity=FAR12&transferType=RCV&referenceOriginalPayload=false&payloadLogAmount=BYTERANGE(0,20)&payloadMsgHeader=%27Header1%27=%27Value1%27,%27Header2%27=%27Value2%27&resubmitServiceName=FUSERESUBMITSERVICE&resubmitParameters=%27Transport%27=%27MQSC%27,%27QueueMgr%27=%27MQHUBT1QM%27,%27Queue%27=%27AI.DEV.Q01%27&allowResubmit=true&alternateLogFilePath=" + HttpUtilSupport.UrlEncode(eventOutputDir), messageBody);

        assertMockEndpointsSatisfied();

        // Minimum Parameters ______________________________________________________________
        exchange = auditEndpoint.getExchanges().get(0);
        assertThat("String class expected", exchange.getIn().getBody(), instanceOf(String.class));
        payload = (String)exchange.getIn().getBody();
        event = unmashall(payload);

        // Generated Event content
        assertThat("Auto-EventId", event.getEventId() , not(isEmptyOrNullString()));
        assertThat("Auto-Metadata", event.getMetadata(), not(nullValue()));
        assertThat("Auto-EventData", event.getEventData(), not(nullValue()));

        // Common Event content
        assertThat("Common-GlobalTxId", event.getGlobalTxId(), not(isEmptyOrNullString()));
        assertEquals("Common-EventGroup", "NotSpecified", event.getEventGroup());
        assertEquals("Common-ApplicationName", "CEERS_TESTER", event.getApplicationName());
        assertThat("Common-MessageName", event.getMessageName(), not(isEmptyOrNullString()));
        assertThat("Common-ServerName", event.getServerName(), not(isEmptyOrNullString()));
        assertThat("Common-EnvironmentName", event.getEnvironmentName(), not(isEmptyOrNullString()));
        assertThat("Common-ComponentName", event.getComponentName(), not(isEmptyOrNullString()));
        assertThat("Common-EventTimestsamp", event.getEventTimestamp(), not(nullValue()));
        assertThat("Common-UserdataNotPresent", event.getUserdata(), nullValue());
        assertEquals("Common-DataSensitivity", "RESTRICT", event.getDataSensitivity());

        // Audit Event specific content
        assertThat("Audit-TypePresent", event.getEventData().getAudit(), not(nullValue()));
        assertEquals("Audit-TransferType", "LOG", event.getEventData().getAudit().getTransferType());
        assertThat("Audit-ResubmitInfoNotPresent", event.getEventData().getAudit().getResubmitInfo(), nullValue());
        assertEquals("Audit-OriginalEventIdSet", event.getEventId(), exchange.getProperty("CeersOriginalEventId", String.class));

        // Maximum Parameters ______________________________________________________________
        /** Maximum Parameter Audit URI
            ceers://?eventType=audit
            &globalTxId=75bc9f2c-ece4-4d32-8958-55d17ad125e2
            &eventGroup=TEST_GROUP
            &applicationName=CEERS_TESTER
            &messageName=MAX_PARAMETERS
            &serverName=TESTSERVER
            &environmentName=UNITTEST
            &componentName=TESTCOMPONENT
            &eventTimestamp=2016-04-16T23:51:53.752-07:00
            &userdata=%27FirstName%27=%27Tim%27,%27LastName%27=%27Schramer%27,%27PluckValue%27=%27XPATH(//MyChild2/Value/text())%27
            &dataSensitivity=FAR12
            &transferType=RCV
            &referenceOriginalPayload=false
            &payloadLogAmount=BYTERANGE(0,20)
            &payloadMsgHeader=%27Header1%27=%27Value1%27,%27Header2%27=%27Value2%27
            &resubmitServiceName=FUSERESUBMITSERVICE
            &resubmitParameters=%27Transport%27=%27MQSC%27,%27QueueMgr%27=%27MQHUBT1QM%27,%27Queue%27=%27AI.DEV.Q01%27
            &allowResubmit=true
            &alternateLogFilePath=C:%5Ctemp%5CCeersEvents  // Option added to send Event to file instead of CEERS (Windows folder)
        */
        exchange = auditEndpoint.getExchanges().get(1);
        assertThat("String class expected", exchange.getIn().getBody(), instanceOf(String.class));
        payload = (String)exchange.getIn().getBody();
        event = unmashall(payload);

        // Generated Event content
        assertThat("Auto-EventId", event.getEventId(), not(isEmptyOrNullString()));
        assertThat("Auto-Metadata", event.getMetadata(), not(nullValue()));
        assertThat("Auto-EventData", event.getEventData(), not(nullValue()));

        // Common Event content
        assertEquals("Common-GlobalTxId", "75bc9f2c-ece4-4d32-8958-55d17ad125e2", event.getGlobalTxId());
        assertEquals("Common-EventGroup", "TEST_GROUP", event.getEventGroup());
        assertEquals("Common-ApplicationName", "CEERS_TESTER", event.getApplicationName());
        assertEquals("Common-MessageName", "MAX_PARAMETERS", event.getMessageName());
        assertEquals("Common-ServerName", "TESTSERVER", event.getServerName());
        assertEquals("Common-EnvironmentName", "UNITTEST", event.getEnvironmentName());
        assertEquals("Common-ComponentName", "TESTCOMPONENT", event.getComponentName());
        assertEquals("Common-EventTimestsamp", "2016-04-16T23:51:53.752-07:00", event.getEventTimestamp().toString());
        assertThat("Common-UserdataPresent", event.getUserdata(), not(nullValue()));
        assertEquals("Common-DataSensitivity", "FAR12", event.getDataSensitivity());

        // Audit Event specific content
        assertThat("Audit-TypePresent", event.getEventData().getAudit(), not(nullValue()));
        assertEquals("Audit-TransferType", "RCV", event.getEventData().getAudit().getTransferType());
        assertThat("Audit-PayloadPresent", event.getEventData().getAudit().getPayload(), not(nullValue()));
        assertThat("Audit-ContentPresent", event.getEventData().getAudit().getPayload().getContent(), not(nullValue()));
        assertThat("Audit-MessagePresent", event.getEventData().getAudit().getPayload().getContent().getMessageBody(), not(nullValue()));
        assertEquals("Audit-MessageText", "<MyRoot><MyElement1>", event.getEventData().getAudit().getPayload().getContent().getMessageBody().getTextContent());
        assertThat("Audit-PayloadHeaderPresent", event.getEventData().getAudit().getPayload().getContent().getMessageHeader(), not(nullValue()));
        assertThat("Audit-ResubmitInfoPresent", event.getEventData().getAudit().getResubmitInfo(), not(nullValue()));
        assertEquals("Audit-ResubmitService", "FUSERESUBMITSERVICE", event.getEventData().getAudit().getResubmitInfo().getResubmitServiceName());
        assertThat("Audit-ResubmitParametersPresent", event.getEventData().getAudit().getResubmitInfo().getResubmitParameters(), not(nullValue()));
        assertEquals("Audit-OriginalEventIdSet", event.getEventId(), exchange.getProperty("CeersOriginalEventId", String.class));

        // Also test manual send methods with the last Exchange. Send to a subdirectory of the eventOutputDir.
        String eventID = "";
        eventID = CeersMethodTest.ceersAuditSend(exchange, Paths.get(eventOutputDir, "MethodUnitTest").toString());
        assertThat("Audit-TestSendMethod", eventID, not(isEmptyOrNullString()));
    }

    // Test State Event Component calls_____________________________________________________
    @Test
    public void ceersStateMessage() throws Exception {
        Exchange exchange;
        String payload;
        Event event;

        // let's add the component manually for the test
        // it doesn't always seem to load it from the manifest description
        context.addComponent("ceers", new CeersComponent());

        MockEndpoint stateEndpoint = getMockEndpoint(MOCK_REMOTE_STATE_QUEUE);
        stateEndpoint.setExpectedCount(2);

        // Send with minimum URI values
        producer.sendBody("ceers://?eventType=state&applicationName=CEERS_TESTER", null);
        // Send minimum again, but write Event XML to "alternateLogFilePath=eventOutputDir" instead of queue.
        producer.sendBody("ceers://?eventType=state&applicationName=CEERS_TESTER&alternateLogFilePath=" + HttpUtilSupport.UrlEncode(eventOutputDir), null);
        // Send with maximum URI values. (see comments below for readable list)
        producer.sendBody("ceers://?eventType=state&globalTxId=75bc9f2c-ece4-4d32-8958-55d17ad125e2&eventGroup=TEST_GROUP&applicationName=CEERS_TESTER&messageName=MAX_PARAMETERS&serverName=TESTSERVER&environmentName=UNITTEST&componentName=TESTCOMPONENT&eventTimestamp=2016-04-16T23:51:53.752-07:00&userdata=%27FirstName%27=%27Tim%27,%27LastName%27=%27Schramer%27,%27PluckValue%27=%27XPATH(//MyChild2/Value/text())%27&dataSensitivity=FAR12&transactionState=COMPLETED&additionalInfo=Unit%20Test%20Additional%20Info", null);
        // Send maximum again, but write Event XML to "alternateLogFilePath=eventOutputDir" instead of queue.
        producer.sendBody("ceers://?eventType=state&globalTxId=75bc9f2c-ece4-4d32-8958-55d17ad125e2&eventGroup=TEST_GROUP&applicationName=CEERS_TESTER&messageName=MAX_PARAMETERS&serverName=TESTSERVER&environmentName=UNITTEST&componentName=TESTCOMPONENT&eventTimestamp=2016-04-16T23:51:53.752-07:00&userdata=%27FirstName%27=%27Tim%27,%27LastName%27=%27Schramer%27,%27PluckValue%27=%27XPATH(//MyChild2/Value/text())%27&dataSensitivity=FAR12&transactionState=COMPLETED&additionalInfo=Unit%20Test%20Additional%20Info&alternateLogFilePath=" + HttpUtilSupport.UrlEncode(eventOutputDir), null);
        assertMockEndpointsSatisfied();

        // Minimum Parameters ______________________________________________________________
        exchange = stateEndpoint.getExchanges().get(0);
        assertThat("String class expected", exchange.getIn().getBody(), instanceOf(String.class));
        payload = (String)exchange.getIn().getBody();
        event = unmashall(payload);

        // Generated Event content
        assertThat("Auto-EventId", event.getEventId(), not(isEmptyOrNullString()));
        assertThat("Auto-Metadata", event.getMetadata(), not(nullValue()));
        assertThat("Auto-EventData", event.getEventData(), not(nullValue()));

        // Common Event content
        assertThat("Common-GlobalTxId", event.getGlobalTxId(), not(isEmptyOrNullString()));
        assertEquals("Common-EventGroup", "NotSpecified", event.getEventGroup());
        assertEquals("Common-ApplicationName", "CEERS_TESTER", event.getApplicationName());
        assertThat("Common-MessageName", event.getMessageName(), not(isEmptyOrNullString()));
        assertThat("Common-ServerName", event.getServerName(), not(isEmptyOrNullString()));
        assertThat("Common-EnvironmentName", event.getEnvironmentName(), not(isEmptyOrNullString()));
        assertThat("Common-ComponentName", event.getComponentName(), not(isEmptyOrNullString()));
        assertThat("Common-EventTimestsamp", event.getEventTimestamp(), not(nullValue()));
        assertThat("Common-UserdataNotPresent", event.getUserdata(), nullValue());
        assertEquals("Common-DataSensitivity", "RESTRICT", event.getDataSensitivity());

        // State Event specific content
        assertThat("State-TypePresent", event.getEventData().getState(), not(nullValue()));
        assertEquals("State-TransactionState", "INFO", event.getEventData().getState().getTransactionState());
        assertEquals("State-AdditionalInfo", "No Additional Info Provided", event.getEventData().getState().getAdditionalInfo());

        // Maximum Parameters ______________________________________________________________
        /** Maximum Parameter State URI
            ceers://?eventType=state
            &globalTxId=75bc9f2c-ece4-4d32-8958-55d17ad125e2
            &eventGroup=TEST_GROUP
            &applicationName=CEERS_TESTER
            &messageName=MAX_PARAMETERS
            &serverName=TESTSERVER
            &environmentName=UNITTEST
            &componentName=TESTCOMPONENT
            &eventTimestamp=2016-04-16T23:51:53.752-07:00
            &userdata=%27FirstName%27=%27Tim%27,%27LastName%27=%27Schramer%27,%27PluckValue%27=%27XPATH(//MyChild2/Value/text())%27
            &dataSensitivity=FAR12
            &transactionState=COMPLETED
            &additionalInfo=Unit%20Test%20Additional%20Info
            &alternateLogFilePath=C:%5Ctemp%5CCeersEvents  // Option added to send Event to file instead of CEERS (Windows folder)
        */
        exchange = stateEndpoint.getExchanges().get(1);
        assertThat("String class expected", exchange.getIn().getBody(), instanceOf(String.class));
        payload = (String)exchange.getIn().getBody();
        event = unmashall(payload);

        // Generated Event content
        assertThat("Auto-EventId", event.getEventId(), not(isEmptyOrNullString()));
        assertThat("Auto-Metadata", event.getMetadata(), not(nullValue()));
        assertThat("Auto-EventData", event.getEventData(), not(nullValue()));

        // Common Event content
        assertEquals("Common-GlobalTxId", "75bc9f2c-ece4-4d32-8958-55d17ad125e2", event.getGlobalTxId());
        assertEquals("Common-EventGroup", "TEST_GROUP", event.getEventGroup());
        assertEquals("Common-ApplicationName", "CEERS_TESTER", event.getApplicationName());
        assertEquals("Common-MessageName", "MAX_PARAMETERS", event.getMessageName());
        assertEquals("Common-ServerName", "TESTSERVER", event.getServerName());
        assertEquals("Common-EnvironmentName", "UNITTEST", event.getEnvironmentName());
        assertEquals("Common-ComponentName", "TESTCOMPONENT", event.getComponentName());
        assertEquals("Common-EventTimestsamp", "2016-04-16T23:51:53.752-07:00", event.getEventTimestamp().toString());
        assertEquals("Common-DataSensitivity", "FAR12", event.getDataSensitivity());

        // State Event specific content
        assertThat("State-TypePresent", event.getEventData().getState(), not(nullValue()));
        assertEquals("State-TransactionState", "COMPLETED", event.getEventData().getState().getTransactionState());
        assertEquals("State-AdditionalInfo", "Unit Test Additional Info", event.getEventData().getState().getAdditionalInfo());

        // Also test manual send methods with the last Exchange. Send to a subdirectory of the eventOutputDir.
        String eventID = "";
        eventID = CeersMethodTest.ceersStateSend(exchange, Paths.get(eventOutputDir, "MethodUnitTest").toString());
        assertThat("State-TestSendMethod", eventID, not(isEmptyOrNullString()));
    }

    // Test Notification Event Component calls______________________________________________
    @Test
    public void ceersNotificationMessage() throws Exception {
        Exchange exchange;
        String payload;
        Event event;

        // let's add the component manually for the test
        // it doesn't always seem to load it from the manifest description
        context.addComponent("ceers", new CeersComponent());

        MockEndpoint notificationEndpoint = getMockEndpoint(MOCK_REMOTE_NOTIFICATION_QUEUE);
        notificationEndpoint.setExpectedCount(2);

        // Send with minimum URI values
        producer.sendBody("ceers://?eventType=notification&applicationName=CEERS_TESTER", null);
        // Send minimum again, but write Event XML to "alternateLogFilePath=eventOutputDir" instead of queue.
        producer.sendBody("ceers://?eventType=notification&applicationName=CEERS_TESTER&alternateLogFilePath=" + HttpUtilSupport.UrlEncode(eventOutputDir), null);
        // Send with maximum URI values. (see comments below for cleaner list)
        producer.sendBody("ceers://?eventType=notification&globalTxId=75bc9f2c-ece4-4d32-8958-55d17ad125e2&eventGroup=TEST_GROUP&applicationName=CEERS_TESTER&messageName=MAX_PARAMETERS&serverName=TESTSERVER&environmentName=UNITTEST&componentName=TESTCOMPONENT&eventTimestamp=2016-04-16T23:51:53.752-07:00&userdata=%27FirstName%27=%27Tim%27,%27LastName%27=%27Schramer%27,%27PluckValue%27=%27XPATH(//MyChild2/Value/text())%27&dataSensitivity=FAR12&severity=ERROR&shortDescription=Unit%20Test%20Short%20Description&detailedMessage=Unit%20Test%20Detailed%20Message&referenceOriginalPayload=false&payloadLogAmount=BYTERANGE(0,20)&payloadMsgHeader=%27Header1%27=%27Value1%27,%27Header2%27=%27Value2%27&resubmitServiceName=UNKNOWN&resubmitParameters=%27Transport%27=%27MQSC%27,%27QueueMgr%27=%27MQHUBT1QM%27,%27Queue%27=%27AI.DEV.Q01%27&allowResubmit=true", messageBody);
        // Send maximum again, but write Event XML to "alternateLogFilePath=eventOutputDir" instead of queue.
        producer.sendBody("ceers://?eventType=notification&globalTxId=75bc9f2c-ece4-4d32-8958-55d17ad125e2&eventGroup=TEST_GROUP&applicationName=CEERS_TESTER&messageName=MAX_PARAMETERS&serverName=TESTSERVER&environmentName=UNITTEST&componentName=TESTCOMPONENT&eventTimestamp=2016-04-16T23:51:53.752-07:00&userdata=%27FirstName%27=%27Tim%27,%27LastName%27=%27Schramer%27,%27PluckValue%27=%27XPATH(//MyChild2/Value/text())%27&dataSensitivity=FAR12&severity=ERROR&shortDescription=Unit%20Test%20Short%20Description&detailedMessage=Unit%20Test%20Detailed%20Message&referenceOriginalPayload=false&payloadLogAmount=BYTERANGE(0,20)&payloadMsgHeader=%27Header1%27=%27Value1%27,%27Header2%27=%27Value2%27&resubmitServiceName=UNKNOWN&resubmitParameters=%27Transport%27=%27MQSC%27,%27QueueMgr%27=%27MQHUBT1QM%27,%27Queue%27=%27AI.DEV.Q01%27&allowResubmit=true&alternateLogFilePath=" + HttpUtilSupport.UrlEncode(eventOutputDir), messageBody);

        assertMockEndpointsSatisfied();

        // Minimum Parameters ______________________________________________________________
        exchange = notificationEndpoint.getExchanges().get(0);
        assertThat("String class expected", exchange.getIn().getBody(), instanceOf(String.class));
        payload = (String)exchange.getIn().getBody();
        event = unmashall(payload);

        // Generated Event content
        assertThat("Auto-EventId", event.getEventId(), not(isEmptyOrNullString()));
        assertThat("Auto-Metadata", event.getMetadata(), not(nullValue()));
        assertThat("Auto-EventData", event.getEventData(), not(nullValue()));

        // Common Event content
        assertThat("Common-GlobalTxId", event.getGlobalTxId(), not(isEmptyOrNullString()));
        assertEquals("Common-EventGroup", "NotSpecified", event.getEventGroup());
        assertEquals("Common-ApplicationName", "CEERS_TESTER", event.getApplicationName());
        assertThat("Common-MessageName", event.getMessageName(), not(isEmptyOrNullString()));
        assertThat("Common-ServerName", event.getServerName(), not(isEmptyOrNullString()));
        assertThat("Common-EnvironmentName", event.getEnvironmentName(), not(isEmptyOrNullString()));
        assertThat("Common-ComponentName", event.getComponentName(), not(isEmptyOrNullString()));
        assertThat("Common-EventTimestsamp", event.getEventTimestamp(), not(nullValue()));
        assertThat("Common-UserdataNotPresent", event.getUserdata(), nullValue());
        assertEquals("Common-DataSensitivity", "RESTRICT", event.getDataSensitivity());

        // Notification Event specific content
        assertThat("Notification-TypePresent", event.getEventData().getNotification(), not(nullValue()));
        assertEquals("Notification-Severity", "INFO", event.getEventData().getNotification().getSeverity());
        assertEquals("Notification-ShortDescription", "No Description Provided", event.getEventData().getNotification().getShortDescription());
        assertThat("Notification-NoDetailedMessage", event.getEventData().getNotification().getDetailedMessage(), isEmptyOrNullString());
        assertThat("Notification-ResubmitInfoNotPresent", event.getEventData().getNotification().getResubmitInfo(), nullValue());
        assertEquals("Notification-OriginalEventIdSet", event.getEventId(), exchange.getProperty("CeersOriginalEventId", String.class));

        // Maximum Parameters ______________________________________________________________
        /** Maximum Parameter Notification URI
            ceers://?eventType=notification
            &globalTxId=75bc9f2c-ece4-4d32-8958-55d17ad125e2
            &eventGroup=TEST_GROUP
            &applicationName=CEERS_TESTER
            &messageName=MAX_PARAMETERS
            &serverName=TESTSERVER
            &environmentName=UNITTEST
            &componentName=TESTCOMPONENT
            &eventTimestamp=2016-04-16T23:51:53.752-07:00
            &userdata=%27FirstName%27=%27Tim%27,%27LastName%27=%27Schramer%27,%27PluckValue%27=%27XPATH(//MyChild2/Value/text())%27
            &dataSensitivity=FAR12
            &severity=ERROR
            &shortDescription=Unit%20Test%20Short%20Description
            &detailedMessage=Unit%20Test%20Detailed%20Message
            &referenceOriginalPayload=false
            &payloadLogAmount=BYTERANGE(0,20)
            &payloadMsgHeader=%27Header1%27=%27Value1%27,%27Header2%27=%27Value2%27
            &resubmitServiceName=UNKNOWN
            &resubmitParameters=%27Transport%27=%27MQSC%27,%27QueueMgr%27=%27MQHUBT1QM%27,%27Queue%27=%27AI.DEV.Q01%27
            &allowResubmit=true
            &alternateLogFilePath=C:%5Ctemp%5CCeersEvents  // Option added to send Event to file instead of CEERS (Windows folder)
        */
        exchange = notificationEndpoint.getExchanges().get(1);
        assertThat("String class expected", exchange.getIn().getBody(), instanceOf(String.class));
        payload = (String)exchange.getIn().getBody();
        event = unmashall(payload);

        // Generated Event content
        assertThat("Auto-EventId", event.getEventId(), not(isEmptyOrNullString()));
        assertThat("Auto-Metadata", event.getMetadata(), not(nullValue()));
        assertThat("Auto-EventData", event.getEventData(), not(nullValue()));

        // Common Event content
        assertEquals("Common-GlobalTxId", "75bc9f2c-ece4-4d32-8958-55d17ad125e2", event.getGlobalTxId());
        assertEquals("Common-EventGroup", "TEST_GROUP", event.getEventGroup());
        assertEquals("Common-ApplicationName", "CEERS_TESTER", event.getApplicationName());
        assertEquals("Common-MessageName", "MAX_PARAMETERS", event.getMessageName());
        assertEquals("Common-ServerName", "TESTSERVER", event.getServerName());
        assertEquals("Common-EnvironmentName", "UNITTEST", event.getEnvironmentName());
        assertEquals("Common-ComponentName", "TESTCOMPONENT", event.getComponentName());
        assertEquals("Common-EventTimestsamp", "2016-04-16T23:51:53.752-07:00", event.getEventTimestamp().toString());
        assertEquals("Common-DataSensitivity", "FAR12", event.getDataSensitivity());

        // Notification Event specific content
        assertThat("Notification-TypePresent", event.getEventData().getNotification(), not(nullValue()));
        assertEquals("Notification-Severity", "ERROR", event.getEventData().getNotification().getSeverity());
        assertEquals("Notification-ShortDescription", "Unit Test Short Description", event.getEventData().getNotification().getShortDescription());
        assertEquals("Notification-DetailedMessage", "Unit Test Detailed Message", event.getEventData().getNotification().getDetailedMessage());
        assertThat("Notification-PayloadPresent", event.getEventData().getNotification().getPayload(), not(nullValue()));
        assertThat("Notification-ContentPresent", event.getEventData().getNotification().getPayload().getContent(), not(nullValue()));
        assertThat("Notification-MessagePresent", event.getEventData().getNotification().getPayload().getContent().getMessageBody(), not(nullValue()));
        assertEquals("Notification-MessageText", "<MyRoot><MyElement1>", event.getEventData().getNotification().getPayload().getContent().getMessageBody().getTextContent());
        assertThat("Notification-PayloadHeaderPresent", event.getEventData().getNotification().getPayload().getContent().getMessageHeader(), not(nullValue()));
        assertThat("Notification-ResubmitInfoPresent", event.getEventData().getNotification().getResubmitInfo(), not(nullValue()));
        // Value of UNKNOWN should be replaced with ceers.properties value.
        assertThat("Notification-ResubmitServiceCorrected", event.getEventData().getNotification().getResubmitInfo().getResubmitServiceName(), not("UNKNOWN"));
        assertThat("Notification-ResubmitParametersPresent", event.getEventData().getNotification().getResubmitInfo().getResubmitParameters(), not(nullValue()));
        assertEquals("Notification-OriginalEventIdSet", event.getEventId(), exchange.getProperty("CeersOriginalEventId", String.class));

        // Also test manual send methods with the last Exchange. Send to a subdirectory of the eventOutputDir.
        String eventID = "";
        eventID = CeersMethodTest.ceersNotificationSend(exchange, Paths.get(eventOutputDir, "MethodUnitTest").toString());
        assertThat("Notification-TestSendMethod", eventID, not(isEmptyOrNullString()));
    }

    // Test Miscellaneous Parameter calls______________________________________________
    @Test
    public void ceersMiscMessage() throws Exception {
        Exchange exchange;
        String payload;
        Event event;

        // let's add the component manually for the test
        // it doesn't always seem to load it from the manifest description
        context.addComponent("ceers", new CeersComponent());

        MockEndpoint notificationEndpoint = getMockEndpoint(MOCK_REMOTE_NOTIFICATION_QUEUE);
        notificationEndpoint.setExpectedCount(1);

        // Send with miscellaneous URI values
        producer.sendBody("ceers://?eventType=notification&applicationName=CEERS_TESTER&messageName=MISC_PARAMETERS&shortDescription=Unit%20Test%20refEventId,%20referenceOriginalPayload,%20and%20resubmitEventId&refEventId=ORIGINAL&referenceOriginalPayload=true&originalEventId=0c9b70ad-97dd-4ab6-8fce-fae3a0af051f&resubmitParameters=%27Transport%27=%27MQSC%27,%27QueueMgr%27=%27MQHUBT1QM%27,%27Queue%27=%27AI.DEV.Q01%27&resubmitEventId=6fef2977-6dbc-4acf-81d9-b925e0677069", null);
        // Send again, but write Event XML to "alternateLogFilePath=eventOutputDir" instead of queue.
        producer.sendBody("ceers://?eventType=notification&applicationName=CEERS_TESTER&messageName=MISC_PARAMETERS&shortDescription=Unit%20Test%20refEventId,%20referenceOriginalPayload,%20and%20resubmitEventId&refEventId=ORIGINAL&referenceOriginalPayload=true&originalEventId=0c9b70ad-97dd-4ab6-8fce-fae3a0af051f&resubmitParameters=%27Transport%27=%27MQSC%27,%27QueueMgr%27=%27MQHUBT1QM%27,%27Queue%27=%27AI.DEV.Q01%27&resubmitEventId=6fef2977-6dbc-4acf-81d9-b925e0677069&alternateLogFilePath=" + HttpUtilSupport.UrlEncode(eventOutputDir), null);

        assertMockEndpointsSatisfied();

        // Misc Parameters ______________________________________________________________
        /** Misc Parameter URI
            ceers://?eventType=notification
            &applicationName=CEERS_TESTER
            &messageName=MISC_PARAMETERS
            &shortDescription=Unit%20Test%20refEventId,%20referenceOriginalPayload,%20and%20resubmitEventId
            &refEventId=ORIGINAL
            &referenceOriginalPayload=true
            &originalEventId=0c9b70ad-97dd-4ab6-8fce-fae3a0af051f
            &resubmitParameters=%27Transport%27=%27MQSC%27,%27QueueMgr%27=%27MQHUBT1QM%27,%27Queue%27=%27AI.DEV.Q01%27
            &resubmitEventId=6fef2977-6dbc-4acf-81d9-b925e0677069
            &alternateLogFilePath=C:%5Ctemp%5CCeersEvents  // Option added to send Event to file instead of CEERS (Windows folder)
        */
        exchange = notificationEndpoint.getExchanges().get(0);
        assertThat("String class expected", exchange.getIn().getBody(), instanceOf(String.class));
        payload = (String)exchange.getIn().getBody();
        event = unmashall(payload);

        // Generated Event content
        assertThat("Auto-EventId", event.getEventId(), not(isEmptyOrNullString()));
        assertThat("Auto-Metadata", event.getMetadata(), not(nullValue()));
        assertThat("Auto-EventData", event.getEventData(), not(nullValue()));

        // Common Event content
        assertThat("Common-GlobalTxId", event.getGlobalTxId(), not(isEmptyOrNullString()));
        assertEquals("Common-EventGroup", "NotSpecified", event.getEventGroup());
        assertEquals("Common-ApplicationName", "CEERS_TESTER", event.getApplicationName());
        assertThat("Common-MessageName", event.getMessageName(), not(isEmptyOrNullString()));
        assertThat("Common-ServerName", event.getServerName(), not(isEmptyOrNullString()));
        assertThat("Common-EnvironmentName", event.getEnvironmentName(), not(isEmptyOrNullString()));
        assertThat("Common-ComponentName", event.getComponentName(), not(isEmptyOrNullString()));
        assertThat("Common-EventTimestsamp", event.getEventTimestamp(), not(nullValue()));
        assertThat("Common-UserdataNotPresent", event.getUserdata(), nullValue());
        assertEquals("Common-DataSensitivity", "RESTRICT", event.getDataSensitivity());

        // Misc Event specific content
        assertThat("Misc-TypePresent", event.getEventData().getNotification(), not(nullValue()));
        assertEquals("Misc-Severity", "INFO", event.getEventData().getNotification().getSeverity());
        assertEquals("Misc-ShortDescription", "Unit Test refEventId, referenceOriginalPayload, and resubmitEventId", event.getEventData().getNotification().getShortDescription());
        assertThat("Misc-DetailedMessageNotPresent", event.getEventData().getNotification().getDetailedMessage(), nullValue());
        assertThat("Misc-PayloadPresent", event.getEventData().getNotification().getPayload(), not(nullValue()));
        assertThat("Misc-ContentNotPresent", event.getEventData().getNotification().getPayload().getContent(), nullValue());
        assertEquals("Misc-PayloadRefEventId", "0c9b70ad-97dd-4ab6-8fce-fae3a0af051f", event.getEventData().getNotification().getPayload().getRefEventId());
        assertThat("Misc-ResubmitInfoPresent", event.getEventData().getNotification().getResubmitInfo(), not(nullValue()));
        assertEquals("Misc-ResubmitEventId", "6fef2977-6dbc-4acf-81d9-b925e0677069", event.getEventData().getNotification().getResubmitInfo().getResubmitEventId());
        assertThat("Misc-ResubmitServiceCorrected", event.getEventData().getNotification().getResubmitInfo().getResubmitServiceName(), not("UNKNOWN"));
        assertThat("Misc-ResubmitParametersPresent", event.getEventData().getNotification().getResubmitInfo().getResubmitParameters(), not(nullValue()));

        // Also test manual send methods with the last Exchange. Verify OriginalEventId is preserved between Exchanges..
        String eventID = "";
        exchange.setProperty("CeersOriginalEventId", "187c9129-81b2-45d1-8c4a-41f8d70f479e");
        eventID = CeersMethodTest.ceersMiscSend(exchange, "");
        assertThat("Misc-TestSendMethod", eventID, not(isEmptyOrNullString()));
        exchange = notificationEndpoint.getExchanges().get(1);
        assertEquals("Misc-OriginalEventIdSame", "187c9129-81b2-45d1-8c4a-41f8d70f479e", exchange.getProperty("CeersOriginalEventId", String.class));

        // Same call but send to a subdirectory of the eventOutputDir.
        eventID = "";
        eventID = CeersMethodTest.ceersMiscSend(exchange, Paths.get(eventOutputDir, "MethodUnitTest").toString());
        assertThat("Misc-TestSendMethod", eventID, not(isEmptyOrNullString()));
    }

    private Event unmashall(String payload) throws JAXBException {
        JAXBContext jaxbContext = JAXBContext.newInstance(Event.class);
        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
        StringReader reader = new StringReader(payload);
        return (Event) unmarshaller.unmarshal(reader);
    }

    // Return Root Directory - for code readability
    public static String RD() {
        File[] roots = File.listRoots();
        return roots[0].toString();
    }

    // Return File.separator - for code readability
    public static String FS() {
        return File.separator;
    }
}


