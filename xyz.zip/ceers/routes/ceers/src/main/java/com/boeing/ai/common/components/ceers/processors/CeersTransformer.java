/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 12-09-2016
 * Authors      : Alex Kretchetov, David Campbell, Rohan Mars, Tim Schramer
 * File         : CeersTransformer.java - Transformer Bean to create CEERS Event
 *-----------------------------------------------------------------------------
 * Revision History (Release 2.5.5)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *-----------------------------------------------------------------------------
 * -.-.-/1.0.0  | Alex Kretchetov   | Initial Create.
 *              | David Campbell    |
 *              | Rohan Mars        |
 *              | 12-09-2016        |
 *--------------|-------------------|------------------------------------------
 * 1.0.0/2.0.0  | Tim Schramer      | Major update and additions.
 *              | Rohan Mars        | Added missing CEERS API functionality
 *              | 04-13-2016        |
 *--------------|-------------------|------------------------------------------
 * 2.0.0/2.5.0  | Tim Schramer      | Robust Unit tests. Added legacy .NET
 *              | Rohan Mars        | method calls. Additional functionality
 *              | 04-21-2016        | Restructured code.
 *--------------|-------------------|------------------------------------------
 * 2.5.0/2.5.5  | Tim Schramer      | Restructured to natively support Classes
 *              | 04-28-2016        | ported from .NET.
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.components.ceers.processors;
import com.boeing.ai.common.components.ceers.endpoint.CeersEventManagerImpl;
import com.boeing.ai.common.components.ceers.utils.CeersUtils;
import com.boeing.ai.common.components.ceers.utils.EventLoggingUtility;
import com.boeing.ai.common.components.ceers.exception.CeersException;
import com.boeing.ai.common.utilities.StringSupport;

import com.boeing.ai.fuse.framework.Context;

// For debugging
// import java.io.FileOutputStream;
// import java.io.OutputStream;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/*---------------------------------------------------------------------------*/
public class CeersTransformer implements Processor {

    private static final transient Logger LOG = LoggerFactory.getLogger(CeersTransformer.class);

    public void process(Exchange exchange)
    throws Exception {
        CeersEventManagerImpl em = (CeersEventManagerImpl)exchange.getIn().getBody();
        EventLoggingUtility eventLogUtil = null;
        Boolean disableLogging = false;
        Boolean ignoreErrors = true;
        String metaData = "";
        String outputDir = "";
        String originalEventID = "";

        LOG.info("CeersTransformer in: " + exchange.getIn().getBody());

        try {

// For debugging to see serialized em.
//        OutputStream outputStream = null;
//        try {
//            String outString = "C:\\temp\\CeersEvents\\EM\\EventManager_" + em.getEventType().toString() + em.toString() + ".xml";
//            String outString = "EventTimboy_" + em.getEventType().toString() + em.toString() + ".xml";
//            outString = outString.replace("com.boeing.ai.common.components.ceers.CeersEventManagerImpl", "");
//            outputStream = new FileOutputStream(outString);
//            CeersUtils.marshalCeersObject(em, outputStream);
//        } finally {
//            outputStream.flush();
//            outputStream.close();
//            outputStream = null;
//            System.gc();
//        }

            // Setup specific values for each Event Type.
            switch (em.getEventType() ) {
            case AUDIT:
                // Processing control settings.
                disableLogging = em.getAuditEvent().getDisableLogging();
                ignoreErrors = em.getAuditEvent().getIgnoreEventErrors();
                if (disableLogging == false) {
                    // Add Metadata if missing
                    metaData = em.getAuditEvent().getMetaData();
                    if (StringSupport.isBlank(metaData)) {
                        metaData = CeersUtils.getExchangeMetadata("", exchange);
                        em.getAuditEvent().setMetaData(metaData);
                    }
                    eventLogUtil = CeersUtils.setupAuditEvent(em.getAuditEvent());
                    originalEventID = em.getAuditEvent().getOriginalEventID();
                    outputDir = em.getAuditEvent().getAlternateLogFilePath();
                }
                break;
            case STATE:
                // Processing control settings.
                disableLogging = em.getStateEvent().getDisableLogging();
                ignoreErrors = em.getStateEvent().getIgnoreEventErrors();
                if (disableLogging == false) {
                    // Add Metadata if missing
                    metaData = em.getStateEvent().getMetaData();
                    if (StringSupport.isBlank(metaData)) {
                        metaData = CeersUtils.getExchangeMetadata("", exchange);
                        em.getStateEvent().setMetaData(metaData);
                    }
                    eventLogUtil = CeersUtils.setupStateEvent(em.getStateEvent());
                    outputDir = em.getStateEvent().getAlternateLogFilePath();
                }
                break;
            case NOTIFICATION:
                // Processing control settings.
                disableLogging = em.getNotificationEvent().getDisableLogging();
                ignoreErrors = em.getNotificationEvent().getIgnoreEventErrors();
                if (disableLogging == false) {
                    // Add Metadata if missing
                    metaData = em.getNotificationEvent().getMetaData();
                    if (StringSupport.isBlank(metaData)) {
                        metaData = CeersUtils.getExchangeMetadata("", exchange);
                        em.getNotificationEvent().setMetaData(metaData);
                    }
                    eventLogUtil = CeersUtils.setupNotificationEvent(em.getNotificationEvent());
                    originalEventID = em.getNotificationEvent().getOriginalEventID();
                    outputDir = em.getNotificationEvent().getAlternateLogFilePath();
                }
                break;
            default:
                throw new Exception("Unable to recognize Event Type during CEERS Transformer processing");
            }

            if(eventLogUtil != null) {
                // Legacy support
                Context context = Context.getInstance();
                context.setProperty ("ceers.globalTxId", eventLogUtil.getGlobalTransID());

                // Set Original Event ID or the new Event ID as Exchange Property if possible.
                if (!StringSupport.isBlank(originalEventID)) {
                    exchange.setProperty("CeersOriginalEventId", originalEventID);
                    context.setProperty ("CeersOriginalEventId", originalEventID);
                } else {
                    exchange.setProperty("CeersOriginalEventId", eventLogUtil.getEventID());
                    context.setProperty ("CeersOriginalEventId", eventLogUtil.getEventID());
                }

                // Output to a folder or set body on the Exchange
                if (!StringSupport.isBlank(outputDir)) {
                    eventLogUtil.setAlternateLogFilePath(outputDir);
                    eventLogUtil.writeEventMessage();
                } else {
                    exchange.getIn().setBody(eventLogUtil.getEventMessage());
                }
            } else if (disableLogging == false) {
                throw new CeersException("Unable to generate EventLoggingUtility object");
            }
        } catch (CeersException ce) {
            LOG.error(ce.getMessage());
            if(ignoreErrors) {
                LOG.warn("CEERS IgnoreErrors set to true. Processing not aborted.");
            } else {
                throw ce;
            }
        } catch (Exception e) {
            LOG.error("Exception while transforming CEERS Event data: " + e.getMessage());
            if(ignoreErrors) {
                LOG.warn("CEERS IgnoreErrors set to true. Processing not aborted.");
            } else {
                throw e;
            }
        }

    }
}


