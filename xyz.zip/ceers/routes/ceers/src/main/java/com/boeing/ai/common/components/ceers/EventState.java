/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 04-21-2016
 * Authors      : Tim Schramer
 * File         : EventState.java - EventState Enum exposed in CEERS API
 *                                  Converted from .NET API
 *-----------------------------------------------------------------------------
 * Revision History (Release 2.5.5)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *--------------|-------------------|------------------------------------------
 * 2.0.0/2.5.0  | Tim Schramer      | Added with version 2.5.0
 *              | 04-21-2016        |
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.components.ceers;
/*---------------------------------------------------------------------------*/
public enum EventState {
    __dummyEnum__0,
    Started,
    Completed,
    Failed,
    Info,
    Wait,
    Debug
}



