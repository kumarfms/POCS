/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 04-13-2016
 * Authors      : Rohan Mars, Tim Schramer
 * File         : MarshallerProcessor.java - Custom Marshaller for CEERS Events
 *-----------------------------------------------------------------------------
 * Revision History (Release 2.5.5)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *--------------|-------------------|------------------------------------------
 * 1.0.0/2.0.0  | Rohan Mars        | Added with version 2.0.0
 *              | 04-13-2016        |
 *--------------|-------------------|------------------------------------------
 * 2.0.0/2.5.0  | Tim Schramer      | Moved marshalling functionality to
 *              | 04-21-2016        | CeersUtils.
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.components.ceers.processors;
import java.io.ByteArrayOutputStream;

import javax.xml.bind.JAXBException;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import com.boeing.ai.common.components.ceers.utils.CeersUtils;

// For debugging
// import org.slf4j.Logger;
// import org.slf4j.LoggerFactory;
/*---------------------------------------------------------------------------*/
public class MarshallerProcessor implements Processor  {

//	private static final transient Logger LOG = LoggerFactory.getLogger(MarshallerProcessor.class);

    public MarshallerProcessor() throws JAXBException {}

    @Override
    public void process(Exchange exchange) throws Exception {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        String eventXml = CeersUtils.marshalCeersObject(exchange.getIn().getBody(), outputStream);

//           LOG.info("MarshallerProcessor Event XML: \n");
//           LOG.info(eventXml);
        exchange.getIn().setBody(eventXml);
    }
}


