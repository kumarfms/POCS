/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 04-28-2016
 * Authors      : Tim Schramer
 * File         : CeersEventSender.java - Force manually created Event to process
 *                                        by creating a ProducerTemplate for 
 *                                        pickup by the CeersTransformerBean.
 *                                        Used when creating CEERS Events through
 *                                        the Java method call API (not the URI).
 *-----------------------------------------------------------------------------
 * Revision History (Release 2.5.5)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *--------------|-------------------|------------------------------------------
 * 2.5.0/2.5.5  | Tim Schramer      | Added with version 2.5.5
 *              | 04-28-2016        |
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.components.ceers.endpoint;
import com.boeing.ai.common.components.ceers.AuditEvent;
import com.boeing.ai.common.components.ceers.EventType;
import com.boeing.ai.common.components.ceers.NotificationEvent;
import com.boeing.ai.common.components.ceers.StateEvent;
import com.boeing.ai.common.components.ceers.endpoint.CeersEventManagerImpl;

import org.apache.camel.CamelContext;
import org.apache.camel.impl.DefaultCamelContext;
import org.apache.camel.ProducerTemplate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/*---------------------------------------------------------------------------*/
public final class CeersEventSender {

    private static final transient Logger LOG = LoggerFactory.getLogger(CeersEventSender.class);
    private static CamelContext context = new DefaultCamelContext();
    private static ProducerTemplate template = context.createProducerTemplate();
    private static String producerUrl = "direct-vm:ceers";
    private static CeersEventManagerImpl em;

    public static void postAuditEvent(AuditEvent theEvent) throws Exception {
        if (theEvent == null )
            return;
        em = new CeersEventManagerImpl();
        em.setEventType(EventType.AUDIT);
        em.setAuditEvent(theEvent);
        em.setStateEvent(null);
        em.setNotificationEvent(null);

        sendEventManagerToQueue();
        return;
    }

    public static void postStateEvent(StateEvent theEvent) throws Exception {
        if (theEvent == null)
            return;
        em = new CeersEventManagerImpl();
        em.setEventType(EventType.STATE);
        em.setStateEvent(theEvent);
        em.setAuditEvent(null);
        em.setNotificationEvent(null);

        sendEventManagerToQueue();
        return;
    }

    public static void postNotificationEvent(NotificationEvent theEvent) throws Exception {
        if (theEvent == null)
            return;
        em = new CeersEventManagerImpl();
        em.setEventType(EventType.NOTIFICATION);
        em.setNotificationEvent(theEvent);
        em.setAuditEvent(null);
        em.setStateEvent(null);

        sendEventManagerToQueue();
        return;
    }

    // Send EventManager object to queue where CeersTransformerBean will process it.
    private static void sendEventManagerToQueue() throws Exception {
        context.start();
        template.setDefaultEndpointUri(producerUrl);
        template.start();
        template.sendBody(em);
        template.stop();
        Thread.sleep(1000);
        context.stop();

        return;
    }
}
