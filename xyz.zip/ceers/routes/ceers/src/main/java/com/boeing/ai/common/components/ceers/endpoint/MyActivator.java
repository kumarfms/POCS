package com.boeing.ai.common.components.ceers.endpoint;

import java.util.Dictionary;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;
import org.osgi.service.cm.Configuration;
import org.osgi.service.cm.ConfigurationAdmin;

public class MyActivator implements BundleActivator {

	

	@Override
	public void start(final BundleContext context) throws Exception {
		final ServiceReference serviceReference = context.getServiceReference(ConfigurationAdmin.class.getName());
        if (serviceReference != null) {

            final ConfigurationAdmin admin = (ConfigurationAdmin) context.getService(serviceReference);
            final Configuration configuration = admin.getConfiguration("ceers.properties");
            final Dictionary<String, Object> configurations = configuration.getProperties();

            if (configurations == null) {
                throw new Exception("Exception in loading properties file");
            }
          //  populateProperties(configurations);
        }
		
	}

	@Override
	public void stop(BundleContext arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}

}
