/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 12-09-2016
 * Authors      : Alex Kretchetov, David Campbell, Rohan Mars, Tim Schramer
 * File         : CeersComponent.java - Represents the component that manages
 *                                     {@link CeersEndpoint}.
 *-----------------------------------------------------------------------------
 * Revision History (Release 2.5.5)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *-----------------------------------------------------------------------------
 * -.-.-/1.0.0  | Alex Kretchetov   | Initial Create.
 *              | David Campbell    |
 *              | Rohan Mars        |
 *              | 12-09-2016        |
 *--------------|-------------------|------------------------------------------
 * 1.0.0/2.0.0  | Tim Schramer      | Major update and additions.
 *              | Rohan Mars        | Added missing CEERS API functionality
 *              | 04-13-2016        |
 *--------------|-------------------|------------------------------------------
 * 2.0.0/2.5.0  | Tim Schramer      | Robust Unit tests. Added legacy .NET
 *              | Rohan Mars        | method calls. Additional functionality
 *              | 04-21-2016        | Restructured code.
 *--------------|-------------------|------------------------------------------
 * 2.5.0/2.5.5  | Tim Schramer      | Restructured to natively support Classes
 *              | 04-28-2016        | ported from .NET.
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.components.ceers.endpoint;
/*---------------------------------------------------------------------------*/
import java.util.Map;

import org.apache.camel.CamelContext;
import org.apache.camel.Endpoint;
import org.apache.camel.impl.UriEndpointComponent;
/*---------------------------------------------------------------------------*/
public class CeersComponent extends UriEndpointComponent {

    protected Endpoint createEndpoint(String uri, String remaining, Map<String, Object> parameters) throws Exception {
        Endpoint endpoint = new CeersEndpoint(uri, this);
        setProperties(endpoint, parameters);
        return endpoint;
    }

    public CeersComponent() {
        super(CeersEndpoint.class);
    }

    public CeersComponent(CamelContext context) {
        super(context, CeersEndpoint.class);
    }
}


