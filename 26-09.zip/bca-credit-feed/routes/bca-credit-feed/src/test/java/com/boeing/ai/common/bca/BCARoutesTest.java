/**
 * 
 */
package com.boeing.ai.common.bca;

import java.io.File;
import java.util.Dictionary;

import org.apache.camel.EndpointInject;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.test.blueprint.CamelBlueprintTestSupport;
import org.apache.commons.io.FileUtils;
import org.junit.Test;


public class BCARoutesTest extends CamelBlueprintTestSupport  {
	
	 

	// TODO Create test message bodies that work for the route(s) being tested
	// Expected message bodies
	// TODO Create test message bodies that work for the route(s) being tested
		// Expected message bodies
		
		// To assert that everything works as it should, read the content of created xml files.
		protected  String body1;
		protected  String body2;
		protected  String body3;
		protected  String body4;
		protected  String body5;
		protected  String body6;


		// Templates to send to input endpoints
		@Produce(uri = "file:src/data?noop=true")
		protected ProducerTemplate inputEndpoint;
		// Mock endpoints used to consume messages from the output 
		// endpoints and then perform assertions
		@EndpointInject(uri = "mock:output")
		protected MockEndpoint outputEndpoint;
		@EndpointInject(uri = "mock:output2")
		protected MockEndpoint output2Endpoint;
		@EndpointInject(uri = "mock:output3")
		protected MockEndpoint output3Endpoint;
		@EndpointInject(uri = "mock:output4")
		protected MockEndpoint output4Endpoint;
		@EndpointInject(uri = "mock:output5")
		protected MockEndpoint output5Endpoint;
		
		 @SuppressWarnings({ "unchecked", "rawtypes" })
		    @Override
		    protected String useOverridePropertiesWithConfigAdmin(Dictionary props) {
		        props.put("bca.consumer.endpoint.uri", "C:\\temp\\CeersEvents");
		        props.put("bca.consumer.endpoint.delay", 60000);
		        props.put("bca.consumer.endpoint.move",".done");
		        props.put("bca.consumer.endpoint.moveFailed", ".failed");
		        props.put("bca.consumer.endpoint.include",".*.xml");
		        props.put("bca.consumer.endpoint.readLock", "markerFile");
		        props.put("bca.consumer.endpoint.maxMessagesPerPoll", 100);
		        props.put("bca.producer.endpoint.uri","C:\\temp\\CeersFinal");
		        props.put("bca.producer.endpoint.fileExist","Fail");
		        props.put("bca.producer.endpoint.chmod", 777);		       
		        return "ceers.properties";
		    }

		@Test
		public void testCamelRoute() throws Exception {
			// Easy way of reading content of xml files to a String object. 
			// But you must add dependency on commons-io project to pom.xml
			
			body1 = FileUtils.readFileToString(new File("src/data/NOTIF_2.xml"));

			// Invalid orders.
			body2 = FileUtils.readFileToString(new File("src/data/AUDIT_4.xml"));
			body3 = FileUtils.readFileToString(new File("src/data/ID-LAPTOP3"));


			// Create routes from the output endpoints to our mock endpoints 
			// so we can assert expectations
			context.addRoutes(new RouteBuilder() {
				@Override
				public void configure() throws Exception {					
					from("file:C:/temp/CeersFinal/").to(outputEndpoint);
				}
			});

			// Define some expectations

			// TODO Ensure expectations make sense for the route(s) we're testing

			// Invalid orders
			outputEndpoint.expectedBodiesReceived(body2, body4);

			// For each country one order
			output2Endpoint.expectedBodiesReceived(body1);
			output3Endpoint.expectedBodiesReceived(body3);
			/*output4Endpoint.expectedBodiesReceived(body6);
			output5Endpoint.expectedBodiesReceived(body5);*/

			// Validate our expectations
			assertMockEndpointsSatisfied();
		}
	
	@Override
    protected String getBlueprintDescriptor() {
        return "/OSGI-INF/blueprint/blueprint.xml";
    }

	

}
