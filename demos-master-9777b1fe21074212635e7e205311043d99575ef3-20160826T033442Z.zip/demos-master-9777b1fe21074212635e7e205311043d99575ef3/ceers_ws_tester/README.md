ceers_ws_tester: Camel CEERS WebService Tester Project - Tim Schramer
=====================================================================
CEERS Events are written to local directory using method calls from the ceers package.
Change the value of "eventOutputDir" in CeersWsTesterImpl.java to control this location
or to actually send them to the CEERS Application.

System requirements
-------------------
Before building and running this exammple you need:

* Maven 3.1.1 or higher
* JDK 1.7 or 1.8
* JBoss Fuse 6
* utilities 1.0.1-SNAPSHOT or higher
* ceers 2.5.5-SNAPSHOT or higher
(See pom.xml, routes\ceers-ws-tester\pom.xml and features\src\main\filtered-resources\features.xml
for CEERS dependencies.)
(See pom.xml files for other dependencies)

To build this project use

    mvn clean install

To deploy the project in OSGi. For example using Apache Karaf.
You can run the following command from the shell:

  features:addurl mvn:com.boeing.ai.ceers_ws_tester/ceers_ws_tester-features/1.0.0-SNAPSHOT/xml/features
  features:install ceers_ws_tester

There are several ways you can interact with the running web services: you can browse the web service metadata,
but you can also invoke the web services in a few different ways.

### Browsing web service metadata

A full listing of all CXF web services is available at

    http://localhost:8181/cxf

After you deployment you will see the 'CeersWsTester' service appear in the 'Available SOAP Services' section,
together with a list of operations for the endpoint and some additional information like the endpoint's address
and a link to the WSDL file for the web service:

    http://localhost:8181/cxf/CeersWsTester?wsdl

You can also use "cxf:list-endpoints" in Fuse to check the state of all CXF web services like this 

    JBossFuse:karaf@root> cxf:list-endpoints
    
    Name                      State      Address                                                      BusID                                   
    [CeersWsTesterImplPort     ] [Started ] [http://localhost:8181/cxf/CeersWsTester                   ] [org.jboss.fuse.examples.soap-cxf2040055609]
    
### To run a Web client:

You can use an external tool such as SoapUI to test web services.
A SoapUI Project to run the service is in routes\ceers-ws-tester\src\test\CallWS-soapui-project.xml.

### To run the test:

In this cxf-jaxws quistart, we also provide an integration test which can perform a few HTTP requests to test our web services. We
created a Maven `test` profile to allow us to run tests code with a simple Maven command after having deployed the bundle to Fuse:

1. Change to the `soap` directory.
2. Run the following command:

        mvn -Ptest

    The test sends the contents of the request.xml sample SOAP request file to the server and afterwards display the response
    message:

        <soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
           <soap:Body>
              <ns2:generateEventsResponse xmlns:ns2="http://ceers_ws_tester.ai.boeing.com/">
                 <return>Audit Event ID: "(new guid)" sent to folder: "C:\temp\CeersEvents"
              State Event ID: "(new guid)" sent to folder: "C:\temp\CeersEvents"
              Notification ERROR Event ID: "(new guid)" sent to folder: "C:\temp\CeersEvents"</return>
              </ns2:generateEventsResponse>
           </soap:Body>
        </soap:Envelope>

### Changing /cxf servlet alias

By default CXF Servlet is assigned a '/cxf' alias. You can change it in a couple of ways

1. Add org.apache.cxf.osgi.cfg to the /etc directory and set the 'org.apache.cxf.servlet.context' property, for example:

        org.apache.cxf.servlet.context=/custom
   
   In this way, JBoss Fuse will load the cfg when the CXF Servlet is reloaded, you can restart the CXF bundle to load the change.

2. Use shell config commands, for example:

        config:edit org.apache.cxf.osgi
        config:propset org.apache.cxf.servlet.context /custom
        config:update

    JBoss Fuse will create org.apache.cxf.osgi.cfg file in the /etc directory and and set the entry as we did in the first way after the commands are run, you need to restart the CXF bundle to load the change.
    
Undeploy the Bundle
-------------------

To stop and undeploy the bundle in Fuse:

1. Enter `osgi:list` command to retrieve your bundle id
2. To stop and uninstall the bundle enter

        osgi:uninstall <id>
