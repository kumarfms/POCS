package ai.demos.contfeed;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.apache.log4j.Logger;

/****
 * A bean which we use in the route 
 *  this comment is added as a test
 *  and another 
 *  last one
 */
public class HelloBean implements Hello {

    private String say = "Hello World";
    Logger log = Logger.getLogger(HelloBean.class);

    public String hello() {
    	
    	/*Map<String, String> env = System.getenv();
        for (String envName : env.keySet()) {
        	log.info(envName + "=" + env.get(envName));
        }*/
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return say + " at " + sdf.format(new Date());
    }

    public String getSay() {
        return say;
    }

    public void setSay(String say) {
        this.say = say;
    }
}
