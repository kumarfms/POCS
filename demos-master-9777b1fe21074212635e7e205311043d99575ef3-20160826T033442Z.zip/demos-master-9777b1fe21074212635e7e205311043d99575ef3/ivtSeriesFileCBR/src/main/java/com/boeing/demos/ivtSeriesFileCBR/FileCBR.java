package com.boeing.demos.ivtSeriesFileCBR;

/**
 * An interface for implementing Hello services.
 */
public interface FileCBR {

    String hello();
    String loadCustomersOrders();
	
}
