package com.boeing.demos.ivtSeriesFileCBR;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * A bean which we use in the route
 */
public class FileCBRBean implements FileCBR {

    private String say = "Hello World";
    
    public final static String Customers =
    		"<CustomerOrders>"
    			+ "<Customers>\n"
    				+ "<Customer>\n"
        				+ "<ID>6CC9B6C6-2BAF-457A-0FEB-977C272226FD</ID>\n"
        				+ "<Name>Kelsie Casey</Name>\n"
        				+ "<Company>Mauris Institute</Company>\n"
        				+ "<Phone>1-775-302-5777</Phone>\n"
        				+  "<City>Montgomery</City>\n"
        				+  "<Country>United States</Country>\n"
        				+"</Customer>n"
        		+ "</Customers>\n"
        		+ "<Orders>\n"
					+ "<Order>\n"
    					+ "<ID>DD29F36E-3378-0CA6-8AA2-03C6C001A51C</ID>\n"
    					+ "<OrderDate>26/01/2015</OrderDate>\n"
    					+ "<RequiredDate>04/11/2014</RequiredDate>\n"
    					+ "<Address>Ap #264-2983 Dolor Rd.</Address>\n"
    					+  "<City>Edinburgh</City>\n"
    					+  "<Country>United Kingdom</Country>\n"
    				+"</Order>n"
    			+"</Orders>n"
    		+"</CustomerOrders>";

    
    public String loadCustomersOrders() {
       // return FileCBRBean.Customers;
    	String fileName = "../../applications/demos/ivt/ivtSeriesFileCBR/CustOrders_Extd.xml";
    	
        String output = null;

        try {
        	output = new Scanner(new File(fileName)).useDelimiter("\\Z").next();        
        }
        catch(Exception ex) {
            output = Customers;              
        }
        return output;
    }

    public String hello() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return say + " at " + sdf.format(new Date());
    }

    public String getSay() {
        return say;
    }

    public void setSay(String say) {
        this.say = say;
    }
    
    
}
