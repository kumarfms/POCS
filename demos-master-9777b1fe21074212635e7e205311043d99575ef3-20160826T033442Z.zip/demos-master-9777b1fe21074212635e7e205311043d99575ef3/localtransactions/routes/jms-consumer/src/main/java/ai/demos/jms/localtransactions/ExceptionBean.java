package ai.demos.jms.localtransactions;

import java.util.Random;

public class ExceptionBean {

	public void process(Exception ex) throws Exception {
		Random random = new Random();
		if (random.nextBoolean()) {
			throw new Exception("fake error");
		}
	}
}
